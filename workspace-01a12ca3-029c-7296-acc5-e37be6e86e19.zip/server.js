const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const D = require('./shared/domain.js');

const PORT = Number(process.env.PORT || 4173);
const HOST = '0.0.0.0';
const ROOT = __dirname;
const DATA_FILE = process.env.MT_DATA_FILE ? path.resolve(process.env.MT_DATA_FILE) : path.join(ROOT, 'data', 'site.json');
const PUBLIC_DIR = path.join(ROOT, 'public');
const ADMIN_PASSWORD = process.env.MT_ADMIN_PASSWORD || 'Csmu@MT';
const ADMIN_HASH = crypto.createHash('sha256').update(ADMIN_PASSWORD).digest();
const SESSION_TTL = 12 * 60 * 60 * 1000;
const LOGIN_MAX_FAILS = 8;
const LOGIN_LOCK_MS = 15 * 60 * 1000;
const RATE_LIMIT = Number(process.env.MT_RATE_LIMIT === undefined ? 120 : process.env.MT_RATE_LIMIT);
const RATE_WINDOW = 10 * 60 * 1000;
const MAX_BODY = 32 * 1024 * 1024;

const sessions = new Map();
const loginState = new Map();
const rateBuckets = new Map();
const clients = new Set();
let writeQueue = Promise.resolve();

const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.pdf': 'application/pdf'
};

/* ---------- storage ---------- */

async function readDb() {
  return D.normalizeDb(JSON.parse(await fsp.readFile(DATA_FILE, 'utf8')));
}

async function persist(db) {
  await fsp.mkdir(path.dirname(DATA_FILE), { recursive: true });
  const temp = `${DATA_FILE}.${process.pid}.${Date.now()}.tmp`;
  await fsp.writeFile(temp, JSON.stringify(db, null, 2));
  await fsp.rename(temp, DATA_FILE);
  broadcast(db);
}

// Every write runs through one queue so two simultaneous requests can never overwrite each other.
function mutate(task) {
  const run = writeQueue.then(async () => {
    const db = await readDb();
    const outcome = await task(db);
    if (outcome.changed) await persist(db);
    return outcome;
  });
  writeQueue = run.catch(() => {});
  return run;
}

function newId(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${crypto.randomBytes(3).toString('hex')}`;
}

function broadcast(db) {
  const message = `event: site-update\ndata: ${JSON.stringify(D.publicSnapshot(db))}\n\n`;
  for (const client of clients) {
    try { client.write(message); } catch (_) { clients.delete(client); }
  }
}

/* ---------- HTTP helpers ---------- */

function send(res, status, payload, extraHeaders = {}) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'X-Content-Type-Options': 'nosniff',
    ...extraHeaders
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(new Error('That upload is too large. Please use a smaller file.'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      const text = Buffer.concat(chunks).toString('utf8');
      try { resolve(text ? JSON.parse(text) : {}); }
      catch (_) { reject(new Error('The request could not be read. Please try again.')); }
    });
    req.on('error', reject);
  });
}

function clientIp(req) {
  return req.socket.remoteAddress || 'unknown';
}

function rateLimited(req, bucketName) {
  if (!RATE_LIMIT) return false;
  const now = Date.now();
  const key = `${clientIp(req)}:${bucketName}`;
  const bucket = rateBuckets.get(key) || { count: 0, reset: now + RATE_WINDOW };
  if (bucket.reset < now) { bucket.count = 0; bucket.reset = now + RATE_WINDOW; }
  bucket.count += 1;
  rateBuckets.set(key, bucket);
  return bucket.count > RATE_LIMIT;
}

/* ---------- admin session ---------- */

function bearerToken(req) {
  const match = String(req.headers.authorization || '').match(/^Bearer\s+([a-f0-9]{64})$/i);
  return match ? match[1].toLowerCase() : '';
}

function isAdmin(req) {
  const token = bearerToken(req);
  const expires = token ? sessions.get(token) : 0;
  if (!expires) return false;
  if (expires < Date.now()) { sessions.delete(token); return false; }
  return true;
}

function requireAdmin(req, res) {
  if (isAdmin(req)) return true;
  send(res, 401, { ok: false, error: 'Please sign in to the Content Studio to continue.' });
  return false;
}

async function handleLogin(req, res) {
  const ip = clientIp(req);
  const state = loginState.get(ip) || { fails: 0, lockedUntil: 0 };
  if (state.lockedUntil > Date.now()) {
    return send(res, 429, { ok: false, error: 'Too many attempts. Please wait a few minutes and try again.' });
  }
  const body = await readBody(req);
  const candidate = crypto.createHash('sha256').update(String(body.password || '')).digest();
  if (crypto.timingSafeEqual(candidate, ADMIN_HASH)) {
    loginState.delete(ip);
    const token = crypto.randomBytes(32).toString('hex');
    sessions.set(token, Date.now() + SESSION_TTL);
    return send(res, 200, { ok: true, token });
  }
  state.fails += 1;
  if (state.fails >= LOGIN_MAX_FAILS) { state.fails = 0; state.lockedUntil = Date.now() + LOGIN_LOCK_MS; }
  loginState.set(ip, state);
  return send(res, 401, { ok: false, error: 'That password does not match. Please try again.' });
}

/* ---------- validation for content collections ---------- */

const clean = (value, max) => String(value === undefined || value === null ? '' : value).replace(/\s+/g, ' ').trim().slice(0, max);
const isSafeImage = value => /^data:image\/(png|jpe?g|webp);base64,/i.test(value) || /^https:\/\//i.test(value) || /^\/assets\/[\w./-]+$/i.test(value);
const isSafeBrochure = value => /^data:application\/pdf(?:;[^,]*)?,/i.test(value) || /^https:\/\//i.test(value) || /^\/assets\/[\w./-]+\.pdf$/i.test(value);

function sanitizeMember(input, existing) {
  const merged = { ...(existing || {}), ...input };
  const name = D.validateName(merged.name);
  if (!name.ok) return { error: name.error, field: 'name' };
  if (!D.GROUP_IDS.includes(merged.group)) return { error: 'Choose a member group: Core Committee, Head Committee or Volunteers.', field: 'group' };
  const phone = D.normalizeIndianMobile(merged.phone);
  if (!phone.ok) return { error: phone.error, field: 'phone' };
  let email = '';
  if (clean(merged.email, 254)) {
    const checked = D.validateEmail(merged.email);
    if (!checked.ok) return { error: checked.error, field: 'email' };
    email = checked.value;
  }
  const image = clean(merged.image, 3_000_000);
  if (image && !isSafeImage(image)) return { error: 'Photos must be PNG, JPG or WebP images.', field: 'image' };
  const group = merged.group;
  return {
    value: D.normalizeMember({
      ...merged,
      id: merged.id,
      name: name.value,
      role: clean(merged.role, 80),
      group,
      phone: phone.e164,
      email,
      bio: clean(merged.bio, 600),
      image,
      showOnHome: group === 'management' ? merged.showOnHome !== false : false
    })
  };
}

function sanitizeEvent(input, existing) {
  const merged = { ...(existing || {}), ...input };
  const title = clean(merged.title, 120);
  if (title.length < 2) return { error: 'Give the event a title.', field: 'title' };
  if (!D.SCOPE_IDS.includes(merged.scope)) return { error: 'Choose the event scope: Intercollege, Interdepartmental or Departmental.', field: 'scope' };
  const month = merged.month === '' || merged.month === undefined || merged.month === null ? '' : Number(merged.month);
  let isoDate = '';
  if (Number.isInteger(month) && month >= 0 && month <= 11 && clean(merged.day, 4) && clean(merged.year, 4)) {
    isoDate = D.validIso(clean(merged.year, 4), month + 1, clean(merged.day, 4).replace(/\D/g, ''));
    if (!isoDate) return { error: 'That date does not exist. Check the day, month and year.', field: 'day' };
  } else if (clean(merged.date, 60)) {
    isoDate = D.eventIsoDate({ date: clean(merged.date, 60) });
  }
  const date = isoDate ? D.formatIsoDate(isoDate) : (clean(merged.date, 60) || 'Date to be announced');
  const feeType = D.FEE_TYPES.includes(merged.feeType) ? merged.feeType : 'free';
  const fee = feeType === 'paid' ? Number(merged.fee) : 0;
  if (feeType === 'paid' && (!Number.isFinite(fee) || fee <= 0 || fee > 100000)) return { error: 'Enter the entry fee in rupees (₹1–₹1,00,000).', field: 'fee' };
  const capacityText = clean(merged.capacity, 6);
  const capacity = capacityText === '' ? null : Number(capacityText);
  if (capacity !== null && (!Number.isInteger(capacity) || capacity < 1 || capacity > 5000)) return { error: 'Seat capacity must be a whole number from 1 to 5000, or left blank for no limit.', field: 'capacity' };
  const venue = clean(merged.location, 160);
  if (!venue) return { error: 'Add the venue for this event.', field: 'location' };
  const brochureUrl = clean(merged.brochureUrl, 500);
  if (brochureUrl && !/^https:\/\//i.test(brochureUrl)) return { error: 'The brochure link must start with https:// and point to a PDF.', field: 'brochureUrl' };
  const attachment = clean(merged.attachment, 30_000_000);
  if (attachment && !isSafeBrochure(attachment)) return { error: 'Brochures must be PDF files.', field: 'attachment' };
  const image = clean(merged.image, 3_000_000);
  if (image && !isSafeImage(image)) return { error: 'Cover images must be PNG, JPG or WebP files.', field: 'image' };
  const registrationUrl = clean(merged.registrationUrl, 500);
  if (registrationUrl && !/^https:\/\//i.test(registrationUrl)) return { error: 'The details link must start with https://', field: 'registrationUrl' };
  const category = clean(merged.category, 60) || clean(merged.kicker, 40) || 'Club gathering';
  return {
    value: D.normalizeEvent({
      ...merged,
      id: merged.id,
      title,
      scope: merged.scope,
      date,
      isoDate,
      month: month === '' ? '' : String(month),
      day: clean(merged.day, 4),
      year: clean(merged.year, 4),
      time: clean(merged.time, 40),
      location: venue,
      instructor: clean(merged.instructor, 120),
      category,
      kicker: clean(merged.kicker, 40) || category,
      description: clean(merged.description, 1500),
      feeType,
      fee: feeType === 'paid' ? fee : 0,
      capacity,
      brochureUrl,
      attachment,
      attachmentName: clean(merged.attachmentName, 120) || (attachment ? 'brochure.pdf' : ''),
      image,
      registrationUrl,
      published: merged.published === true || merged.published === 'true'
    })
  };
}

function sanitizeGallery(input, existing) {
  const merged = { ...(existing || {}), ...input };
  const image = clean(merged.image, 3_000_000);
  if (image && !isSafeImage(image)) return { error: 'Photos must be PNG, JPG or WebP images.', field: 'image' };
  const url = clean(merged.url, 500);
  if (url && !/^https:\/\//i.test(url)) return { error: 'The photo link must start with https://', field: 'url' };
  const title = clean(merged.title, 120) || clean(merged.caption, 120);
  return {
    value: D.normalizeGallery({
      ...merged,
      id: merged.id,
      title,
      category: clean(merged.category, 60) || 'Event',
      caption: clean(merged.caption, 200) || title,
      alt: clean(merged.alt, 200) || title,
      url,
      image
    })
  };
}

function sanitizeHistory(input, existing) {
  const merged = { ...(existing || {}), ...input };
  return { value: { ...merged, id: merged.id, year: clean(merged.year, 60), title: clean(merged.title, 160), body: clean(merged.body, 1200) } };
}

const COLLECTIONS = {
  team: { sanitize: sanitizeMember, label: 'Member' },
  events: { sanitize: sanitizeEvent, label: 'Event' },
  gallery: { sanitize: sanitizeGallery, label: 'Photo' },
  history: { sanitize: sanitizeHistory, label: 'Milestone' }
};

const SITE_TEXT_FIELDS = ['clubName', 'shortName', 'eyebrow', 'tagline', 'intro', 'announcement', 'aboutHeading', 'aboutBody', 'clubDescription', 'mission', 'vision', 'memberBenefits', 'joiningIntro', 'memberVision', 'registrationIntro', 'contactNote', 'instagramHandle', 'universityName', 'department', 'address', 'addressSource', 'universityWebsite', 'clubPhone'];

function sanitizeSiteUpdate(body) {
  const update = {};
  for (const field of SITE_TEXT_FIELDS) {
    if (body[field] !== undefined) update[field] = clean(body[field], field === 'intro' || field.endsWith('Body') || field === 'clubDescription' ? 1200 : 400);
  }
  if (body.instagramUrl !== undefined) {
    const url = clean(body.instagramUrl, 400);
    if (url && !/^https:\/\//i.test(url)) return { error: 'The Instagram link must start with https://' };
    update.instagramUrl = url;
  }
  if (body.email !== undefined) {
    const email = clean(body.email, 254);
    if (email) {
      const checked = D.validateEmail(email);
      if (!checked.ok) return { error: checked.error };
      update.email = checked.value;
    } else update.email = '';
  }
  if (body.logoImage !== undefined) {
    const logo = clean(body.logoImage, 3_000_000);
    if (logo && !isSafeImage(logo)) return { error: 'The logo must be a PNG, JPG or WebP image.' };
    update.logoImage = logo;
  }
  if (Array.isArray(body.stats)) {
    update.stats = body.stats.slice(0, 3).map(stat => ({ value: clean(stat && stat.value, 12), label: clean(stat && stat.label, 40) }));
  }
  return { value: update };
}

/* ---------- public submissions (volunteer applications and legacy forms) ---------- */

function sanitizeSubmission(body) {
  const requested = ['volunteer', 'membership', 'club-registration'].includes(body.type) ? body.type : 'volunteer';
  const type = requested === 'membership' ? 'volunteer' : requested;
  const name = D.validateName(body.name);
  if (!name.ok) return { error: name.error, field: 'name' };
  const email = D.validateEmail(body.email);
  if (!email.ok) return { error: email.error, field: 'email' };
  const phone = D.normalizeIndianMobile(body.phone);
  if (!phone.ok) return { error: phone.error, field: 'phone' };
  const base = { type, name: name.value, email: email.value, phone: phone.e164 };
  if (type === 'volunteer') {
    const contribution = clean(body.contribution, 1200);
    if (contribution.length < 30) return { error: 'Please share at least 30 characters about how you can help Mindful Tattva grow.', field: 'contribution' };
    return { value: { ...base, programme: clean(body.programme || body.course, 120), year: clean(body.year, 40), interests: clean(body.interests, 500), contribution, status: 'pending' } };
  }
  return { value: { ...base, event: clean(body.event, 160), message: clean(body.message, 1000), interests: clean(body.interests, 500), course: clean(body.course, 160), year: clean(body.year, 60), status: 'pending' } };
}

/* ---------- event registrations and passes ---------- */

function eventsById(db) {
  return Object.fromEntries(db.events.map(event => [event.id, event]));
}

function passForSerial(db, serial) {
  const rows = db.registrations.filter(row => row.serial === serial);
  return rows.length ? D.buildPass(rows, eventsById(db)) : null;
}

function uniqueSerial(db, year) {
  const used = new Set(db.registrations.map(row => row.serial));
  for (let attempt = 0; attempt < 100; attempt += 1) {
    const serial = D.serialFor(year, String(crypto.randomInt(100000, 1000000)));
    if (!used.has(serial)) return serial;
  }
  throw new Error('Could not issue a unique serial number');
}

function makeRow({ serial, event, formScope, person, now }) {
  return {
    id: newId('reg'),
    serial,
    passType: 'event',
    eventId: event.id,
    // Snapshots: a registration outlives its event, so the pass and the CSV keep the event's own
    // title, date and venue even after the event is deleted from the calendar.
    eventTitle: event.title,
    eventDate: D.eventIsoDate(event),
    eventTime: event.time || '',
    eventVenue: event.location || '',
    eventScope: event.scope,
    formScope,
    name: person.name,
    email: person.email,
    phone: person.phone,
    college: person.college,
    department: person.department,
    rollNo: person.rollNo,
    yearOrSemester: person.yearOrSemester || '',
    feeType: event.feeType,
    fee: event.feeType === 'paid' ? Number(event.fee) || 0 : 0,
    createdAt: now.toISOString()
  };
}

function registerAttendee(db, body, now) {
  const today = D.todayIso(now);
  const year = Number(today.slice(0, 4));
  const target = clean(body.target || body.eventId, 80);
  if (!target) return { changed: false, status: 400, body: { ok: false, error: 'Choose an event first.', code: 'validation', fields: { target: 'Choose an event.' } } };
  const event = db.events.find(item => item.id === target);
  if (!event || !event.published) return { changed: false, status: 404, body: { ok: false, error: 'This event is not open for registration.', code: 'not-found' } };
  if (!D.isUpcomingEvent(event, today)) return { changed: false, status: 409, body: { ok: false, error: 'This event has already taken place.', code: 'closed' } };
  const check = D.validateRegistrationFields(body, event.scope);
  if (!check.ok) {
    const fields = { ...check.errors };
    return { changed: false, status: 400, body: { ok: false, error: 'Please correct the highlighted fields.', code: 'validation', fields } };
  }
  const person = check.value;
  const sameContact = row => row.email === person.email || row.phone === person.phone;

  const existing = db.registrations.find(row => row.eventId === event.id && sameContact(row));
  if (existing) {
    return {
      changed: false,
      status: 409,
      body: {
        ok: false,
        code: 'duplicate',
        error: 'You are already registered for this event. Your existing pass is shown below.',
        eventId: event.id,
        passes: [passForSerial(db, existing.serial)]
      }
    };
  }
  const seats = D.seatsFor(db.registrations, event.id, event.capacity);
  if (seats.full) return { changed: false, status: 409, body: { ok: false, code: 'full', error: `Sorry, ${event.title} is full.`, seats } };
  const serial = uniqueSerial(db, year);
  const row = makeRow({ serial, event, formScope: event.scope, person, now });
  db.registrations.push(row);
  return { changed: true, status: 201, body: { ok: true, pass: passForSerial(db, serial) } };
}

function rosterFor(db, eventId) {
  return db.registrations
    .filter(row => row.eventId === eventId)
    .sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)))
    .map(row => ({ name: row.name, serial: row.serial, passType: row.passType, registeredAt: row.createdAt }));
}

function registrationsCsv(db, eventId) {
  const events = eventsById(db);
  const rows = db.registrations
    .filter(row => !eventId || row.eventId === eventId)
    .sort((a, b) => {
      const byEvent = String(D.eventIsoDate(events[a.eventId]) || '9999').localeCompare(String(D.eventIsoDate(events[b.eventId]) || '9999'));
      return byEvent || String(a.createdAt).localeCompare(String(b.createdAt));
    })
    .map(row => D.registrationCsvRow(row, events[row.eventId]));
  return D.toCsv(D.REGISTRATION_CSV_HEADERS, rows);
}

/* ---------- API routes ---------- */

function publicCollection(db, name) {
  if (name === 'team') return (db.team || []).map(D.publicMember);
  if (name === 'events') return D.publicSnapshot(db).events;
  return db[name];
}

async function handleApi(req, res, pathname) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    return res.end();
  }

  /* live updates */
  if (pathname === '/api/stream' && req.method === 'GET') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*'
    });
    res.write(': connected\n\n');
    clients.add(res);
    const heartbeat = setInterval(() => {
      try { res.write(': heartbeat\n\n'); } catch (_) { clearInterval(heartbeat); clients.delete(res); }
    }, 25000);
    req.on('close', () => { clearInterval(heartbeat); clients.delete(res); });
    return;
  }

  /* admin session */
  if (pathname === '/api/session' && req.method === 'GET') return send(res, 200, { authenticated: isAdmin(req) });
  if (pathname === '/api/admin/login' && req.method === 'POST') return handleLogin(req, res);
  if (pathname === '/api/admin/logout' && req.method === 'POST') {
    const token = bearerToken(req);
    if (token) sessions.delete(token);
    return send(res, 200, { ok: true });
  }

  /* public site data */
  if (pathname === '/api/site' && req.method === 'GET') {
    const db = await readDb();
    return send(res, 200, D.publicSnapshot(db));
  }
  if (pathname === '/api/site' && req.method === 'PUT') {
    if (!requireAdmin(req, res)) return;
    let body;
    try { body = await readBody(req); } catch (error) { return send(res, 400, { ok: false, error: error.message }); }
    const checked = sanitizeSiteUpdate(body);
    if (checked.error) return send(res, 400, { ok: false, error: checked.error });
    try {
      const outcome = await mutate(db => {
        db.site = { ...db.site, ...checked.value };
        return { changed: true, status: 200, body: D.publicSnapshot(db) };
      });
      return send(res, 200, outcome.body);
    } catch (_) {
      return send(res, 500, { ok: false, error: 'The change could not be saved. Nothing was saved — please try again.' });
    }
  }

  /* event registration, roster and pass lookup (public) */
  const rosterMatch = pathname.match(/^\/api\/events\/([^/]+)\/roster$/);
  if (rosterMatch && req.method === 'GET') {
    const db = await readDb();
    const event = db.events.find(item => item.id === decodeURIComponent(rosterMatch[1]));
    if (!event) return send(res, 404, { ok: false, error: 'Event not found' });
    const seats = D.seatsFor(db.registrations, event.id, event.capacity);
    return send(res, 200, { ok: true, event: { id: event.id, title: event.title, date: D.displayDate(event), seats }, roster: rosterFor(db, event.id) });
  }

  if (pathname === '/api/registrations' && req.method === 'POST') {
    if (rateLimited(req, 'registration')) return send(res, 429, { ok: false, error: 'Too many registrations from this connection. Please wait a few minutes.' });
    let body;
    try { body = await readBody(req); } catch (error) { return send(res, 400, { ok: false, error: error.message }); }
    try {
      const outcome = await mutate(db => registerAttendee(db, body, new Date()));
      return send(res, outcome.status, outcome.body);
    } catch (_) {
      return send(res, 500, { ok: false, code: 'save-failed', error: 'The registration could not be saved, so no pass was issued. Please try again.' });
    }
  }

  if (pathname === '/api/passes/lookup' && req.method === 'POST') {
    if (rateLimited(req, 'lookup')) return send(res, 429, { ok: false, error: 'Too many lookups. Please wait a few minutes.' });
    let body;
    try { body = await readBody(req); } catch (error) { return send(res, 400, { ok: false, error: error.message }); }
    const email = D.validateEmail(body.email);
    if (!email.ok) return send(res, 400, { ok: false, error: email.error, fields: { email: email.error } });
    const phone = D.normalizeIndianMobile(body.phone);
    if (!phone.ok) return send(res, 400, { ok: false, error: phone.error, fields: { phone: phone.error } });
    const db = await readDb();
    const serials = [...new Set(db.registrations.filter(row => row.email === email.value && row.phone === phone.digits).map(row => row.serial))];
    return send(res, 200, { ok: true, passes: serials.map(serial => passForSerial(db, serial)), note: 'If you are registered with these details, your pass appears here.' });
  }

  /* volunteer applications and legacy forms (public submit, admin review) */
  const submissionMatch = pathname.match(/^\/api\/submissions(?:\/([^/]+)(\/approve)?)?$/);
  if (submissionMatch) {
    const [, submissionId, approveSegment] = submissionMatch;
    if (req.method === 'POST' && !submissionId) {
      if (rateLimited(req, 'submission')) return send(res, 429, { ok: false, error: 'Too many submissions from this connection. Please wait a few minutes.' });
      let body;
      try { body = await readBody(req); } catch (error) { return send(res, 400, { ok: false, error: error.message }); }
      const checked = sanitizeSubmission(body);
      if (checked.error) return send(res, 400, { ok: false, error: checked.error, fields: checked.field ? { [checked.field]: checked.error } : undefined });
      try {
        const outcome = await mutate(db => {
          const item = checked.value;
          if (item.type === 'volunteer') {
            const duplicate = db.submissions.find(entry => entry.type === 'volunteer' && entry.status !== 'rejected' && (entry.email === item.email || entry.phone === item.phone));
            if (duplicate) return { changed: false, status: 409, body: { ok: false, code: 'duplicate', error: 'A volunteer application with these details already exists. The team will be in touch soon.' } };
          }
          const record = { id: newId('submission'), ...item, submittedAt: new Date().toISOString() };
          db.submissions.unshift(record);
          return { changed: true, status: 201, body: { ok: true, id: record.id } };
        });
        return send(res, outcome.status, outcome.body);
      } catch (_) {
        return send(res, 500, { ok: false, error: 'Your application could not be saved. Please try again.' });
      }
    }
    if (!requireAdmin(req, res)) return;
    if (req.method === 'GET' && !submissionId) {
      const db = await readDb();
      return send(res, 200, db.submissions);
    }
    if (req.method === 'POST' && submissionId && approveSegment) {
      let body;
      try { body = await readBody(req); } catch (error) { return send(res, 400, { ok: false, error: error.message }); }
      try {
        const outcome = await mutate(db => {
          const submission = db.submissions.find(item => item.id === submissionId);
          if (!submission || submission.type !== 'volunteer') return { changed: false, status: 404, body: { ok: false, error: 'Application not found.' } };
          if (submission.status === 'approved') return { changed: false, status: 409, body: { ok: false, error: 'This volunteer is already a member.' } };
          const group = D.GROUP_IDS.includes(body.group) ? body.group : 'volunteers';
          const role = clean(body.role, 80) || (group === 'volunteers' ? 'Volunteer' : 'Member');
          const member = D.normalizeMember({
            id: newId('team'),
            name: submission.name,
            role,
            group,
            phone: submission.phone,
            email: submission.email,
            bio: group === 'volunteers' ? '' : clean(submission.contribution, 600),
            image: '',
            status: 'active',
            sourceSubmissionId: submission.id,
            createdAt: new Date().toISOString()
          });
          db.team.push(member);
          submission.status = 'approved';
          submission.memberId = member.id;
          submission.approvedAt = new Date().toISOString();
          return { changed: true, status: 200, body: { ok: true, member: D.publicMember(member), submission } };
        });
        return send(res, outcome.status, outcome.body);
      } catch (_) {
        return send(res, 500, { ok: false, error: 'The member could not be saved. Nothing was approved — please try again.' });
      }
    }
    if (req.method === 'DELETE' && submissionId) {
      try {
        const outcome = await mutate(db => {
          const index = db.submissions.findIndex(item => item.id === submissionId);
          if (index < 0) return { changed: false, status: 404, body: { ok: false, error: 'Submission not found' } };
          db.submissions.splice(index, 1);
          return { changed: true, status: 200, body: { ok: true } };
        });
        return send(res, outcome.status, outcome.body);
      } catch (_) {
        return send(res, 500, { ok: false, error: 'The submission could not be deleted. Please try again.' });
      }
    }
    return send(res, 405, { ok: false, error: 'Method not allowed' });
  }

  /* admin: full member records, including volunteer contact details */
  if (pathname === '/api/admin/team' && req.method === 'GET') {
    if (!requireAdmin(req, res)) return;
    const db = await readDb();
    return send(res, 200, db.team);
  }

  /* admin registrations and exports */
  if (pathname === '/api/admin/registrations' && req.method === 'GET') {
    if (!requireAdmin(req, res)) return;
    const db = await readDb();
    const events = eventsById(db);
    const rows = db.registrations.map(row => ({ ...row, eventTitle: events[row.eventId] ? events[row.eventId].title : (row.eventTitle || 'Deleted event'), eventDate: events[row.eventId] ? D.displayDate(events[row.eventId]) : (D.formatIsoDate(row.eventDate) || '') }));
    return send(res, 200, rows);
  }
  const registrationRowMatch = pathname.match(/^\/api\/admin\/registrations\/([^/]+)$/);
  if (registrationRowMatch && req.method === 'DELETE') {
    if (!requireAdmin(req, res)) return;
    try {
      const outcome = await mutate(db => {
        const index = db.registrations.findIndex(row => row.id === decodeURIComponent(registrationRowMatch[1]));
        if (index < 0) return { changed: false, status: 404, body: { ok: false, error: 'Registration not found' } };
        db.registrations.splice(index, 1);
        return { changed: true, status: 200, body: { ok: true } };
      });
      return send(res, outcome.status, outcome.body);
    } catch (_) {
      return send(res, 500, { ok: false, error: 'The registration could not be removed. Please try again.' });
    }
  }
  if (pathname === '/api/admin/export/registrations.csv' && req.method === 'GET') {
    if (!requireAdmin(req, res)) return;
    const db = await readDb();
    const url = new URL(req.url, 'http://localhost');
    const eventId = url.searchParams.get('eventId') || '';
    const event = eventId ? db.events.find(item => item.id === eventId) : null;
    if (eventId && !event) return send(res, 404, { ok: false, error: 'Event not found' });
    const name = event ? `mindful-tattva-${D.slugify(event.title)}-registrations.csv` : 'mindful-tattva-all-registrations.csv';
    res.writeHead(200, {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${name}"`,
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff'
    });
    return res.end(registrationsCsv(db, eventId));
  }

  /* content collections */
  const match = pathname.match(/^\/api\/(history|team|events|gallery)(?:\/([^/]+))?$/);
  if (!match) return send(res, 404, { ok: false, error: 'API route not found' });
  const [, collectionName, itemId] = match;
  const config = COLLECTIONS[collectionName];

  if (req.method === 'GET' && !itemId) {
    const db = await readDb();
    return send(res, 200, publicCollection(db, collectionName));
  }
  if (!requireAdmin(req, res)) return;

  let body = {};
  if (req.method === 'POST' || req.method === 'PUT' || req.method === 'PATCH') {
    try { body = await readBody(req); } catch (error) { return send(res, 400, { ok: false, error: error.message }); }
  }

  try {
    const outcome = await mutate(db => {
      const collection = db[collectionName];
      if (req.method === 'POST' && !itemId) {
        const checked = config.sanitize({ ...body, id: undefined }, null);
        if (checked.error) return { changed: false, status: 400, body: { ok: false, error: checked.error, fields: { [checked.field]: checked.error } } };
        const item = { ...checked.value, id: newId(collectionName.slice(0, -1)), createdAt: new Date().toISOString() };
        collection.push(item);
        return { changed: true, status: 201, body: item };
      }
      if ((req.method === 'PUT' || req.method === 'PATCH') && itemId) {
        const index = collection.findIndex(item => item.id === itemId);
        if (index < 0) return { changed: false, status: 404, body: { ok: false, error: `${config.label} not found` } };
        const checked = config.sanitize(body, collection[index]);
        if (checked.error) return { changed: false, status: 400, body: { ok: false, error: checked.error, fields: { [checked.field]: checked.error } } };
        collection[index] = { ...checked.value, id: itemId, createdAt: collection[index].createdAt };
        return { changed: true, status: 200, body: collection[index] };
      }
      if (req.method === 'DELETE' && itemId) {
        const index = collection.findIndex(item => item.id === itemId);
        if (index < 0) return { changed: false, status: 404, body: { ok: false, error: `${config.label} not found` } };
        const removed = collection.splice(index, 1)[0];
        let archivedRegistrations = 0;
        if (collectionName === 'events') {
          // Registrations are never deleted with their event: they stay as archived records and keep the
          // event's own title, date and venue, so past attendance and the master CSV stay complete.
          archivedRegistrations = db.registrations.filter(row => row.eventId === removed.id).length;
        }
        return { changed: true, status: 200, body: { ok: true, archivedRegistrations } };
      }
      return { changed: false, status: 405, body: { ok: false, error: 'Method not allowed' } };
    });
    return send(res, outcome.status, outcome.body);
  } catch (_) {
    return send(res, 500, { ok: false, error: 'The change could not be saved. Nothing was saved — please try again.' });
  }
}

/* ---------- static files ---------- */

async function serveStatic(req, res, pathname) {
  let relative = decodeURIComponent(pathname).replace(/^\/+/, '');
  if (!relative) relative = 'index.html';
  let filePath = path.resolve(PUBLIC_DIR, relative);
  if (filePath !== PUBLIC_DIR && !filePath.startsWith(PUBLIC_DIR + path.sep)) return send(res, 403, { ok: false, error: 'Forbidden' });
  try {
    let stat = await fsp.stat(filePath).catch(() => null);
    if (stat && stat.isDirectory()) {
      filePath = path.join(filePath, 'index.html');
      stat = await fsp.stat(filePath).catch(() => null);
    }
    if (!stat && !path.extname(filePath)) {
      const withHtml = `${filePath}.html`;
      const htmlStat = await fsp.stat(withHtml).catch(() => null);
      if (htmlStat && htmlStat.isFile()) { filePath = withHtml; stat = htmlStat; }
    }
    if (!stat || !stat.isFile()) return send(res, 404, { ok: false, error: 'Not found' });
    const type = mimeTypes[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    fs.createReadStream(filePath).pipe(res);
  } catch (_) {
    send(res, 404, { ok: false, error: 'Not found' });
  }
}

const SHORT_ROUTES = { '/admin': '/admin.html', '/events': '/events.html', '/members': '/members.html', '/calendar': '/calendar.html', '/gallery': '/gallery.html' };

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url.pathname);
    const pathname = SHORT_ROUTES[url.pathname] || url.pathname;
    return await serveStatic(req, res, pathname);
  } catch (error) {
    if (!res.headersSent) send(res, 400, { ok: false, error: error.message || 'Request could not be completed' });
    else res.end();
  }
});

if (require.main === module) {
  server.listen(PORT, HOST, () => {
    console.log(`Mindful Tattva is live at http://${HOST}:${PORT}`);
  });
}

module.exports = { server, registerAttendee, sanitizeMember, sanitizeEvent, sanitizeSubmission, sanitizeGallery, sanitizeSiteUpdate, mutate, readDb, DATA_FILE, ADMIN_PASSWORD };
