'use strict';
// Unit tests for the shared rules (validation, dates, passes, exports, public projection).
const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../../shared/domain.js');

test('Indian mobile numbers: prefixes are stripped and the 10-digit national number is kept', () => {
  for (const input of ['9812300456', '+91 98123 00456', '+919812300456', '919812300456', '09812300456', '0091 9812300456', '+91 0 98123 00456']) {
    const result = D.normalizeIndianMobile(input);
    assert.equal(result.ok, true, `${input} should be accepted`);
    assert.equal(result.digits, '9812300456');
    assert.equal(result.e164, '+919812300456');
    assert.equal(result.display, '+91 98123 00456');
  }
});

test('Indian mobile numbers: must start with 6-9 and be exactly 10 digits', () => {
  assert.equal(D.normalizeIndianMobile('5876543210').ok, false);
  assert.equal(D.normalizeIndianMobile('98765').ok, false);
  assert.equal(D.normalizeIndianMobile('98123004567').ok, false);
  assert.equal(D.normalizeIndianMobile('').ok, false);
});

test('Indian mobile numbers: repeated digits and sequences are rejected', () => {
  for (const input of ['9999999999', '8888888888', '9898989898', '1234567890', '9876543210', '7654321098', '9123456789', '6000000001']) {
    const result = D.normalizeIndianMobile(input);
    assert.equal(result.ok, false, `${input} should be rejected`);
    assert.match(result.error, /placeholder|start with|10-digit/);
  }
  assert.equal(D.mobileDummyReason('9812300456'), '');
});

test('Indian mobile numbers: foreign codes and letters are rejected', () => {
  assert.equal(D.normalizeIndianMobile('+1 5551234567').ok, false);
  assert.equal(D.normalizeIndianMobile('+44 7911123456').ok, false);
  assert.equal(D.normalizeIndianMobile('98a12300456').ok, false);
});

test('Email: normalised to lower case; placeholder and disposable domains are rejected', () => {
  assert.equal(D.validateEmail('Asha.Rao@Gmail.com').value, 'asha.rao@gmail.com');
  assert.equal(D.validateEmail('student@csmu.ac.in').ok, true);
  assert.equal(D.validateEmail('asha+mt@gmail.com').ok, true);
  for (const input of ['x@mailinator.com', 'a@example.com', 'test@test.com', 'a@b.test', 'dummy@gmail.com', 'a@yopmail.com', 'a@tempmail.org', 'a@10minutemail.com', 'a@sample.org']) {
    assert.equal(D.validateEmail(input).ok, false, `${input} should be rejected`);
  }
  for (const input of ['bad@', 'john@domain', '', 'no-at-sign.com']) {
    assert.equal(D.validateEmail(input).ok, false, `${input} should be invalid`);
  }
});

test('Names: letters only, sensible length, no placeholders', () => {
  assert.equal(D.validateName('  Asha   Rao ').value, 'Asha Rao');
  assert.equal(D.validateName('Anne-Marie O’Neil').ok, true);
  assert.equal(D.validateName('A').ok, false);
  assert.equal(D.validateName('R2D2').ok, false);
  assert.equal(D.validateName('test').ok, false);
});

test('Scope-adaptive fields: intercollege asks for the external college, PRN and stream', () => {
  const ok = D.validateRegistrationFields({ name: 'Asha Rao', email: 'asha@gmail.com', phone: '9812300456', college: 'University of Mumbai', rollNo: 'prn/2024/0456', department: 'B.Sc. Psychology' }, 'intercollege');
  assert.equal(ok.ok, true);
  assert.equal(ok.value.college, 'University of Mumbai');
  assert.equal(ok.value.rollNo, 'PRN/2024/0456');
  assert.equal(ok.value.yearOrSemester, '');
  const missing = D.validateRegistrationFields({ name: 'Asha Rao', email: 'asha@gmail.com', phone: '9812300456' }, 'intercollege');
  assert.ok(missing.errors.college && missing.errors.rollNo && missing.errors.department);
});

test('Scope-adaptive fields: interdepartmental uses the CSMU college and needs a year', () => {
  const result = D.validateRegistrationFields({ name: 'Asha Rao', email: 'asha@gmail.com', phone: '9812300456', department: 'B.A. Psychology', rollNo: 'CS2026-14', year: '2nd Year', college: 'ignored' }, 'interdepartmental');
  assert.equal(result.ok, true);
  assert.equal(result.value.college, D.UNIVERSITY_NAME);
  assert.equal(result.value.yearOrSemester, '2nd Year');
  assert.equal(D.validateRegistrationFields({ name: 'Asha Rao', email: 'asha@gmail.com', phone: '9812300456', department: 'B.A. Psychology', rollNo: 'CS2026-14', year: '9th Year' }, 'interdepartmental').errors.year !== undefined, true);
});

test('Scope-adaptive fields: departmental locks the department and needs a semester', () => {
  const result = D.validateRegistrationFields({ name: 'Ravi Kumar', email: 'ravi@gmail.com', phone: '7045512345', department: 'Some other dept', rollNo: 'CSMU-22-091', semester: 'Semester 3' }, 'departmental');
  assert.equal(result.ok, true);
  assert.equal(result.value.department, D.DEPARTMENT_NAME);
  assert.equal(result.value.yearOrSemester, 'Semester 3');
  assert.ok(D.validateRegistrationFields({ name: 'Ravi Kumar', email: 'ravi@gmail.com', phone: '7045512345', rollNo: 'CSMU-22-091' }, 'departmental').errors.semester);
  assert.ok(D.validateRegistrationFields({ name: 'Ravi Kumar', email: 'ravi@gmail.com', phone: '7045512345' }, 'nonsense').errors.scope);
});

test('Event dates: explicit ISO, month/day/year parts, and common display strings', () => {
  assert.equal(D.eventIsoDate({ date: '24 October 2026' }), '2026-10-24');
  assert.equal(D.eventIsoDate({ date: 'October 24, 2026' }), '2026-10-24');
  assert.equal(D.eventIsoDate({ date: '2026-10-24' }), '2026-10-24');
  assert.equal(D.eventIsoDate({ date: '5 Sept 2026' }), '2026-09-05');
  assert.equal(D.eventIsoDate({ month: '9', day: '5', year: '2026' }), '2026-10-05');
  assert.equal(D.eventIsoDate({ date: 'Date to be announced' }), '');
  assert.equal(D.eventIsoDate({ date: '31 February 2026' }), '');
  assert.equal(D.eventYear({ date: 'Date to be announced' }), null);
  assert.equal(D.eventYear({ date: '1 May 2027' }), 2027);
});

test('Today and upcoming use the India calendar date', () => {
  assert.equal(D.todayIso(new Date('2026-10-08T20:00:00Z')), '2026-10-09');
  assert.equal(D.todayIso(new Date('2026-10-09T02:00:00Z')), '2026-10-09');
  assert.equal(D.isUpcomingEvent({ isoDate: '2026-10-08' }, '2026-10-09'), false);
  assert.equal(D.isUpcomingEvent({ isoDate: '2026-10-09' }, '2026-10-09'), true);
  assert.equal(D.isUpcomingEvent({ date: 'To be announced' }, '2026-10-09'), true);
});

test('Fees, seats and serials', () => {
  assert.equal(D.feeLabel({ feeType: 'paid', fee: 250 }), '₹250');
  assert.equal(D.feeLabel({ feeType: 'free', fee: 250 }), 'Free entry');
  assert.equal(D.feeStatusText(1500, true), 'Pending · ₹1,500 payable at the desk on the event day');
  assert.equal(D.feeStatusText(0, true), 'Free entry');
  const rows = [{ eventId: 'a' }, { eventId: 'a' }, { eventId: 'b' }];
  assert.deepEqual(D.seatsFor(rows, 'a', 2), { filled: 2, capacity: 2, open: 0, full: true });
  assert.equal(D.seatsFor(rows, 'a', null).full, false);
  assert.equal(D.serialFor(2026, '892415'), 'MT-2026-892415');
  assert.ok(D.SERIAL_PATTERN.test('MT-2026-892415'));
});

test('CSV: UTF-8 BOM, quoting, and protection against spreadsheet formulas', () => {
  const csv = D.toCsv(['a', 'b'], [['=1+1', 'x,y'], ['He said "hi"', 'ok']]);
  assert.equal(csv.charCodeAt(0), 0xFEFF);
  assert.equal(csv, '\uFEFFa,b\r\n\'=1+1,"x,y"\r\n"He said ""hi""",ok\r\n');
});

test('Pass model: one pass per event, with no season pass anywhere', () => {
  const eventsById = { e1: { id: 'e1', title: 'Welcome Circle', date: '24 October 2026', time: '4:00 PM', location: 'Seminar Hall', scope: 'interdepartmental' }, e2: { id: 'e2', title: 'Workshop', date: '14 November 2026', time: '2:00 PM', location: 'Lab', scope: 'intercollege', feeType: 'paid', fee: 250 } };
  const base = { serial: 'MT-2026-000001', name: 'Asha Rao', email: 'asha@gmail.com', phone: '9812300456', college: D.UNIVERSITY_NAME, department: 'B.A. Psychology', rollNo: 'CS1', yearOrSemester: '2nd Year', formScope: 'interdepartmental', createdAt: '2026-10-09T03:00:00.000Z' };
  const single = D.buildPass([{ ...base, passType: 'event', eventId: 'e1', eventScope: 'interdepartmental', feeType: 'free', fee: 0 }], eventsById);
  assert.equal(single.passType, 'event');
  assert.equal(single.eventTitle, 'Welcome Circle');
  assert.equal(single.venue, 'Seminar Hall');
  assert.equal(single.eventDate, '24 October 2026');
  assert.equal(single.feeStatus, 'Free entry');
  assert.equal(single.archived, false);
  assert.equal('seasonYear' in single, false, 'there is no season pass in the data model');
  const paid = D.buildPass([{ ...base, passType: 'event', eventId: 'e2', eventScope: 'intercollege', feeType: 'paid', fee: 250 }], eventsById);
  assert.equal(paid.feeTotal, 250);
  assert.match(paid.feeStatus, /Pending · ₹250/);
});

test('A registration outlives its event: the pass still renders after the event is deleted', () => {
  const row = {
    serial: 'MT-2026-000042', passType: 'event', eventId: 'gone',
    eventTitle: 'Deleted Workshop', eventDate: '2026-11-14', eventTime: '2:00 PM', eventVenue: 'Lab 4',
    eventScope: 'intercollege', formScope: 'intercollege', name: 'Asha Rao', email: 'asha@gmail.com',
    phone: '9812300456', college: 'University of Mumbai', department: 'B.Sc.', rollNo: 'PRN-9',
    yearOrSemester: '2nd Year', feeType: 'free', fee: 0, createdAt: '2026-10-09T03:00:00.000Z'
  };
  const pass = D.buildPass([row], {});
  assert.equal(pass.archived, true);
  assert.equal(pass.eventTitle, 'Deleted Workshop');
  assert.equal(pass.eventDate, '14 November 2026');
  assert.equal(pass.venue, 'Lab 4');
  const cells = D.registrationCsvRow(row, null);
  assert.equal(cells[1], 'Deleted Workshop');
  assert.equal(cells[9], '2026-10-09 08:30');
  assert.equal(cells[14], '14 November 2026');
  assert.equal(cells[15], 'Lab 4');
});

test('Public snapshot hides registrations and submissions, strips volunteer contacts and reports seats', () => {
  const db = D.normalizeDb({
    site: { clubName: 'Mindful Tattva' },
    team: [
      { id: 't1', name: 'Tanisha', role: 'President', group: 'management', phone: '+917046075606', email: 'tanisha@gmail.com', bio: 'Leads.' },
      { id: 't2', name: 'Aman', role: 'Volunteer', group: 'volunteers', phone: '+919898011223', email: 'aman@gmail.com', bio: 'Private contribution text' }
    ],
    events: [
      { id: 'e1', title: 'Open', date: '24 October 2026', isoDate: '2026-10-24', published: true, capacity: 2, scope: 'interdepartmental' },
      { id: 'e2', title: 'Past', date: '1 September 2026', isoDate: '2026-09-01', published: true, scope: 'departmental' }
    ],
    registrations: [{ id: 'r1', eventId: 'e1', serial: 'MT-2026-000002', email: 'x@gmail.com', phone: '9812300456', createdAt: '2026-10-09T00:00:00Z' }],
    submissions: [{ id: 's1', type: 'volunteer', email: 'aman@gmail.com' }],
    gallery: [],
    history: []
  });
  const snapshot = D.publicSnapshot(db, new Date('2026-10-09T04:00:00Z'));
  assert.equal('registrations' in snapshot, false);
  assert.equal('submissions' in snapshot, false);
  const volunteer = snapshot.team.find(member => member.name === 'Aman');
  assert.equal(volunteer.email, '');
  assert.equal(volunteer.bio, '');
  const tanisha = snapshot.team.find(member => member.name === 'Tanisha');
  assert.equal(tanisha.email, 'tanisha@gmail.com');
  const open = snapshot.events.find(event => event.id === 'e1');
  assert.deepEqual(open.seats, { filled: 1, capacity: 2, open: 1, full: false });
  assert.equal(open.registrationOpen, true);
  assert.equal(snapshot.events.find(event => event.id === 'e2').registrationOpen, false);
  assert.equal(snapshot.today, '2026-10-09');
});

test('Stored data is migrated without dropping existing records', () => {
  const db = D.normalizeDb({
    team: [{ id: 'team-mohd', name: 'Mohd Shafiq', role: 'Vice President', group: 'management', phone: '+918104553395', image: 'data:image/jpeg;base64,AAAA' }],
    events: [{ id: 'event-welcome-circle', title: 'Welcome', date: '24 October 2026', published: true, location: 'Seminar Hall', kicker: 'Club gathering' }],
    gallery: [{ id: 'g1', caption: 'Logo', image: 'data:image/jpeg;base64,BBBB' }]
  });
  const mohd = db.team[0];
  assert.equal(mohd.image, 'data:image/jpeg;base64,AAAA');
  assert.equal(mohd.groupLabel, 'Core Committee');
  assert.equal(mohd.showOnHome, true);
  assert.equal(db.events[0].scope, 'interdepartmental');
  assert.equal(db.events[0].category, 'Club gathering');
  assert.equal(db.events[0].feeType, 'free');
  assert.equal(db.events[0].capacity, null);
  assert.equal(db.events[0].location, 'Seminar Hall');
  assert.equal(db.gallery[0].title, 'Logo');
  assert.deepEqual(db.registrations, []);
  assert.deepEqual(db.submissions, []);
});

test('Export rows carry serial, scope, phone and registration time in India time', () => {
  const row = {
    serial: 'MT-2026-892415', eventId: 'e1', eventScope: 'interdepartmental', formScope: 'departmental', passType: 'event',
    name: 'Ravi Kumar', email: 'ravi@gmail.com', phone: '7045512345', college: D.UNIVERSITY_NAME, department: D.DEPARTMENT_NAME,
    rollNo: 'CSMU-22-091', yearOrSemester: 'Semester 3', feeType: 'free', fee: 0, createdAt: '2026-10-09T02:30:00.000Z'
  };
  const cells = D.registrationCsvRow(row, { title: 'Welcome Circle', date: '24 October 2026', location: 'Seminar Hall' });
  assert.equal(cells[0], 'MT-2026-892415');
  assert.equal(cells[2], 'Interdepartmental');
  assert.equal(cells[5], '7045512345');
  assert.equal(cells[9], '2026-10-09 08:00');
  assert.equal(cells[10], 'Single event');
  assert.equal(cells[11], 'Departmental');
  assert.equal(D.REGISTRATION_CSV_HEADERS.length, cells.length);
});
