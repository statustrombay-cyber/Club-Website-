#!/usr/bin/env python3
"""
End-to-end checks for the Mindful Tattva website.

Starts a fresh server on a free port with a temporary copy of data/site.json, seeds a few events and members
through the API, then drives Chromium through the public pages and the Content Studio.
Exit code is 0 only when every check passes.

Run:  python3 tests/e2e/run_e2e.py        (needs: pip install playwright, and `playwright install chromium`)
"""
import base64
import json
import os
import re
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zlib
from pathlib import Path

from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parents[2]
ARTIFACTS = Path(os.environ.get('MT_E2E_ARTIFACTS', ROOT / '.work' / 'e2e'))
CREDIT = 'Made with love by Mohd Shafiq · Vice President'
ADMIN_PASSWORD = os.environ.get('MT_ADMIN_PASSWORD', 'Csmu@MT')
RESULTS = []


def check(name, ok, detail=''):
    RESULTS.append((bool(ok), name))
    print(('PASS  ' if ok else 'FAIL  ') + name + ('' if ok or not detail else f'  -> {detail}'), flush=True)
    return bool(ok)


def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def wait_for_port(port, timeout=25):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(('127.0.0.1', port), timeout=0.5):
                return
        except OSError:
            time.sleep(0.2)
    raise RuntimeError('server did not start in time')


def api(base, method, path, body=None, token=None):
    data = json.dumps(body).encode() if body is not None else None
    request = urllib.request.Request(base + path, data=data, method=method)
    request.add_header('Content-Type', 'application/json')
    if token:
        request.add_header('Authorization', f'Bearer {token}')
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            raw = response.read()
            return response.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as error:
        raw = error.read()
        try:
            return error.code, json.loads(raw)
        except ValueError:
            return error.code, raw.decode(errors='replace')


def make_png(width, height, rgb):
    raw = b''.join(b'\x00' + bytes(rgb) * width for _ in range(height))

    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xFFFFFFFF)

    header = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', header) + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b'')


def png_size(path):
    data = Path(path).read_bytes()
    if data[:8] != b'\x89PNG\r\n\x1a\n':
        return None
    return struct.unpack('>II', data[16:24])


PDF_TEXT = b"""%PDF-1.4
1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj
2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj
3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 200 200]>>endobj
trailer<</Root 1 0 R>>
%%EOF
"""


def main():
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    workdir = Path(tempfile.mkdtemp(prefix='mt-e2e-'))
    data_copy = workdir / 'site.json'
    shutil.copy(ROOT / 'data' / 'site.json', data_copy)
    port = free_port()
    base = f'http://127.0.0.1:{port}'
    env = dict(os.environ, PORT=str(port), MT_DATA_FILE=str(data_copy), MT_RATE_LIMIT='0')
    server_log = open(workdir / 'server.log', 'w')
    server = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=env, stdout=server_log, stderr=subprocess.STDOUT)
    png_path = workdir / 'photo.png'
    png_path.write_bytes(make_png(96, 96, (214, 162, 70)))
    pdf_data = 'data:application/pdf;base64,' + base64.b64encode(PDF_TEXT).decode()
    photo_data = 'data:image/png;base64,' + base64.b64encode(png_path.read_bytes()).decode()
    try:
        wait_for_port(port)
        run_suite(base, workdir, pdf_data, photo_data, png_path)
    finally:
        server.terminate()
        try:
            server.wait(timeout=5)
        except subprocess.TimeoutExpired:
            server.kill()
        server_log.close()
        shutil.rmtree(workdir, ignore_errors=True)

    failed = [name for ok, name in RESULTS if not ok]
    print(f'\n{len(RESULTS) - len(failed)} passed, {len(failed)} failed')
    if failed:
        for name in failed:
            print('  failed:', name)
        sys.exit(1)


def run_suite(base, workdir, pdf_data, photo_data, png_path):
    # ----- seed data through the API (also proves the admin login and the content endpoints) -----
    status, session = api(base, 'POST', '/api/admin/login', {'password': 'wrong-password'})
    check('admin login rejects a wrong password', status == 401 and 'error' in session, f'{status} {session}')
    status, login = api(base, 'POST', '/api/admin/login', {'password': ADMIN_PASSWORD})
    check('admin login accepts the Studio password', status == 200 and len(login.get('token', '')) == 64)
    token = login['token']

    seeds = {}
    status, seeds['breath'] = api(base, 'POST', '/api/events', {
        'title': 'Breath & Balance Workshop', 'scope': 'interdepartmental', 'category': 'Workshop',
        'day': '14', 'month': '10', 'year': '2026', 'time': '2:00 PM', 'location': 'CSMU campus · Psychology Lab',
        'instructor': 'Dr. Meera Iyer', 'feeType': 'paid', 'fee': 250, 'capacity': 2,
        'description': 'A guided breath and body-awareness workshop for students.', 'published': True,
        'attachment': pdf_data, 'attachmentName': 'breath-balance.pdf'}, token)
    check('admin creates a paid, capped event with a PDF brochure', status == 201 and seeds['breath'].get('attachment', '').startswith('data:application/pdf'), f'{status}')
    status, seeds['walk'] = api(base, 'POST', '/api/events', {
        'title': 'Campus Walk & Talk', 'scope': 'intercollege', 'category': 'Talk', 'day': '5', 'month': '11', 'year': '2026',
        'time': '7:00 AM', 'location': 'Panvel campus lawn', 'instructor': 'Prof. Arjun Deshmukh', 'feeType': 'free',
        'published': True}, token)
    status, seeds['dept'] = api(base, 'POST', '/api/events', {
        'title': 'Department Circle: Focus & Flow', 'scope': 'departmental', 'category': 'Wellbeing', 'day': '10', 'month': '11',
        'year': '2026', 'time': '3:00 PM', 'location': 'Seminar Hall 2', 'instructor': 'Dr. Ritu Sen', 'feeType': 'free',
        'published': True}, token)
    check('admin creates a departmental event', status == 201 and seeds['dept'].get('scope') == 'departmental', f'{status}')
    status, seeds['past'] = api(base, 'POST', '/api/events', {
        'title': 'Department Circle: Stress & Sleep', 'scope': 'departmental', 'category': 'Wellbeing', 'day': '20', 'month': '8',
        'year': '2026', 'time': '11:00 AM', 'location': 'Seminar Hall 2', 'instructor': 'Dr. Ritu Sen', 'feeType': 'free',
        'published': True}, token)
    status, riya = api(base, 'POST', '/api/team', {
        'name': 'Riya Kapoor', 'role': 'Head · Design', 'group': 'heads', 'phone': '8452019376',
        'email': 'riya.kapoor@gmail.com', 'bio': 'Leads the poster and social design team.', 'image': photo_data,
        'showOnHome': False}, token)
    check('admin adds a Head Committee member with a photo', status == 201 and riya.get('image', '').startswith('data:image/png'), f'{status} {riya}')
    status, bad = api(base, 'POST', '/api/team', {'name': 'Bad Phone', 'role': 'Head', 'group': 'heads', 'phone': '12345'}, token)
    check('admin member save rejects a non-Indian phone number', status == 400 and 'phone' in (bad.get('fields') or {}), f'{status} {bad}')
    status, _ = api(base, 'PUT', '/api/site', {'instagramHandle': '@mindful_tattva'})
    check('public write without a session is refused (401)', status == 401, f'{status}')

    # ----- public pages: load, footer, ticker, overflow, no page errors -----
    pages = ['/', '/members.html', '/gallery.html', '/calendar.html', '/events.html']
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch()

        def new_page(width=1280, height=900, downloads=True):
            context = browser.new_context(viewport={'width': width, 'height': height}, accept_downloads=downloads)
            # Test-only: the site scrolls smoothly, which can make automated clicks land before the target is in place.
            context.add_init_script("document.addEventListener('DOMContentLoaded', () => { const s = document.createElement('style'); s.textContent = 'html{scroll-behavior:auto !important}'; document.documentElement.appendChild(s); });")
            page = context.new_page()
            page.errors = []
            page.on('pageerror', lambda exc: page.errors.append(str(exc)))
            page.on('console', lambda msg: page.errors.append(msg.text) if msg.type == 'error' else None)
            return context, page

        for path in pages:
            context, page = new_page()
            page.goto(base + path, wait_until='load')
            page.wait_for_selector('[data-ticker-title]', timeout=8000)
            page.wait_for_timeout(400)
            tail = page.evaluate("() => document.body.innerText.trim().split('\\n').pop()")
            check(f'{path} loads without script errors', not page.errors, '; '.join(page.errors[:3]))
            check(f'{path} ends with the footer credit and no stray text', tail.replace('♥', '').strip() == CREDIT, repr(tail))
            check(f'{path} shows the next-event ticker', page.locator('[data-ticker-title]').inner_text().strip() != '')
            check(f'{path} shows live status', 'Live updates' in page.locator('[data-live-status]').first.inner_text())
            context.close()

        # footer heart: soft peach on dark footers, not red
        context, page = new_page()
        page.goto(base + '/', wait_until='load')
        page.wait_for_selector('.credit-heart')
        colour = page.evaluate("() => getComputedStyle(document.querySelector('.credit-heart')).color")
        check('footer heart is soft peach, not red', colour == 'rgb(244, 193, 127)', colour)
        check('homepage shows the Core-only team (two cards, Head Committee hidden)', page.locator('#teamGrid .team-card').count() == 2)
        mt = page.locator('#teamGrid .team-card', has_text='Tanisha').locator('.team-avatar')
        check('President without a photo shows the MT placeholder', mt.inner_text().strip() == 'MT')
        check('Vice President keeps the uploaded photo', page.locator('#teamGrid .team-card', has_text='Mohd Shafiq').locator('.team-avatar.has-image').count() == 1)
        check('homepage event grid lists upcoming events (past event hidden)', page.locator('#eventGrid .mt-event').count() == 3, str(page.locator('#eventGrid .mt-event').count()))
        check('homepage gallery shows saved photos', page.locator('#galleryGrid .gallery-item').count() == 4)
        page.click('#volunteerForm button[type="submit"]')
        status_text = page.locator('#volunteerForm .form-status').inner_text()
        check('volunteer form blocks an empty submission with a message', 'name' in status_text.lower() or 'mobile' in status_text.lower() or 'email' in status_text.lower(), status_text)
        page.fill('#volunteerForm input[name="name"]', 'Aman Verma')
        page.fill('#volunteerForm input[name="email"]', 'aman.verma@gmail.com')
        page.fill('#volunteerForm input[name="phone"]', '9898011223')
        page.fill('#volunteerForm textarea[name="contribution"]', 'Too short')
        page.click('#volunteerForm button[type="submit"]')
        check('volunteer contribution must be at least 30 characters', 'at least 30' in page.locator('#volunteerForm .form-status').inner_text())
        page.fill('#volunteerForm textarea[name="contribution"]', 'I can design posters, run Instagram stories and help host welcome circles for new members.')
        page.click('#volunteerForm button[type="submit"]')
        page.wait_for_function("() => /Thank you/.test(document.querySelector('#volunteerForm .form-status').textContent)", timeout=8000)
        check('volunteer success message appears only after the server confirms', True)
        check('volunteer application is remembered on this device', 'sent from this device' in page.locator('#volunteerHistory').inner_text())
        context.close()

        # ----- registration modal on the homepage -----
        context, page = new_page()
        page.goto(base + '/', wait_until='load')
        page.wait_for_selector('#eventGrid .mt-event')
        page.click('.hero button[data-mt-open="register"]')
        modal = page.locator('.mt-modal:not([hidden])')
        expect(modal).to_be_visible()
        breath_id = seeds['breath']['id']
        walk_id = seeds['walk']['id']
        dept_id = seeds['dept']['id']
        page.select_option('.mt-modal select[name="target"]', breath_id)
        check('interdepartmental form asks for department, roll number and year',
              page.locator('.mt-modal input[name="department"]').count() == 1 and page.locator('.mt-modal input[name="rollNo"]').count() == 1 and page.locator('.mt-modal select[name="year"]').count() == 1)
        facts = page.locator('.mt-modal .mt-event-facts').inner_text()
        check('event facts show the fee and live seats', 'pay at the desk' in facts.lower() and '0 / 2 Seats Filled' in facts, facts[:200])
        page.fill('.mt-modal input[name="name"]', 'Asha Rao')
        page.fill('.mt-modal input[name="email"]', 'asha@mailinator.com')
        page.fill('.mt-modal input[name="phone"]', '9999999999')
        page.fill('.mt-modal input[name="department"]', 'B.A. Psychology')
        page.fill('.mt-modal input[name="rollNo"]', 'CSMU2024044')
        page.select_option('.mt-modal select[name="year"]', '2nd Year')
        page.click('.mt-modal button[data-submit]')
        check('disposable email domains are rejected in the form', 'Placeholder and temporary email' in page.locator('[data-error-for="email"]').inner_text())
        check('repeated-digit mobile numbers are rejected in the form', 'placeholder number' in page.locator('[data-error-for="phone"]').inner_text())
        page.fill('.mt-modal input[name="email"]', 'asha.rao@gmail.com')
        page.fill('.mt-modal input[name="phone"]', '9812300456')
        page.click('.mt-modal button[data-submit]')
        page.wait_for_selector('.mt-modal .mt-pass', timeout=8000)
        serial = page.locator('.mt-modal .mt-pass-serial').inner_text().strip()
        check('registration issues a serial in the MT-YYYY-NNNNNN format', re.fullmatch(r'MT-2026-\d{6}', serial) is not None, serial)
        pass_text = page.locator('.mt-modal .mt-pass').inner_text()
        check('pass shows name, college, roll number, event, venue and fee status',
              all(text in pass_text for text in ['Asha Rao', 'Chhatrapati Shivaji Maharaj University', 'CSMU2024044', 'Breath & Balance Workshop', 'CSMU campus · Psychology Lab', 'Pending']), pass_text[:300])
        with page.expect_download() as download_info:
            page.click('.mt-modal button[data-pass-download]')
        download = download_info.value
        target = workdir / 'pass.png'
        download.save_as(str(target))
        size = png_size(target)
        check('PNG pass downloads at high resolution (1600 px wide)', size is not None and size[0] == 1600 and size[1] >= 1000, str(size))
        check('pass file is named after its serial', download.suggested_filename == f'MT-pass-{serial}.png', download.suggested_filename)
        shutil.copy(target, ARTIFACTS / 'pass-breath.png')
        page.keyboard.press('Escape')
        expect(page.locator('.mt-modal')).to_be_hidden()

        # duplicate: same event, same email (different case) and phone in a different format
        page.click('.hero button[data-mt-open="register"]')
        page.select_option('.mt-modal select[name="target"]', breath_id)
        page.fill('.mt-modal input[name="name"]', 'Asha R.')
        page.fill('.mt-modal input[name="email"]', 'ASHA.RAO@gmail.com')
        page.fill('.mt-modal input[name="phone"]', '+91 98123 00456')
        page.fill('.mt-modal input[name="department"]', 'B.A. Psychology')
        page.fill('.mt-modal input[name="rollNo"]', 'CSMU2024044')
        page.select_option('.mt-modal select[name="year"]', '2nd Year')
        page.click('.mt-modal button[data-submit]')
        page.wait_for_selector('.mt-modal .mt-pass', timeout=8000)
        check('duplicate registration shows the existing serial instead of a new pass',
              page.locator('.mt-modal .mt-pass-serial').inner_text().strip() == serial and 'already registered' in page.locator('.mt-modal').inner_text().lower())
        page.keyboard.press('Escape')

        # live roster inside the modal
        page.click('.hero button[data-mt-open="register"]')
        page.select_option('.mt-modal select[name="target"]', breath_id)
        page.click('.mt-modal [data-roster-toggle]')
        page.wait_for_selector('.mt-modal .mt-roster-list li', timeout=8000)
        check('live roster toggle inside the modal lists participants and serials',
              'Asha Rao' in page.locator('.mt-modal .mt-roster-list').inner_text() and serial in page.locator('.mt-modal .mt-roster-list').inner_text())
        page.keyboard.press('Escape')

        # my passes survive a reload (localStorage)
        page.reload(wait_until='load')
        page.wait_for_selector('#eventGrid .mt-event')
        stored = page.evaluate("() => JSON.parse(localStorage.getItem('mt-my-passes-v1') || '[]').map(item => item.serial)")
        check('issued passes are kept in localStorage for this device', serial in stored, str(stored))
        page.click('.mt-home-register button[data-mt-open="lookup"]')
        page.fill('.mt-modal input[name="email"]', 'asha.rao@gmail.com')
        page.fill('.mt-modal input[name="phone"]', '9812300456')
        page.click('.mt-modal button[type="submit"]')
        page.wait_for_selector('.mt-modal [data-lookup-results] .mt-pass', timeout=8000)
        check('find-my-pass returns the pass for the registered details', serial in page.locator('.mt-modal [data-lookup-results]').inner_text())
        page.keyboard.press('Escape')

        # ----- departmental event: department locked to DASS, CSMU roll number and semester required -----
        page.click('.mt-home-register button[data-mt-open="register"]')
        page.select_option('.mt-modal select[name="target"]', dept_id)
        check('departmental scope locks the department to DASS',
              'Department of Applied Social Sciences' in page.locator('.mt-modal .mt-locked').inner_text() and page.locator('.mt-modal input[name="department"]').count() == 0)
        check('departmental scope asks for CSMU roll number and semester',
              page.locator('.mt-modal input[name="rollNo"]').count() == 1 and page.locator('.mt-modal select[name="semester"]').count() == 1)
        page.fill('.mt-modal input[name="name"]', 'Ravi Kumar')
        page.fill('.mt-modal input[name="email"]', 'ravi.kumar@gmail.com')
        page.fill('.mt-modal input[name="phone"]', '7045512345')
        page.fill('.mt-modal input[name="rollNo"]', 'CSMU-22-091')
        page.select_option('.mt-modal select[name="semester"]', 'Semester 3')
        page.click('.mt-modal button[data-submit]')
        page.wait_for_selector('.mt-modal .mt-pass', timeout=8000)
        check('departmental registration issues a pass with the department locked on it',
              'Department of Applied Social Sciences' in page.locator('.mt-modal .mt-pass').inner_text())
        dept_serial = page.locator('.mt-modal .mt-pass-serial').inner_text().strip()
        check('the pass covers the one event it was issued for',
              'Department Circle: Focus & Flow' in page.locator('.mt-modal .mt-pass').inner_text() and page.locator('.mt-modal .mt-pass-events').count() == 0)
        page.keyboard.press('Escape')

        # ----- intercollege event: a separate registration with its own serial -----
        page.click('.mt-home-register button[data-mt-open="register"]')
        page.select_option('.mt-modal select[name="target"]', walk_id)
        check('intercollege form asks for the external college, PRN and department/stream',
              all(page.locator(f'.mt-modal input[name="{name}"]').count() == 1 for name in ['college', 'rollNo', 'department']))
        page.fill('.mt-modal input[name="name"]', 'Neha Patel')
        page.fill('.mt-modal input[name="email"]', 'neha.patel@gmail.com')
        page.fill('.mt-modal input[name="phone"]', '9833174526')
        page.fill('.mt-modal input[name="college"]', 'Ramnarain Ruia College')
        page.fill('.mt-modal input[name="rollNo"]', 'PRN-2026-77')
        page.fill('.mt-modal input[name="department"]', 'B.A. Psychology')
        page.click('.mt-modal button[data-submit]')
        page.wait_for_selector('.mt-modal .mt-pass', timeout=8000)
        walk_text = page.locator('.mt-modal .mt-pass').inner_text()
        check('the intercollege pass carries the external college and the walk event',
              'Ramnarain Ruia College' in walk_text and 'Campus Walk & Talk' in walk_text, walk_text[:200])
        walk_serial = page.locator('.mt-modal .mt-pass-serial').inner_text().strip()
        check('each registration gets its own serial number', walk_serial != serial, f'{serial} / {walk_serial}')
        page.keyboard.press('Escape')

        # ----- there is no season pass anywhere on the public site -----
        check('no Season Pass button is left on the page', page.locator('[data-mt-open="season"]').count() == 0)
        page.click('.hero button[data-mt-open="register"]')
        options_text = ' '.join(page.locator('.mt-modal select[name="target"] option').all_inner_texts())
        check('the registration dropdown offers single events only', 'Season Pass' not in options_text and page.locator('.mt-modal select[name="category"]').count() == 0, options_text[:160])
        page.keyboard.press('Escape')

        # ----- capacity: Breath & Balance has 2 seats; Asha holds one of them -----
        # A second visitor opens the form for the workshop before the last seat is taken...
        karan_context, karan_page = new_page()
        karan_page.goto(base + '/', wait_until='load')
        karan_page.wait_for_selector('#eventGrid .mt-event')
        karan_page.click(f'[data-register="{breath_id}"]')
        karan_page.select_option('.mt-modal select[name="target"]', breath_id)
        karan_page.fill('.mt-modal input[name="name"]', 'Karan Shah')
        karan_page.fill('.mt-modal input[name="email"]', 'karan.shah@gmail.com')
        karan_page.fill('.mt-modal input[name="phone"]', '7700112233')
        karan_page.fill('.mt-modal input[name="department"]', 'B.Com')
        karan_page.fill('.mt-modal input[name="rollNo"]', 'CSMU2024777')
        karan_page.select_option('.mt-modal select[name="year"]', '3rd Year')
        # ...meanwhile the last seat is taken by Meera on another page
        page.reload(wait_until='load')
        page.wait_for_selector('#eventGrid .mt-event')
        page.click(f'[data-register="{breath_id}"]')
        page.fill('.mt-modal input[name="name"]', 'Meera Nair')
        page.fill('.mt-modal input[name="email"]', 'meera.nair@gmail.com')
        page.fill('.mt-modal input[name="phone"]', '9650214387')
        page.fill('.mt-modal input[name="department"]', 'M.A. Psychology')
        page.fill('.mt-modal input[name="rollNo"]', 'CSMU2025003')
        page.select_option('.mt-modal select[name="year"]', '1st Year')
        page.click('.mt-modal button[data-submit]')
        page.wait_for_selector('.mt-modal .mt-pass', timeout=8000)
        page.keyboard.press('Escape')
        # ...so the server, not the stale form, must refuse Karan's registration
        karan_page.click('.mt-modal button[data-submit]')
        karan_page.wait_for_function("() => /full/i.test(document.querySelector('.mt-modal [data-alert]').textContent)", timeout=8000)
        refusal = karan_page.locator('.mt-modal [data-alert]').inner_text()
        check('server refuses a registration once the event is full, with a clear message', 'full' in refusal.lower() and karan_page.locator('.mt-modal .mt-pass').count() == 0, refusal)
        karan_context.close()
        page.reload(wait_until='load')
        page.wait_for_selector('#eventGrid .mt-event')
        check('event card shows the seat tracker "2 / 2 Seats Filled"', '2 / 2 Seats Filled' in page.locator(f'.mt-event[data-event-id="{breath_id}"]').inner_text())
        check('full event card replaces the register button with "Event full"', page.locator(f'.mt-event[data-event-id="{breath_id}"] button', has_text='Event full').count() == 1)
        context.close()

        # ----- events page: search, filters, past events, brochure -----
        context, page = new_page()
        page.goto(base + '/events.html', wait_until='load')
        page.wait_for_selector('#eventResults .mt-event')
        total = page.locator('#eventResults .mt-event').count()
        check('events page lists upcoming events by default', total == 4, str(total))
        page.fill('#filterKeyword', 'breath')
        check('keyword search narrows the list', page.locator('#eventResults .mt-event').count() == 1)
        page.fill('#filterKeyword', 'zzz-nothing')
        check('empty search shows a helpful message', 'No events match' in page.locator('#eventResults').inner_text())
        page.click('[data-clear-filters]')
        page.select_option('#filterInstructor', 'Dr. Meera Iyer')
        check('instructor filter works', page.locator('#eventResults .mt-event').count() == 1)
        page.select_option('#filterInstructor', '')
        page.select_option('#filterScope', 'intercollege')
        check('scope filter works', page.locator('#eventResults .mt-event').count() == 1 and 'Campus Walk' in page.locator('#eventResults').inner_text())
        page.select_option('#filterScope', '')
        page.select_option('#filterVenue', 'Panvel campus lawn')
        check('venue filter works', page.locator('#eventResults .mt-event').count() == 1)
        page.select_option('#filterVenue', '')
        page.check('#filterPast')
        check('include-past shows the finished event too', page.locator('#eventResults .mt-event').count() == 5)
        page.uncheck('#filterPast')
        card = page.locator(f'.mt-event[data-event-id="{breath_id}"]')
        check('paid event shows its fee on the card', '₹250' in card.inner_text())
        check('brochure button appears when a PDF is attached', card.locator('a', has_text='Brochure (PDF)').count() == 1)
        walk_card = page.locator(f'.mt-event[data-event-id="{walk_id}"]')
        check('no brochure button when none is attached', walk_card.locator('a', has_text='Brochure').count() == 0)
        page.screenshot(path=str(ARTIFACTS / 'events-desktop.png'), full_page=False)
        context.close()

        # ----- calendar -----
        context, page = new_page()
        page.goto(base + '/calendar.html', wait_until='load')
        page.wait_for_selector('#monthGrid .month')
        check('calendar shows twelve month cards', page.locator('#monthGrid .month').count() == 12)
        check('calendar marks months with activities', page.locator('#monthGrid .month.has-event').count() == 4, str(page.locator('#monthGrid .month.has-event').count()))
        check('calendar places the November workshop in November', 'Breath & Balance' in page.locator('#monthGrid .month', has_text='November').inner_text())
        page.click('#yearNext')
        check('calendar year navigation shows an empty next year', 'No activities planned yet' in page.locator('#monthGrid .month').first.inner_text())
        page.click('#yearPrev')
        context.close()

        # ----- members directory -----
        context, page = new_page()
        page.goto(base + '/members.html', wait_until='load')
        page.wait_for_selector('#memberGroups .member-group')
        groups = page.locator('#memberGroups .member-group').count()
        check('members page shows exactly the three fixed groups', groups == 3, str(groups))
        check('core card without a photo shows the MT placeholder', page.locator('.member-card', has_text='Tanisha').locator('.member-photo-placeholder').inner_text().strip() == 'MT')
        riya_card = page.locator('.member-card', has_text='Riya Kapoor')
        check('head member photo renders from the saved record', 'background-image' in (riya_card.locator('.member-photo').get_attribute('style') or ''))
        check('officers get clickable tel and mailto links', riya_card.locator('a[href^="tel:+91"]').count() == 1 and riya_card.locator('a[href^="mailto:"]').count() == 1)
        page.click('#memberFilters [data-filter="heads"]')
        check('filter chips show one group at a time', page.locator('#memberGroups .member-group:not([hidden])').count() == 1)
        page.click('#memberFilters [data-filter="all"]')
        page.screenshot(path=str(ARTIFACTS / 'members-desktop.png'), full_page=False)
        context.close()

        # ----- gallery -----
        context, page = new_page()
        page.goto(base + '/gallery.html', wait_until='load')
        page.wait_for_selector('#archiveGrid .archive-card')
        check('gallery archive lists every saved photo', page.locator('#archiveGrid .archive-card').count() == 4)
        first = page.locator('#galleryCounter').inner_text()
        page.click('#galleryNext')
        check('gallery slider advances to the next photo', page.locator('#galleryCounter').inner_text() != first, f'{first} -> {page.locator("#galleryCounter").inner_text()}')
        context.close()

        # ----- mobile: no horizontal overflow, drawer with quick access -----
        context, page = new_page(width=390, height=844)
        for path in pages:
            page.goto(base + path, wait_until='load')
            page.wait_for_selector('[data-ticker-title]')
            overflow = page.evaluate('() => document.documentElement.scrollWidth - window.innerWidth')
            check(f'{path} has no horizontal scrolling on a phone', overflow <= 1, f'overflow {overflow}px')
        page.goto(base + '/', wait_until='load')
        page.wait_for_selector('#menuButton')
        page.click('#menuButton')
        expect(page.locator('#mtDrawer')).to_be_visible()
        drawer_text = page.locator('#mtDrawer').inner_text()
        check('drawer offers registration tools and contacts', all(word in drawer_text for word in ['Register for an event', 'Find my pass', 'My passes on this device', 'Campus map', 'Instagram']))
        check('drawer has no Season Pass entry', 'Season Pass' not in drawer_text)
        map_href = page.locator('#mtDrawer a', has_text='Campus map').get_attribute('href')
        check('campus map link points at the CSMU Panvel campus', 'maps' in map_href and 'Chhatrapati' in map_href and '410206' in map_href, map_href)
        page.screenshot(path=str(ARTIFACTS / 'drawer-mobile.png'), full_page=False)
        page.keyboard.press('Escape')
        page.wait_for_timeout(450)
        check('Escape closes the drawer', page.locator('#mtDrawer').is_hidden() or not page.locator('#mtDrawer').is_visible())
        page.goto(base + '/events.html', wait_until='load')
        page.wait_for_selector('#eventResults .mt-event')
        page.screenshot(path=str(ARTIFACTS / 'events-mobile.png'), full_page=False)
        context.close()

        # ----- Content Studio -----
        context, page = new_page()
        page.goto(base + '/admin.html', wait_until='load')
        expect(page.locator('#loginGate')).to_be_visible()
        page_text = page.locator('#loginGate').inner_text().lower()
        check('studio login gives no password hint', 'hint' not in page_text and 'csmu' not in page_text)
        page.fill('#loginForm input[name="password"]', 'not-the-password')
        page.click('#loginForm button[type="submit"]')
        expect(page.locator('#loginError')).to_contain_text('does not match')
        check('wrong studio password is refused', 'does not match' in page.locator('#loginError').inner_text())
        page.fill('#loginForm input[name="password"]', ADMIN_PASSWORD)
        page.click('#loginForm button[type="submit"]')
        expect(page.locator('#studio')).to_be_visible()
        page.wait_for_function("() => /Synced/.test(document.querySelector('#syncStatus').textContent)", timeout=10000)
        check('correct studio password opens the console', page.locator('#studio').is_visible())
        check('overview shows registration and seat totals', 'Registrations on record' in page.locator('#overviewStats').inner_text())

        # members: validation, photo upload, save, then public check
        page.click('#addMember')
        item = page.locator('#teamEditor article[data-id="new"]')
        item.locator('input[data-field="name"]').fill('Dev Joshi')
        item.locator('select[data-field="group"]').select_option('heads')
        item.locator('input[data-field="phone"]').fill('12345')
        item.locator('button[data-action="save-member"]').click()
        check('member editor rejects a short mobile number', 'mobile' in item.locator('[data-item-error]').inner_text().lower() or '10-digit' in item.locator('[data-item-error]').inner_text())
        item.locator('input[data-field="phone"]').fill('9432176850')
        item.locator('input[data-upload="image"]').set_input_files(str(png_path))
        expect(item.locator('[data-preview] img')).to_be_visible()
        check('member photo uploads via FileReader and previews', item.locator('[data-preview] img').count() == 1)
        item.locator('button[data-action="save-member"]').click()
        page.wait_for_function("() => document.querySelector('#saveMessage').textContent.includes('Dev Joshi is saved')", timeout=8000)
        status, team_now = api(base, 'GET', '/api/admin/team', token=token)
        dev = next((member for member in team_now if member['name'] == 'Dev Joshi'), None)
        check('saved member is stored in the Head Committee group with a photo', dev is not None and dev['group'] == 'heads' and dev['image'].startswith('data:image/'), str(dev and dev['group']))

        # events: create a free event with date/time, edit a field, delete with confirmation
        page.click('#addEvent')
        event_item = page.locator('#eventsEditor article[data-id="new"]')
        event_item.locator('input[data-field="title"]').fill('Mindful Sketch Night')
        event_item.locator('select[data-field="scope"]').select_option('departmental')
        event_item.locator('input[data-field="category"]').fill('Cultural')
        event_item.locator('select[data-field="day"]').select_option('3')
        event_item.locator('select[data-field="month"]').select_option('11')
        event_item.locator('input[data-field="year"]').fill('2026')
        event_item.locator('input[data-field="time"]').fill('18:30')
        event_item.locator('input[data-field="location"]').fill('Art room, CSMU campus')
        event_item.locator('button[data-action="save-event"]').click()
        page.wait_for_function("() => document.querySelector('#saveMessage').textContent.includes('Mindful Sketch Night is saved')", timeout=8000)
        created = api(base, 'GET', '/api/events')[1]
        sketch = next((event for event in created if event['title'] == 'Mindful Sketch Night'), None)
        check('event saved from the studio stores the date and 24-hour time as 6:30 PM', sketch is not None and sketch.get('time') == '6:30 PM' and sketch.get('date') == '3 December 2026', str(sketch and (sketch.get('time'), sketch.get('date'))))

        welcome = page.locator('#eventsEditor article[data-id="event-welcome-circle"]')
        welcome.locator('input[data-field="time"]').fill('16:30')
        welcome.locator('button[data-action="save-event"]').click()
        page.wait_for_function("() => document.querySelector('#saveMessage').textContent.includes('Mindful Tattva Welcome Circle is saved')", timeout=8000)
        status, site_now = api(base, 'GET', '/api/site')
        welcome_now = next(event for event in site_now['events'] if event['id'] == 'event-welcome-circle')
        check('editing an existing event time is saved and shown publicly', welcome_now.get('time') == '4:30 PM', str(welcome_now.get('time')))

        sketch_item = page.locator(f'#eventsEditor article[data-id="{sketch["id"]}"]')
        page.once('dialog', lambda dialog: dialog.accept())
        sketch_item.locator('button[data-action="delete-event"]').click()
        page.wait_for_function(f"() => !document.querySelector('#eventsEditor article[data-id=\"{sketch['id']}\"]')", timeout=8000)
        check('deleting an event asks for confirmation and removes it', True)

        # a booked event is deleted: its registrations stay on record, labelled as archived
        dept_item = page.locator(f'#eventsEditor article[data-id="{dept_id}"]')
        opened = {}

        def confirm_delete(dialog):
            opened['message'] = dialog.message
            dialog.accept()

        page.once('dialog', confirm_delete)
        dept_item.locator('button[data-action="delete-event"]').click()
        page.wait_for_function(f"() => !document.querySelector('#eventsEditor article[data-id=\"{dept_id}\"]')", timeout=8000)
        check('the delete confirmation tells the officer the registrations are kept',
              'stay on record' in opened.get('message', ''), opened.get('message', ''))
        page.wait_for_timeout(600)
        page.fill('#registrationSearch', 'Ravi Kumar')
        archived_rows = page.locator('#registrationTable tbody tr')
        archived_text = page.locator('#registrationTable tbody').inner_text()
        check('the registration survives its event and is marked Archived',
              dept_serial in archived_text and 'archived' in archived_text.lower(), archived_text[:200])
        check('the archived row keeps the deleted event name', 'Department Circle: Focus & Flow' in archived_text, archived_text[:200])
        page.fill('#registrationSearch', '')
        state, site_after_delete = api(base, 'GET', '/api/site')
        check('the deleted event is gone from the public site',
              all(event['id'] != dept_id for event in site_after_delete['events']),
              str([event['id'] for event in site_after_delete['events']]))
        state, passes_after_delete = api(base, 'POST', '/api/passes/lookup', {'email': 'ravi.kumar@gmail.com', 'phone': '7045512345'})
        kept = next((item for item in passes_after_delete['passes'] if item['serial'] == dept_serial), None)
        check('the pass holder can still find an archived pass', kept is not None and kept['archived'] is True and kept['eventTitle'] == 'Department Circle: Focus & Flow', str(kept and (kept['archived'], kept['eventTitle'])))
        page.wait_for_timeout(400)

        # registrations and CSV export
        expect(page.locator('#registrationTable tbody tr').first).to_be_visible()
        rows = page.locator('#registrationTable tbody tr').count()
        check('registrations table lists every registration', rows == 4, str(rows))
        with page.expect_download() as csv_info:
            page.click(f'[data-export-event="{breath_id}"]')
        csv_download = csv_info.value
        csv_path = workdir / 'breath.csv'
        csv_download.save_as(str(csv_path))
        csv_text = csv_path.read_text(encoding='utf-8-sig')
        header = csv_text.splitlines()[0]
        expected_header = ['Serial Number', 'Event Title', 'Scope', 'Name', 'Email', 'Phone', 'College Name', 'Department', 'Roll No/PRN', 'Registration Date']
        check('CSV export carries the required columns in order', all(column in header for column in expected_header) and header.startswith('Serial Number'), header[:160])
        check('CSV rows include the serial and participant', serial in csv_text and 'Asha Rao' in csv_text)
        check('CSV file name names the event', csv_download.suggested_filename.startswith('mindful-tattva-breath-balance-workshop'), csv_download.suggested_filename)
        with page.expect_download() as all_info:
            page.click('#exportAll')
        all_path = workdir / 'all.csv'
        all_info.value.save_as(str(all_path))
        all_text = all_path.read_text(encoding='utf-8-sig')
        check('master CSV export includes every registration, including archived ones', serial in all_text and dept_serial in all_text, f'{serial} / {dept_serial}')

        # volunteers: approve one, reject one
        status, reject_me = api(base, 'POST', '/api/submissions', {
            'type': 'volunteer', 'name': 'Test Reject', 'email': 'test.reject@gmail.com', 'phone': '7700998877',
            'contribution': 'This application exists only so that the reject button can be tested end to end.'})
        check('volunteer application API accepts a valid form', status == 201, f'{status} {reject_me}')
        page.reload(wait_until='load')
        expect(page.locator('#studio')).to_be_visible()
        page.wait_for_selector('#volunteerList .volunteer-card')
        aman = page.locator('#volunteerList .volunteer-card', has_text='Aman Verma')
        check('volunteer review shows the contribution answer', 'design posters' in aman.inner_text())
        aman.locator('[data-approve]').click()
        page.wait_for_function("() => document.querySelector('#saveMessage').textContent.includes('Approved.')", timeout=8000)
        check('approving a volunteer creates a live member profile', True)
        reject_card = page.locator('#volunteerList .volunteer-card', has_text='Test Reject')
        page.once('dialog', lambda dialog: dialog.accept())
        reject_card.locator('[data-reject]').click()
        page.wait_for_function("() => !/Test Reject/.test(document.querySelector('#volunteerList').textContent)", timeout=8000)
        check('rejecting a volunteer deletes the application', True)
        page.screenshot(path=str(ARTIFACTS / 'studio-registrations.png'), full_page=False)

        page.click('#signOut')
        expect(page.locator('#loginGate')).to_be_visible()
        check('signing out returns to the password gate', page.locator('#loginGate').is_visible())
        context.close()

        # public members page now shows the approved volunteer without their email
        context, page = new_page()
        page.goto(base + '/members.html', wait_until='load')
        page.wait_for_selector('#memberGroups .member-group')
        volunteer_card = page.locator('.member-card-volunteer', has_text='Aman Verma')
        check('approved volunteer shows on the public directory with name and phone only', volunteer_card.count() == 1 and volunteer_card.locator('.member-email').count() == 0 and volunteer_card.locator('a[href^="tel:"]').count() == 1)
        dev_card = page.locator('.member-card', has_text='Dev Joshi')
        check('new Head Committee member shows their uploaded photo on the members page', dev_card.count() == 1 and 'background-image' in (dev_card.locator('.member-photo').get_attribute('style') or ''))
        context.close()

        context, page = new_page()
        page.goto(base + '/', wait_until='load')
        page.wait_for_selector('#teamGrid .team-card')
        check('homepage Core-only filter ignores Head Committee members', page.locator('#teamGrid .team-card', has_text='Dev Joshi').count() == 0 and page.locator('#teamGrid .team-card').count() == 2)
        context.close()
        browser.close()

    # ----- API-level privacy and integrity checks -----
    status, site = api(base, 'GET', '/api/site')
    check('public site data never exposes registrations or volunteer submissions', 'registrations' not in site and 'submissions' not in site)
    volunteer_public = [m for m in site['team'] if m['group'] == 'volunteers']
    check('public volunteer records hide email and bio', all(not m.get('email') and not m.get('bio') for m in volunteer_public))
    status, _ = api(base, 'GET', '/api/admin/registrations')
    check('registration list is private (401 without a session)', status == 401, str(status))
    status, count = api(base, 'GET', '/api/admin/registrations', token=token)
    check('admin can read every registration with a valid session', status == 200 and len(count) == 4, str(len(count)) if status == 200 else str(status))


if __name__ == '__main__':
    main()
