'use strict';
// API tests: start a real server on a free port with a temporary copy of the data and exercise every endpoint.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const D = require('../../shared/domain.js');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const { spawn } = require('node:child_process');

const ROOT = path.join(__dirname, '..', '..');
const PASSWORD = 'Csmu@MT';
const PDF = 'data:application/pdf;base64,JVBERi0xLjQKJSVFT0YK';
const PNG = 'data:image/png;base64,iVBORw0KGgo=';

// A phone number that passes the Indian mobile rules, different for each seed.
function phoneFor(seed) {
  for (let k = seed; ; k += 1) {
    const digits = String(8000000000 + ((k * 2654435761) % 1999999999));
    if (D.normalizeIndianMobile(digits).ok) return digits;
  }
}

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.unref();
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      server.close(() => resolve(port));
    });
  });
}

async function startServer(env = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mt-api-'));
  const dataFile = path.join(dir, 'site.json');
  fs.copyFileSync(path.join(ROOT, 'data', 'site.json'), dataFile);
  const port = await freePort();
  const child = spawn(process.execPath, ['server.js'], {
    cwd: ROOT,
    env: { ...process.env, PORT: String(port), MT_DATA_FILE: dataFile, MT_RATE_LIMIT: '0', ...env },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let log = '';
  child.stdout.on('data', chunk => { log += chunk; });
  child.stderr.on('data', chunk => { log += chunk; });
  const base = `http://127.0.0.1:${port}`;
  const deadline = Date.now() + 15000;
  for (;;) {
    try {
      const response = await fetch(`${base}/api/site`);
      if (response.ok) break;
    } catch (_) { /* not up yet */ }
    if (Date.now() > deadline) throw new Error(`server did not start: ${log}`);
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  return {
    base,
    dataFile,
    async stop() {
      child.kill();
      await new Promise(resolve => child.once('exit', resolve));
      fs.rmSync(dir, { recursive: true, force: true });
    }
  };
}

async function call(base, method, route, body, token) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(base + route, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  const type = response.headers.get('content-type') || '';
  const payload = type.includes('json') ? await response.json() : await response.text();
  return { status: response.status, body: payload, headers: response.headers };
}

async function login(base, password = PASSWORD) {
  const result = await call(base, 'POST', '/api/admin/login', { password });
  return result.body.token;
}

const eventBase = {
  scope: 'interdepartmental', category: 'Workshop', day: '14', month: '10', year: '2026', time: '2:00 PM',
  location: 'CSMU campus · Psychology Lab', instructor: 'Dr. Meera Iyer', feeType: 'free', published: true
};

// ----- shared server for the functional tests -----
let server;
let token;
before(async () => {
  server = await startServer();
  token = await login(server.base);
});
after(async () => { if (server) await server.stop(); });

test('public site data exposes content but never registrations or submissions', async () => {
  const site = await call(server.base, 'GET', '/api/site');
  assert.equal(site.status, 200);
  for (const key of ['site', 'history', 'team', 'events', 'gallery', 'serverTime', 'today']) assert.ok(key in site.body, `missing ${key}`);
  assert.equal('registrations' in site.body, false);
  assert.equal('submissions' in site.body, false);
  assert.ok(site.body.team.some(member => member.name === 'Mohd Shafiq' && member.image.startsWith('data:image/')), 'Mohd Shafiq photo must be kept');
  assert.ok(site.body.team.some(member => member.name === 'Tanisha' && member.image === ''), 'Tanisha has no photo and stays listed');
});

test('admin writes need the Studio session; wrong passwords are refused', async () => {
  assert.equal((await call(server.base, 'POST', '/api/admin/login', { password: 'nope' })).status, 401);
  assert.equal((await call(server.base, 'PUT', '/api/site', { instagramHandle: '@x' })).status, 401);
  assert.equal((await call(server.base, 'POST', '/api/events', { title: 'x' })).status, 401);
  assert.equal((await call(server.base, 'DELETE', '/api/team/team-tanisha')).status, 401);
  assert.equal((await call(server.base, 'GET', '/api/admin/registrations')).status, 401);
  assert.equal((await call(server.base, 'GET', '/api/submissions')).status, 401);
  assert.equal((await call(server.base, 'GET', '/api/session')).body.authenticated, false);
  assert.equal((await call(server.base, 'GET', '/api/session', undefined, token)).body.authenticated, true);
  assert.equal((await call(server.base, 'GET', '/api/admin/team', undefined, token)).status, 200);
});

test('member validation: 10-digit Indian phone, real group, image-only photos', async () => {
  const badPhone = await call(server.base, 'POST', '/api/team', { name: 'Test Person', role: 'Head', group: 'heads', phone: '12345' }, token);
  assert.equal(badPhone.status, 400);
  assert.ok(badPhone.body.fields.phone);
  const badGroup = await call(server.base, 'POST', '/api/team', { name: 'Test Person', role: 'Head', group: 'boards', phone: '9812300456' }, token);
  assert.equal(badGroup.status, 400);
  const badPhoto = await call(server.base, 'POST', '/api/team', { name: 'Test Person', role: 'Head', group: 'heads', phone: '9812300456', image: 'javascript:alert(1)' }, token);
  assert.equal(badPhoto.status, 400);
  const good = await call(server.base, 'POST', '/api/team', { name: 'Riya Kapoor', role: 'Head · Design', group: 'heads', phone: '8452019376', email: 'riya.kapoor@gmail.com', image: PNG }, token);
  assert.equal(good.status, 201);
  assert.equal(good.body.phone, '+918452019376');
  const publicList = await call(server.base, 'GET', '/api/team');
  assert.ok(publicList.body.some(member => member.name === 'Riya Kapoor' && member.group === 'heads'));
  const removed = await call(server.base, 'DELETE', `/api/team/${good.body.id}`, undefined, token);
  assert.equal(removed.status, 200);
});

test('event validation: fees, capacity, dates, brochure type and links', async () => {
  const cases = [
    [{ ...eventBase, title: 'Fee', feeType: 'paid', fee: 0 }, 'fee'],
    [{ ...eventBase, title: 'Cap', capacity: 0 }, 'capacity'],
    [{ ...eventBase, title: 'Date', day: '31', month: '1' }, 'day'],
    [{ ...eventBase, title: 'Brochure', brochureUrl: 'http://example.org/a.pdf' }, 'brochureUrl'],
    [{ ...eventBase, title: 'Attach', attachment: PNG, attachmentName: 'x.png' }, 'attachment'],
    [{ ...eventBase, title: 'Scope', scope: 'everywhere' }, 'scope'],
    [{ ...eventBase, title: 'Venue', location: '' }, 'location']
  ];
  for (const [body, field] of cases) {
    const result = await call(server.base, 'POST', '/api/events', body, token);
    assert.equal(result.status, 400, `${body.title} should be refused`);
    assert.ok(result.body.fields && result.body.fields[field], `${body.title}: field ${field} expected, got ${JSON.stringify(result.body)}`);
  }
  const created = await call(server.base, 'POST', '/api/events', { ...eventBase, title: 'Paid And Capped', feeType: 'paid', fee: 250, capacity: 4, attachment: PDF, attachmentName: 'brochure.pdf' }, token);
  assert.equal(created.status, 201);
  assert.equal(created.body.date, '14 November 2026');
  assert.equal(created.body.time, '2:00 PM');
  assert.equal(created.body.attachmentName, 'brochure.pdf');
  const updated = await call(server.base, 'PUT', `/api/events/${created.body.id}`, { time: '3:30 PM', capacity: '' }, token);
  assert.equal(updated.status, 200);
  assert.equal(updated.body.time, '3:30 PM');
  assert.equal(updated.body.capacity, null);
  assert.equal(updated.body.fee, 250, 'untouched fields are kept on edit');
  const deleted = await call(server.base, 'DELETE', `/api/events/${created.body.id}`, undefined, token);
  assert.equal(deleted.status, 200);
});

test('site details: Instagram must be https and the club email must be valid', async () => {
  assert.equal((await call(server.base, 'PUT', '/api/site', { instagramUrl: 'http://instagram.com/x' }, token)).status, 400);
  assert.equal((await call(server.base, 'PUT', '/api/site', { email: 'me@test.com' }, token)).status, 400);
  const ok = await call(server.base, 'PUT', '/api/site', { instagramHandle: '@mindful_tattva', instagramUrl: 'https://www.instagram.com/mindful_tattva' }, token);
  assert.equal(ok.status, 200);
  assert.equal(ok.body.site.instagramHandle, '@mindful_tattva');
});

// Events used by the registration tests
let breath;
let walk;
let past;
let capped;
test('registration setup: create events through the Studio API', async () => {
  breath = (await call(server.base, 'POST', '/api/events', { ...eventBase, title: 'Breath & Balance Workshop', feeType: 'paid', fee: 250, capacity: 3, attachment: PDF, attachmentName: 'breath.pdf' }, token)).body;
  walk = (await call(server.base, 'POST', '/api/events', { ...eventBase, title: 'Campus Walk & Talk', scope: 'intercollege', day: '5', month: '11', location: 'Panvel campus lawn' }, token)).body;
  past = (await call(server.base, 'POST', '/api/events', { ...eventBase, title: 'Old Circle', scope: 'departmental', day: '20', month: '8' }, token)).body;
  capped = (await call(server.base, 'POST', '/api/events', { ...eventBase, title: 'Tiny Session', capacity: 1, day: '20', month: '11' }, token)).body;
  assert.ok(breath.id && walk.id && past.id && capped.id);
  const hidden = (await call(server.base, 'POST', '/api/events', { ...eventBase, title: 'Hidden', published: false }, token)).body;
  const unpublishedRegistration = await call(server.base, 'POST', '/api/registrations', { target: hidden.id, name: 'Asha Rao', email: 'asha.rao@gmail.com', phone: '9812300456', department: 'B.A.', rollNo: 'CS1', year: '1st Year' });
  assert.equal(unpublishedRegistration.status, 404, 'unpublished events are not open for registration');
});

test('single registration: validation, pass issue, duplicate detection by email or phone', async () => {
  const person = { target: breath.id, name: 'Asha Rao', email: 'asha.rao@gmail.com', phone: '9812300456', department: 'B.A. Psychology', rollNo: 'CSMU2024044', year: '2nd Year' };
  const disposable = await call(server.base, 'POST', '/api/registrations', { ...person, email: 'asha@mailinator.com' });
  assert.equal(disposable.status, 400);
  assert.ok(disposable.body.fields.email);
  const repeated = await call(server.base, 'POST', '/api/registrations', { ...person, phone: '9999999999' });
  assert.equal(repeated.status, 400);
  assert.ok(repeated.body.fields.phone);
  const missingYear = await call(server.base, 'POST', '/api/registrations', { ...person, year: '' });
  assert.equal(missingYear.status, 400);
  assert.ok(missingYear.body.fields.year);

  const first = await call(server.base, 'POST', '/api/registrations', person);
  assert.equal(first.status, 201);
  assert.match(first.body.pass.serial, /^MT-2026-\d{6}$/);
  assert.equal(first.body.pass.feeStatus.startsWith('Pending · ₹250'), true);
  assert.equal(first.body.pass.college, 'Chhatrapati Shivaji Maharaj University (CSMU)');

  const sameEmail = await call(server.base, 'POST', '/api/registrations', { ...person, email: 'ASHA.RAO@gmail.com', phone: '7700112233' });
  assert.equal(sameEmail.status, 409);
  assert.equal(sameEmail.body.code, 'duplicate');
  assert.equal(sameEmail.body.passes[0].serial, first.body.pass.serial, 'duplicate returns the existing serial');
  const samePhone = await call(server.base, 'POST', '/api/registrations', { ...person, email: 'other.person@gmail.com', phone: '+91 98123 00456' });
  assert.equal(samePhone.status, 409);
  assert.equal(samePhone.body.passes[0].serial, first.body.pass.serial);

  const roster = await call(server.base, 'GET', `/api/events/${breath.id}/roster`);
  assert.equal(roster.status, 200);
  assert.equal(roster.body.roster.length, 1);
  assert.equal(roster.body.roster[0].serial, first.body.pass.serial);
  assert.equal('email' in roster.body.roster[0], false, 'roster never exposes contact details');
  assert.equal('phone' in roster.body.roster[0], false);

  const lookup = await call(server.base, 'POST', '/api/passes/lookup', { email: 'asha.rao@gmail.com', phone: '9812300456' });
  assert.equal(lookup.body.passes.length, 1);
  const none = await call(server.base, 'POST', '/api/passes/lookup', { email: 'nobody@gmail.com', phone: '9812300457' });
  assert.equal(none.status, 200);
  assert.equal(none.body.passes.length, 0);
});

test('closed and unknown events refuse registrations clearly', async () => {
  const closed = await call(server.base, 'POST', '/api/registrations', { target: past.id, name: 'Ravi Kumar', email: 'ravi.kumar@gmail.com', phone: '7045512345', rollNo: 'CSMU-22-091', semester: 'Semester 3' });
  assert.equal(closed.status, 409);
  assert.equal(closed.body.code, 'closed');
  const unknown = await call(server.base, 'POST', '/api/registrations', { target: 'event-nope', name: 'Ravi Kumar', email: 'ravi.kumar@gmail.com', phone: '7045512345' });
  assert.equal(unknown.status, 404);
  const noTarget = await call(server.base, 'POST', '/api/registrations', { name: 'Ravi Kumar', email: 'ravi.kumar@gmail.com', phone: '7045512345' });
  assert.equal(noTarget.status, 400);
});

test('annual events are registered for one at a time: there is no season pass', async () => {
  const one = await call(server.base, 'POST', '/api/registrations', { target: breath.id, name: 'Ravi Kumar', email: 'ravi.kumar@gmail.com', phone: '7045512345', department: 'B.A.', rollNo: 'CSMU-22-091', year: '2nd Year' });
  assert.equal(one.status, 201, JSON.stringify(one.body));
  assert.equal(one.body.pass.eventTitle, breath.title, 'a single pass covers exactly the event it was issued for');
  assert.equal(one.body.pass.passType, 'event');
  assert.equal('seasonYear' in one.body.pass, false);
  // the next event is a second, separate registration with its own serial
  const two = await call(server.base, 'POST', '/api/registrations', { target: walk.id, name: 'Ravi Kumar', email: 'ravi.kumar@gmail.com', phone: '7045512345', college: 'University of Mumbai', rollNo: 'PRN-1', department: 'B.Sc.' });
  assert.equal(two.status, 201, JSON.stringify(two.body));
  assert.notEqual(two.body.pass.serial, one.body.pass.serial);
  assert.equal(two.body.pass.eventTitle, walk.title);
  // and the season target is simply not a thing any more
  const season = await call(server.base, 'POST', '/api/registrations', { target: 'season', name: 'Ravi Kumar', email: 'ravi.kumar@gmail.com', phone: '7045512345', rollNo: 'CSMU-22-091', semester: 'Semester 3' });
  assert.equal(season.status, 404, JSON.stringify(season.body));
  assert.equal(season.body.code, 'not-found');
});

test('capacity is enforced on the server, even under many simultaneous registrations', async () => {
  const single = (await call(server.base, 'POST', '/api/events', { ...eventBase, title: 'Single Seat Session', capacity: 1, day: '21', month: '11' }, token)).body;
  const requests = Array.from({ length: 12 }, (_, index) => call(server.base, 'POST', '/api/registrations', {
    target: single.id, name: 'Student Applicant', email: `student${index}.person@gmail.com`,
    phone: phoneFor(500 + index), department: 'B.A.', rollNo: `CSMU24${index}00`, year: '1st Year'
  }));
  const results = await Promise.all(requests);
  const created = results.filter(result => result.status === 201).length;
  const full = results.filter(result => result.status === 409 && result.body.code === 'full').length;
  assert.equal(created, 1, 'a 1-seat event takes exactly one registration');
  assert.equal(full, 11, 'the other eleven are refused with "full"');
  const roster = await call(server.base, 'GET', `/api/events/${single.id}/roster`);
  assert.equal(roster.body.roster.length, 1);
  const site = await call(server.base, 'GET', '/api/site');
  const cappedNow = site.body.events.find(event => event.id === single.id);
  assert.equal(cappedNow.seats.full, true);
  assert.equal(cappedNow.registrationOpen, false);
});

test('parallel registrations are all saved (no lost writes)', async () => {
  const many = await call(server.base, 'POST', '/api/events', { ...eventBase, title: 'Big Gathering', day: '9', month: '11', capacity: 40 }, token);
  const requests = Array.from({ length: 25 }, (_, index) => call(server.base, 'POST', '/api/registrations', {
    target: many.body.id, name: `Participant ${String.fromCharCode(65 + (index % 26))}${String.fromCharCode(65 + Math.floor(index / 26))}`,
    email: `participant${index}.run@gmail.com`, phone: phoneFor(2000 + index * 37),
    department: 'M.A.', rollNo: `CSMU25${index}00`, year: '2nd Year'
  }));
  const results = await Promise.all(requests);
  const statuses = results.map(result => result.status);
  assert.ok(statuses.every(status => status === 201), `all should be saved, got ${statuses.join(',')}`);
  const roster = await call(server.base, 'GET', `/api/events/${many.body.id}/roster`);
  assert.equal(roster.body.roster.length, 25);
  const persisted = JSON.parse(fs.readFileSync(server.dataFile, 'utf8'));
  assert.equal(persisted.registrations.filter(row => row.eventId === many.body.id).length, 25, 'every registration is on disk');
});

test('CSV exports: required columns, one event or all, and private to the Studio', async () => {
  assert.equal((await call(server.base, 'GET', `/api/admin/export/registrations.csv?eventId=${breath.id}`)).status, 401);
  const csv = await call(server.base, 'GET', `/api/admin/export/registrations.csv?eventId=${breath.id}`, undefined, token);
  assert.equal(csv.status, 200);
  assert.match(csv.headers.get('content-disposition'), /attachment; filename="mindful-tattva-breath-balance-workshop-registrations\.csv"/);
  const lines = csv.body.replace(/^\uFEFF/, '').trim().split(/\r\n/);
  assert.equal(lines[0].split(',')[0], 'Serial Number');
  for (const column of ['Event Title', 'Scope', 'Name', 'Email', 'Phone', 'College Name', 'Department', 'Roll No/PRN', 'Registration Date']) {
    assert.ok(lines[0].includes(column), `missing column ${column}`);
  }
  assert.ok(csv.body.includes('Asha Rao') && csv.body.includes('asha.rao@gmail.com'));
  const everything = await call(server.base, 'GET', '/api/admin/export/registrations.csv', undefined, token);
  assert.match(everything.headers.get('content-disposition'), /all-registrations\.csv/);
  assert.ok(everything.body.includes('Campus Walk') || everything.body.includes('Breath'));
  assert.equal((await call(server.base, 'GET', '/api/admin/export/registrations.csv?eventId=event-nope', undefined, token)).status, 404);
});

test('deleting an event keeps its registrations as archived attendance', async () => {
  const doomed = (await call(server.base, 'POST', '/api/events', { ...eventBase, title: 'Doomed Event', day: '28', month: '10' }, token)).body;
  const registered = await call(server.base, 'POST', '/api/registrations', { target: doomed.id, name: 'Doomed Person', email: 'doomed.person@gmail.com', phone: phoneFor(90), department: 'B.A.', rollNo: 'CSMU26001', year: '1st Year' });
  assert.equal(registered.status, 201);
  const doomedSerial = registered.body.pass.serial;
  const removed = await call(server.base, 'DELETE', `/api/events/${doomed.id}`, undefined, token);
  assert.equal(removed.status, 200);
  assert.equal(removed.body.archivedRegistrations, 1, 'the Studio is told how many registrations were kept');
  assert.equal((await call(server.base, 'GET', `/api/events/${doomed.id}/roster`)).status, 404, 'the event itself is gone from the calendar');
  // the registration survives, keeps the deleted event's own title and date, and is still exportable
  const rows = (await call(server.base, 'GET', '/api/admin/registrations', undefined, token)).body;
  const kept = rows.find(row => row.serial === doomedSerial);
  assert.ok(kept, 'the archived registration is still on record');
  assert.equal(kept.eventId, doomed.id);
  assert.equal(kept.eventTitle, 'Doomed Event');
  assert.equal(kept.eventDate, '28 November 2026');
  assert.equal(kept.name, 'Doomed Person');
  const csv = await call(server.base, 'GET', '/api/admin/export/registrations.csv', undefined, token);
  assert.ok(csv.body.includes(doomedSerial) && csv.body.includes('Doomed Event'), 'the master CSV keeps archived registrations');
  // and the holder can still look the pass up
  const lookup = await call(server.base, 'POST', '/api/passes/lookup', { email: 'doomed.person@gmail.com', phone: phoneFor(90) });
  assert.equal(lookup.status, 200);
  const found = lookup.body.passes.find(pass => pass.serial === doomedSerial);
  assert.ok(found, 'the archived pass is still findable');
  assert.equal(found.archived, true);
  assert.equal(found.eventTitle, 'Doomed Event');
});

test('registration rows can be removed by the Studio', async () => {
  const rows = (await call(server.base, 'GET', '/api/admin/registrations', undefined, token)).body;
  const row = rows.find(item => item.email === 'karan.shah@gmail.com') || rows[0];
  const removed = await call(server.base, 'DELETE', `/api/admin/registrations/${row.id}`, undefined, token);
  assert.equal(removed.status, 200);
  assert.equal((await call(server.base, 'DELETE', `/api/admin/registrations/${row.id}`, undefined, token)).status, 404);
});

test('volunteer applications: contribution required, duplicates refused, private until approved', async () => {
  const short = await call(server.base, 'POST', '/api/submissions', { type: 'volunteer', name: 'Aman Verma', email: 'aman.verma@gmail.com', phone: '9898011223', contribution: 'Too short' });
  assert.equal(short.status, 400);
  assert.ok(short.body.fields.contribution);
  const invalidEmail = await call(server.base, 'POST', '/api/submissions', { type: 'volunteer', name: 'Aman Verma', email: 'aman@example.com', phone: '9898011223', contribution: 'I can design posters and host welcome circles for new students.' });
  assert.equal(invalidEmail.status, 400);
  const created = await call(server.base, 'POST', '/api/submissions', { type: 'volunteer', name: 'Aman Verma', email: 'aman.verma@gmail.com', phone: '9898011223', programme: 'B.A.', year: '2nd year', interests: 'Mindfulness', contribution: 'I can design posters, run Instagram stories and host welcome circles for new members.' });
  assert.equal(created.status, 201);
  const duplicate = await call(server.base, 'POST', '/api/submissions', { type: 'volunteer', name: 'Aman V', email: 'AMAN.VERMA@gmail.com', phone: '+91 98980 11223', contribution: 'Another attempt with the same details, long enough to pass.' });
  assert.equal(duplicate.status, 409);
  const publicView = await call(server.base, 'GET', '/api/site');
  assert.equal(JSON.stringify(publicView.body).includes('aman.verma@gmail.com'), false, 'applications are not public');
  const list = await call(server.base, 'GET', '/api/submissions', undefined, token);
  const mine = list.body.find(item => item.id === created.body.id);
  assert.equal(mine.status, 'pending');
  const approved = await call(server.base, 'POST', `/api/submissions/${created.body.id}/approve`, { group: 'volunteers', role: 'Volunteer' }, token);
  assert.equal(approved.status, 200);
  assert.equal(approved.body.member.group, 'volunteers');
  const members = await call(server.base, 'GET', '/api/team');
  const volunteer = members.body.find(member => member.name === 'Aman Verma');
  assert.ok(volunteer, 'approved volunteer is in the live directory');
  assert.equal(volunteer.email, '', 'volunteer email stays private');
  assert.equal(volunteer.bio, '', 'volunteer contribution stays private');
  assert.equal((await call(server.base, 'POST', `/api/submissions/${created.body.id}/approve`, { group: 'volunteers' }, token)).status, 409);
  const reject = await call(server.base, 'POST', '/api/submissions', { type: 'volunteer', name: 'Test Reject', email: 'test.reject@gmail.com', phone: '7700998877', contribution: 'This application exists so that rejection can be tested.' });
  assert.equal(reject.status, 201);
  assert.equal((await call(server.base, 'DELETE', `/api/submissions/${reject.body.id}`, undefined, token)).status, 200);
});

test('gallery items: https links and image-only photos', async () => {
  assert.equal((await call(server.base, 'POST', '/api/gallery', { title: 'Bad link', url: 'http://x.org', image: PNG }, token)).status, 400);
  assert.equal((await call(server.base, 'POST', '/api/gallery', { title: 'Bad file', image: PDF }, token)).status, 400);
  const good = await call(server.base, 'POST', '/api/gallery', { title: 'Welcome circle', category: 'Event', caption: 'First meeting', url: 'https://www.instagram.com/p/x', image: PNG }, token);
  assert.equal(good.status, 201);
  assert.equal((await call(server.base, 'DELETE', `/api/gallery/${good.body.id}`, undefined, token)).status, 200);
});

test('static pages: clean URLs work and files outside public/ are never served', async () => {
  for (const route of ['/', '/members.html', '/events.html', '/calendar.html', '/gallery.html', '/admin.html', '/admin', '/events', '/members']) {
    const response = await fetch(server.base + route);
    assert.equal(response.status, 200, `${route} should load`);
  }
  assert.equal((await fetch(server.base + '/nope')).status, 404);
  const traversal = await fetch(server.base + '/%2e%2e/server.js');
  assert.notEqual(traversal.status, 200);
  const body = await traversal.text();
  assert.equal(body.includes('MT_ADMIN_PASSWORD') || body.includes('registerAttendee'), false, 'server source must not leak');
});

test('the public pages carry no password hint and keep the footer credit', async () => {
  const html = await (await fetch(server.base + '/admin.html')).text();
  assert.equal(/csmu@mt/i.test(html.replace(/<script[\s\S]*?<\/script>/gi, '')), false, 'password must not appear in the page markup');
  const home = await (await fetch(server.base + '/')).text();
  assert.ok(home.includes('Made with love by Mohd Shafiq · Vice President'));
  assert.ok(home.includes('credit-heart'));
});

// ----- login lockout uses its own server so other tests keep their session -----
test('repeated wrong passwords lock the Studio login for a while', async () => {
  const locked = await startServer();
  try {
    for (let attempt = 0; attempt < 8; attempt += 1) {
      const result = await call(locked.base, 'POST', '/api/admin/login', { password: `wrong-${attempt}` });
      assert.equal(result.status, 401);
    }
    const blocked = await call(locked.base, 'POST', '/api/admin/login', { password: PASSWORD });
    assert.equal(blocked.status, 429, 'even the right password is refused during the lock');
  } finally {
    await locked.stop();
  }
});
