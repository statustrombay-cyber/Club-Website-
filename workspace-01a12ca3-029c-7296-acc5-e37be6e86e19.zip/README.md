# Mindful Tattva

Website for **Mindful Tattva**, the psychology club of the Department of Applied Social Science at Chhatrapati Shivaji Maharaj University (CSMU), Panvel. No external services or npm packages are needed.

## Run it

```bash
npm run build      # regenerates public/*.html from src/ (run after any change in src/)
npm start          # serves http://0.0.0.0:4173 (PORT env var to change)
```

- Public site: `/` · Events & passes: `/events.html` · Calendar: `/calendar.html` · Gallery: `/gallery.html` · Members: `/members.html`
- Content Studio (officers only): `/admin.html`

Configuration (optional environment variables):

| Variable | Default | Purpose |
| --- | --- | --- |
| `PORT` | `4173` | HTTP port |
| `MT_DATA_FILE` | `data/site.json` | Where the data is stored |
| `MT_ADMIN_PASSWORD` | `Csmu@MT` | Content Studio password (checked on the server only) |
| `MT_RATE_LIMIT` | `120` | Registrations/lookups/submissions per IP per 10 minutes (`0` disables) |

## Tests

```bash
npm test            # unit tests (shared rules) + API tests (real server, temporary data)
npm run test:e2e    # Chromium end-to-end checks (needs: pip install playwright && playwright install chromium)
```

## What the site does

**Event registration and digital passes**
- Registration is per event: pick an event with seats left, get one serial number for it. There is no season or year pass.
- Scope-adaptive form. *Intercollege*: external college/university, PRN or college roll number, department/stream. *Interdepartmental*: CSMU department/course, student roll number, year of study. *Departmental*: department locked to “Department of Applied Social Sciences”, CSMU roll number, semester.
- The server issues serials in the form `MT-2026-892415`. Nobody needs a password to register.
- Digital pass as a 2× PNG drawn on a canvas, with name, college, roll number, serial, event, date, venue, fee status and a verification stamp.
- Duplicates are blocked per event by email **or** phone (normalised, case-insensitive). The duplicate response returns the existing pass.
- Capacity is enforced on the server, including under simultaneous requests.
- Indian mobile rules: 10 digits starting with 6–9; `+91`, `91` and `0` prefixes are stripped; repeated digits (e.g. `9999999999`) and sequences (e.g. `1234567890`) are rejected.
- Email rules: placeholder and disposable domains (`test.com`, `example.com`, `mailinator`, `tempmail`, `yopmail` and similar) are rejected.
- Live roster inside the registration modal (updates every 10 seconds), with names and serials only.
- Find-my-pass lookup by email and phone; passes issued on a device are kept in `localStorage`.
- Per-event and master CSV exports in the Content Studio (serial, event, scope, name, email, phone, college, department, roll or PRN, registration date, and more).

**Events and calendar**
- Search by keyword, venue, instructor, category and scope; optional past events.
- Free entry or a custom ₹ fee (paid at the desk on the event day), optional seat capacity, live “X / Y Seats Filled”.
- Optional brochure: an https link or an uploaded PDF. The *Brochure (PDF)* button only appears when one exists. PDFs are accepted for events only.
- Next-event ticker at the top of every page with one-click RSVP.

**Content Studio (`/admin.html`)**
- Password gate (`Csmu@MT`) with no hint anywhere on the public site. Sessions are bearer tokens kept for the browser tab; the login locks for 15 minutes after 8 wrong passwords.
- Members: add, edit and delete; three groups (Core Committee, Head Committee, Volunteers); 10-digit Indian phone validation; photo upload with FileReader (Base64), centre-cropped to a square.
- Events: full create/edit/delete (scope, date, time, venue, category, instructor, fee, capacity, description, cover image, brochure). Delete asks for confirmation and removes that event's registrations.
- Gallery: upload with title, category, caption and link; delete.
- Volunteer review: read each application and the “what can you do for the club?” answer; approve as a member (creates a live directory profile) or reject and delete.
- Registrations: summary per event, searchable table, remove a registration, CSV exports.
- Instagram, club email and contact details, announcement and intro.
- Drafts: if the server cannot be reached, a change is kept on that device as a **draft** and is clearly marked as not published.

**Members and volunteers**
- Three fixed groups with filter chips. Officers have tel and mailto links.
- Members without a photo show an **MT** placeholder; the card is never removed.
- Volunteers are shown with name and phone only. Their email and contribution text are never published.
- The homepage shows only Core Committee members (those switched on for the homepage).

**Volunteer application**
- Public form with the mandatory prompt *“What can you do for the club? What are your interests? How will you help Mindful Tattva grow?”* (at least 30 characters).
- The success message appears only after the server has saved the application.

**Location, social and persistence**
- Google Maps link to the CSMU Panvel campus, built from the university name and address.
- Instagram: `@mindful_tattva`, editable in the Studio.
- The server is the source of truth (`data/site.json`). Every page mirrors the latest content into `localStorage`, so a page still works from its last saved copy if the server is down. Live updates come over Server-Sent Events.
- Responsive layout with a touch-friendly hamburger drawer (quick access to every form, tool and contact).

## Architecture

```
server.js                  Node http server: API, live updates, static files, auth, registrations, exports
shared/domain.js           Rules shared by server and browser: phone/email/name validation, dates, passes, CSV
src/html/*.html            Page templates
src/css/*.css              Styles (base, page styles, features)
src/js/*.js                Browser code: common helpers, core (store, ticker, drawer, modal, passes), one script per page
scripts/build.js           Builds public/*.html: inlines CSS, JS and the official logos, adds an offline data snapshot
public/                    Generated site (do not edit by hand)
public/assets/             Official logos (university seal, university logo, club logo)
data/site.json             Live data (team, events, gallery, history, site copy, registrations, volunteer applications)
tests/unit, tests/api      node:test suites
tests/e2e/run_e2e.py       Browser checks with Playwright
```

Data writes go through one queue on the server, so simultaneous saves cannot overwrite each other. The public API never returns registrations, volunteer applications or volunteer contact details.

## Known limits and decisions for the club to confirm

- Registration only: there is no season or full-year pass. Every event is registered for on its own.
- The Content Studio password is held on the server (default `Csmu@MT`, overridable with `MT_ADMIN_PASSWORD`). The sign-in session lasts 12 hours. For a public launch, move the password to a deployment secret and add named officer accounts.
- Payments are not taken online. Paid entries are settled at the desk, and the pass says so.
- Deleting an event keeps its registrations as archived attendance. The registration rows store the event's own title, date and venue, so passes, rosters and the master CSV stay complete after the event is gone. The Studio shows those rows with an **Archived** tag, and deletion still asks for confirmation.
- Brochure PDFs are stored inside `data/site.json`. Keep them small (8 MB limit).

## University address used

The address is the wording from the university's official Contact page:

> Near Shedung Toll Plaza, Old Mumbai-Pune Highway, Panvel, Navi Mumbai, Maharashtra Pincode – 410206.

Source: https://csmu.ac.in/contact-us/
