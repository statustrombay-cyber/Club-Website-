#!/usr/bin/env node
/*
 * Builds the public website into public/*.html from:
 *   src/html/*.html   page templates (placeholders below)
 *   src/css/*.css     page styles
 *   src/js/*.js       browser scripts (bundled per page)
 *   shared/domain.js  rules shared with the server
 *   assets/           official logos, inlined as data URIs
 *   data/site.json    snapshot used as an offline fallback
 *
 * Placeholders: <!--@CSS-->  <!--@JS-->  <!--@BOOTSTRAP-->
 * Run with: npm run build
 */
'use strict';

const fs = require('fs');
const path = require('path');
const D = require('../shared/domain.js');

const ROOT = path.join(__dirname, '..');
const SRC = path.join(ROOT, 'src');
const PUBLIC = path.join(ROOT, 'public');
const DATA_FILE = process.env.MT_DATA_FILE ? path.resolve(process.env.MT_DATA_FILE) : path.join(ROOT, 'data', 'site.json');

const LOGO_MIME = { 'mindful-tattva-logo.jpg': 'image/jpeg', 'csmu-seal.png': 'image/png', 'university-logo.png': 'image/png' };

const PAGES = {
  'index.html': { css: ['base.css', 'features.css'], js: ['home.js'], public: true },
  'members.html': { css: ['base.css', 'members.css', 'features.css'], js: ['members.js'], public: true },
  'gallery.html': { css: ['base.css', 'gallery.css', 'features.css'], js: ['gallery.js'], public: true },
  'calendar.html': { css: ['calendar.css', 'features.css'], js: ['calendar.js'], public: true },
  'events.html': { css: ['base.css', 'features.css'], js: ['events.js'], public: true },
  'admin.html': { css: ['base.css', 'admin.css', 'features.css'], js: ['admin.js'], public: false }
};

const SHARED_JS = ['common.js'];
const PUBLIC_JS = ['core.js'];

function read(file) {
  return fs.readFileSync(file, 'utf8');
}

function assetDataUri(name) {
  const file = path.join(ROOT, 'public', 'assets', name);
  const mime = LOGO_MIME[name];
  if (!mime) throw new Error(`No MIME type registered for asset ${name}`);
  return `data:${mime};base64,${fs.readFileSync(file).toString('base64')}`;
}

function inlineAssets(html) {
  return html.replace(/(\s(?:src|href)=)"\/assets\/([\w.-]+)"/g, (match, attribute, name) => {
    if (!LOGO_MIME[name]) return match;
    return `${attribute}"${assetDataUri(name)}"`;
  });
}

function cssBlock(files) {
  return files.map(name => {
    const css = read(path.join(SRC, 'css', name)).trim();
    if (/<\/style/i.test(css)) throw new Error(`${name} contains a closing style tag`);
    return `  <style data-source="${name}">\n${css}\n  </style>`;
  }).join('\n');
}

function jsBlock(files) {
  const source = files.map(name => {
    const code = read(path.join(SRC, 'js', name)).trim();
    if (/<\/script/i.test(code)) throw new Error(`${name} contains a closing script tag`);
    return `/* ---- ${name} ---- */\n${code}`;
  }).join('\n\n');
  return `  <script data-bundle="${files.join(' + ')}">\n${source}\n  </script>`;
}

function domainBlock() {
  const code = read(path.join(ROOT, 'shared', 'domain.js')).trim();
  if (/<\/script/i.test(code)) throw new Error('domain.js contains a closing script tag');
  return code;
}

function bootstrapBlock() {
  const db = D.normalizeDb(JSON.parse(read(DATA_FILE)));
  const snapshot = D.publicSnapshot(db, new Date());
  const json = JSON.stringify(snapshot).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  return `  <script>window.__MT_BOOTSTRAP__ = ${json};</script>`;
}

function buildPage(name, config) {
  let html = read(path.join(SRC, 'html', name));
  // Function replacements keep "$" sequences inside the code (e.g. "$$" or "$'") from being treated as patterns.
  // A data-URI favicon stops browsers from requesting /favicon.ico on every page load.
  html = html.replace(/<meta charset="utf-8">/i, () => '<meta charset="utf-8">\n  <link rel="icon" href="data:,">');
  html = html.replace('<!--@CSS-->', () => cssBlock(config.css));
  const scripts = [...SHARED_JS, ...(config.public ? PUBLIC_JS : []), ...config.js];
  const bundle = jsBlock(scripts);
  // The domain module is a UMD that sets window.MTDomain in the browser. It goes first so every later script can use it.
  const domain = `  <script data-bundle="domain.js">\n${domainBlock()}\n  </script>`;
  html = html.replace('<!--@JS-->', () => `${domain}\n${bundle}`);
  html = html.replace('<!--@BOOTSTRAP-->', () => (config.public ? bootstrapBlock() : ''));
  if (html.includes('<!--@')) throw new Error(`Unresolved placeholder in ${name}`);
  html = inlineAssets(html);
  return html.replace(/\s*$/, '\n');
}

function main() {
  fs.mkdirSync(PUBLIC, { recursive: true });
  const report = [];
  for (const [name, config] of Object.entries(PAGES)) {
    const html = buildPage(name, config);
    fs.writeFileSync(path.join(PUBLIC, name), html);
    report.push(`${name.padEnd(16)} ${(Buffer.byteLength(html) / 1024).toFixed(0).padStart(6)} KB`);
  }
  console.log(report.join('\n'));
}

if (require.main === module) main();

module.exports = { buildPage, PAGES };
