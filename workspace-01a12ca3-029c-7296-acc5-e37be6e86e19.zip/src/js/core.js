/* Public-site core: live data store, ticker, drawer, registration modal, passes and PNG export. */
(function (M) {
  'use strict';

  const D = window.MTDomain;
  const CACHE_KEY = 'mt-site-cache-v1';
  const PASSES_KEY = 'mt-my-passes-v1';
  const ROSTER_KEY = 'mt-roster-cache-v1';
  const APPLY_KEY = 'mt-volunteer-applications-v1';
  const state = { site: null, source: 'loading', live: false };
  const listeners = [];
  const passIndex = new Map();
  const modal = { el: null, view: null, eventId: '', rosterTimer: null, lastFocus: null };

  const esc = M.esc;

  M.site = () => state.site;
  M.siteSource = () => state.source;
  M.onSite = fn => {
    listeners.push(fn);
    if (state.site) fn(state.site, state.source);
  };

  /* ---------- data store: server first, localStorage mirror, bundled snapshot last ---------- */

  function slimSnapshot(data) {
    const shrink = value => (typeof value === 'string' && value.length > 150000 ? '' : value);
    return {
      ...data,
      team: (data.team || []).map(member => ({ ...member, image: shrink(member.image) })),
      gallery: (data.gallery || []).map(item => ({ ...item, image: shrink(item.image) })),
      events: (data.events || []).map(event => ({ ...event, attachment: '', image: shrink(event.image) }))
    };
  }

  function saveMirror(data) {
    if (M.writeJson(CACHE_KEY, data)) return;
    M.writeJson(CACHE_KEY, slimSnapshot(data));
  }

  function setSite(data, source) {
    state.site = data;
    state.source = source;
    if (source === 'live') saveMirror(data);
    for (const listener of listeners) {
      try { listener(state.site, state.source); } catch (error) { console.error(error); }
    }
    updateStatus();
  }

  M.loadSite = async () => {
    try {
      const response = await fetch('/api/site', { cache: 'no-store' });
      if (!response.ok) throw new Error(`Site ${response.status}`);
      const data = await response.json();
      setSite(data, 'live');
      return true;
    } catch (_) {
      const cached = M.readJson(CACHE_KEY, null);
      if (cached && Array.isArray(cached.events)) setSite(cached, 'cache');
      else if (window.__MT_BOOTSTRAP__) setSite(window.__MT_BOOTSTRAP__, 'bootstrap');
      return false;
    }
  };

  function connectLive() {
    if (!('EventSource' in window) || location.protocol === 'file:') return;
    const stream = new EventSource('/api/stream');
    stream.addEventListener('site-update', event => {
      try {
        state.live = true;
        setSite(JSON.parse(event.data), 'live');
      } catch (_) { /* ignore malformed update */ }
    });
    stream.onopen = () => { state.live = true; updateStatus(); };
    stream.onerror = () => { state.live = false; updateStatus(); };
  }

  function updateStatus() {
    const text = state.source === 'live' && state.live
      ? 'Live updates on'
      : (state.source === 'live' ? 'Connected' : 'Showing saved copy');
    M.$$('[data-live-status]').forEach(node => {
      node.textContent = text;
      node.dataset.state = state.source === 'live' ? 'live' : 'cached';
    });
  }

  /* ---------- helpers for events ---------- */

  M.openEvents = site => {
    const today = (site && site.today) || D.todayIso();
    return (site ? site.events : [])
      .filter(event => event.published && D.isUpcomingEvent(event, today))
      .sort((a, b) => String(D.eventIsoDate(a) || '9999-12-31').localeCompare(String(D.eventIsoDate(b) || '9999-12-31')));
  };

  M.seatsOf = event => {
    const seats = event.seats || { filled: 0, capacity: event.capacity || null };
    const capacity = seats.capacity || null;
    const filled = Number(seats.filled) || 0;
    return { filled, capacity, full: Boolean(capacity && filled >= capacity), pct: capacity ? Math.min(100, Math.round((filled / capacity) * 100)) : 0 };
  };

  M.seatText = event => {
    const seats = M.seatsOf(event);
    return seats.capacity ? `${seats.filled} / ${seats.capacity} Seats Filled` : `${seats.filled} Seats Filled · no seat limit`;
  };

  M.feeText = event => (event.feeType === 'paid' && Number(event.fee) > 0 ? `${M.money(event.fee)} · pay at the desk` : 'Free entry');

  M.brochureLink = (event, className) => {
    const pdf = M.safeAttachment(event.attachment);
    const link = pdf || (/^https:\/\//i.test(event.brochureUrl || '') ? event.brochureUrl : '');
    if (!link) return '';
    const name = `${M.slug(event.title)}-brochure.pdf`;
    const attributes = pdf ? `download="${esc(event.attachmentName || name)}"` : 'target="_blank" rel="noopener"';
    return `<a class="${className || 'outline-button small'}" href="${esc(link)}" ${attributes}>Brochure (PDF)</a>`;
  };

  M.eventCard = (event, options) => {
    const opts = options || {};
    const seats = M.seatsOf(event);
    const image = M.bgStyle(event.image);
    const title = event.title || 'Mindful Tattva event';
    const scopeLabel = D.SCOPE_LABEL[event.scope] || '';
    const feeChip = event.feeType === 'paid' && Number(event.fee) > 0 ? M.money(event.fee) : 'Free';
    let action;
    if (!event.registrationOpen && seats.full) action = '<button class="outline-button small" type="button" disabled>Event full</button>';
    else if (event.registrationOpen) action = `<button class="solid-button small" type="button" data-register="${esc(event.id)}">Register ↗</button>`;
    else action = '<span class="mt-muted">Registration closed</span>';
    return `
      <article class="event-card mt-event${opts.compact ? ' mt-event-compact' : ''}" data-event-id="${esc(event.id)}">
        <div class="card-visual${image ? ' has-image' : ''}" style="${esc(image)}"><span class="visual-label">${esc(event.category || event.kicker || 'Mindful Tattva')}</span></div>
        <div class="event-body">
          <div class="event-date">${esc(D.displayDate(event))}${event.time ? ` · ${esc(event.time)}` : ''}</div>
          <h3>${esc(title)}</h3>
          <div class="mt-chips">
            <span class="mt-chip">${esc(scopeLabel)}</span>
            <span class="mt-chip">${esc(event.category || event.kicker || '')}</span>
            <span class="mt-chip mt-chip-fee">${esc(feeChip)}</span>
          </div>
          ${event.location ? `<p class="mt-venue">${esc(event.location)}${event.instructor ? ` · with ${esc(event.instructor)}` : ''}</p>` : (event.instructor ? `<p class="mt-venue">with ${esc(event.instructor)}</p>` : '')}
          ${opts.compact || !event.description ? '' : `<p class="mt-desc">${esc(event.description)}</p>`}
          <div class="mt-seats" aria-label="${esc(M.seatText(event))}">
            <div class="mt-seat-bar"><span style="width:${seats.capacity ? seats.pct : 0}%"></span></div>
            <small><strong>${esc(M.seatText(event))}</strong></small>
          </div>
          <div class="mt-card-actions">
            ${action}
            <button class="outline-button small" type="button" data-roster="${esc(event.id)}">Live roster (${seats.filled})</button>
            ${M.brochureLink(event)}
          </div>
        </div>
      </article>`;
  };

  /* ---------- my passes on this device ---------- */

  M.myPasses = () => M.readJson(PASSES_KEY, []);

  function rememberPass(pass) {
    if (!pass || !pass.serial) return;
    passIndex.set(pass.serial, pass);
    const list = M.myPasses().filter(item => item.serial !== pass.serial);
    list.unshift({ serial: pass.serial, savedAt: new Date().toISOString(), pass });
    M.writeJson(PASSES_KEY, list.slice(0, 25));
  }

  function forgetPass(serial) {
    M.writeJson(PASSES_KEY, M.myPasses().filter(item => item.serial !== serial));
    passIndex.delete(serial);
  }

  function findPass(serial) {
    if (passIndex.has(serial)) return passIndex.get(serial);
    const saved = M.myPasses().find(item => item.serial === serial);
    return saved ? saved.pass : null;
  }

  M.recordVolunteerApplication = entry => {
    const list = M.readJson(APPLY_KEY, []);
    list.unshift(entry);
    M.writeJson(APPLY_KEY, list.slice(0, 20));
  };
  M.volunteerApplications = () => M.readJson(APPLY_KEY, []);

  /* ---------- pass card (HTML) ---------- */

  M.passCard = pass => {
    const rows = [
      ['Name', pass.name],
      ['College', pass.college],
      ['Roll no / PRN', pass.rollNo],
      ['Department', pass.department],
      ['Date', [pass.eventDate, pass.eventTime].filter(Boolean).join(' · ')],
      ['Venue', pass.venue],
      ['Fee status', pass.feeStatus]
    ].filter(row => row[1]);
    return `
      <article class="mt-pass" aria-label="Digital pass ${esc(pass.serial)}">
        <header class="mt-pass-head">
          <div class="mt-pass-brand"><span class="mt-pass-mark">MT</span><div><small>Mindful Tattva · Digital pass</small><strong>${esc(pass.eventTitle)}</strong></div></div>
          <span class="mt-pass-serial">${esc(pass.serial)}</span>
        </header>
        ${pass.archived ? '<p class="mt-fine">This event has since been removed from the calendar. Your registration and this pass stay on record.</p>' : ''}
        <dl class="mt-pass-grid">
          ${rows.map(row => `<div><dt>${esc(row[0])}</dt><dd>${esc(row[1])}</dd></div>`).join('')}
        </dl>
        <div class="mt-pass-stamp"><span>✓</span> Verified · issued ${esc(M.issuedStamp(pass.issuedAt))}</div>
      </article>`;
  };

  /* ---------- high-resolution PNG pass (canvas) ---------- */

  function wrapLines(ctx, text, maxWidth, maxLines) {
    const words = String(text || '').split(/\s+/).filter(Boolean);
    const lines = [];
    let line = '';
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxWidth && line) { lines.push(line); line = word; }
      else line = test;
    }
    if (line) lines.push(line);
    if (lines.length > maxLines) {
      lines.length = maxLines;
      let last = lines[maxLines - 1];
      while (last.length > 1 && ctx.measureText(`${last}…`).width > maxWidth) last = last.slice(0, -1);
      lines[maxLines - 1] = `${last.trimEnd()}…`;
    }
    return lines;
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function spacedText(ctx, text, x, y, spacing) {
    let cursor = x;
    for (const char of String(text)) {
      ctx.fillText(char, cursor, y);
      cursor += ctx.measureText(char).width + spacing;
    }
    return cursor;
  }

  M.drawPassPng = pass => new Promise((resolve, reject) => {
    const scale = 2;
    const width = 800;
    const sans = '"Trebuchet MS", "Segoe UI", Arial, sans-serif';
    const serif = 'Georgia, "Times New Roman", serif';
    const mono = '"Courier New", Consolas, monospace';

    const fields = [
      ['Name', pass.name],
      ['College / university', pass.college],
      ['Roll no / PRN', pass.rollNo],
      ['Department', pass.department],
      ['Scope', pass.eventScopeLabel],
      ['Year / semester', pass.yearOrSemester],
      ['Event date', pass.eventDate],
      ['Fee status', pass.feeStatus]
    ].filter(item => item[1]);

    // Fixed layout: header 0–262, title 310–490, participant grid from 530, stamp band at the bottom.
    const fieldsTop = 530;
    const contentEnd = fieldsTop + Math.ceil(fields.length / 2) * 78;
    const bandTop = contentEnd + 44;
    const height = bandTop + 210;

    const canvas = document.createElement('canvas');
    canvas.width = width * scale;
    canvas.height = height * scale;
    const ctx = canvas.getContext('2d');
    ctx.setTransform(scale, 0, 0, scale, 0, 0);

    ctx.fillStyle = '#fbf8f1';
    ctx.fillRect(0, 0, width, height);

    const band = ctx.createLinearGradient(0, 0, width, 262);
    band.addColorStop(0, '#34213d');
    band.addColorStop(1, '#704b61');
    ctx.fillStyle = band;
    ctx.fillRect(0, 0, width, 262);
    ctx.globalAlpha = 0.14;
    ctx.fillStyle = '#f4c17f';
    ctx.beginPath();
    ctx.arc(width - 40, 40, 170, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;

    // Logo: reuses the page's own embedded image, so it also renders offline.
    const logo = document.querySelector('img[data-mt-logo]');
    ctx.save();
    ctx.beginPath();
    ctx.arc(92, 92, 50, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    if (logo && logo.complete && logo.naturalWidth) {
      ctx.drawImage(logo, 42, 42, 100, 100);
    } else {
      ctx.fillStyle = '#f4c17f';
      ctx.fillRect(42, 42, 100, 100);
      ctx.fillStyle = '#34213d';
      ctx.font = `700 34px ${serif}`;
      ctx.textAlign = 'center';
      ctx.fillText('MT', 92, 104);
      ctx.textAlign = 'left';
    }
    ctx.restore();

    ctx.fillStyle = '#fff9ef';
    ctx.font = `700 17px ${sans}`;
    spacedText(ctx, 'MINDFUL TATTVA', 166, 84, 4);
    ctx.font = `400 42px ${serif}`;
    ctx.fillText('Digital pass', 166, 136);
    ctx.font = `600 14px ${sans}`;
    ctx.fillStyle = 'rgba(255,249,239,.72)';
    ctx.fillText('Chhatrapati Shivaji Maharaj University · Psychology Club', 166, 166);

    ctx.fillStyle = 'rgba(255,249,239,.14)';
    roundRect(ctx, 56, 196, 420, 44, 22);
    ctx.fill();
    ctx.fillStyle = '#f9d6b4';
    ctx.font = `700 13px ${sans}`;
    spacedText(ctx, 'SERIAL NUMBER', 78, 224, 2.5);
    ctx.fillStyle = '#fff9ef';
    ctx.font = `700 22px ${mono}`;
    ctx.fillText(pass.serial, 232, 225);

    // Title and event facts.
    let y = 310;
    ctx.fillStyle = '#34213d';
    ctx.font = `400 46px ${serif}`;
    for (const line of wrapLines(ctx, pass.eventTitle, 688, 2)) { ctx.fillText(line, 56, y); y += 52; }
    ctx.fillStyle = '#6b605c';
    ctx.font = `600 19px ${sans}`;
    const when = [pass.eventDate, pass.eventTime].filter(Boolean).join(' · ');
    ctx.fillText(wrapLines(ctx, when, 688, 1)[0] || '', 56, Math.max(y + 8, 416));
    ctx.fillText(wrapLines(ctx, pass.venue || 'Venue to be announced', 688, 1)[0] || '', 56, 456);

    ctx.strokeStyle = 'rgba(78,49,85,.18)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(56, 490);
    ctx.lineTo(width - 56, 490);
    ctx.stroke();

    // Participant grid.
    fields.forEach((item, index) => {
      const x = 56 + (index % 2) * 352;
      const top = fieldsTop + Math.floor(index / 2) * 78;
      ctx.fillStyle = '#9a8a8f';
      ctx.font = `700 13px ${sans}`;
      spacedText(ctx, item[0].toUpperCase(), x, top, 1.8);
      ctx.fillStyle = '#2e2928';
      ctx.font = `600 21px ${sans}`;
      wrapLines(ctx, item[1], 330, 2).forEach((line, lineIndex) => ctx.fillText(line, x, top + 28 + lineIndex * 26));
    });

    // Verification band: stamp on the left, instructions on the right.
    ctx.strokeStyle = 'rgba(78,49,85,.14)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(56, bandTop);
    ctx.lineTo(width - 56, bandTop);
    ctx.stroke();
    const cx = 146;
    const cy = bandTop + 112;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(-0.18);
    ctx.strokeStyle = '#3f7f66';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(0, 0, 80, 0, Math.PI * 2);
    ctx.stroke();
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.arc(0, 0, 70, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = '#3f7f66';
    ctx.font = `700 12px ${sans}`;
    // Centre the spaced word as one unit: letters are drawn left-aligned from a computed start.
    const verifiedWidth = [...'VERIFIED'].reduce((sum, char) => sum + ctx.measureText(char).width + 2.5, -2.5);
    ctx.textAlign = 'left';
    spacedText(ctx, 'VERIFIED', -verifiedWidth / 2, -26, 2.5);
    ctx.textAlign = 'center';
    ctx.font = `400 28px ${serif}`;
    ctx.fillText('✓', 0, 2);
    ctx.font = `700 11px ${mono}`;
    ctx.fillText(pass.serial, 0, 27);
    ctx.font = `600 10px ${sans}`;
    ctx.fillText(`ISSUED ${(M.shortDate(String(pass.issuedAt || '').slice(0, 10)) || '').toUpperCase()}`, 0, 44);
    ctx.restore();
    ctx.textAlign = 'left';

    ctx.fillStyle = '#34213d';
    ctx.font = `400 26px ${serif}`;
    ctx.fillText('Show this pass at the desk.', 262, bandTop + 84);
    ctx.fillStyle = '#6b605c';
    ctx.font = `600 15px ${sans}`;
    ctx.fillText('Paid entries are settled at the desk on the event day.', 262, bandTop + 114);
    ctx.fillText('Mindful Tattva · Chhatrapati Shivaji Maharaj University, Panvel', 262, bandTop + 140);

    canvas.toBlob(blob => (blob ? resolve(blob) : reject(new Error('The pass image could not be created.'))), 'image/png');
  });

  M.downloadPass = async serial => {
    const pass = findPass(serial);
    if (!pass) throw new Error('This pass is not saved on this device yet. Look it up again to download it.');
    const blob = await M.drawPassPng(pass);
    M.downloadBlob(blob, `MT-pass-${pass.serial}.png`);
  };

  /* ---------- drawer ---------- */

  function buildDrawer() {
    if (M.$('#mtDrawer')) return;
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <div class="mt-drawer-overlay" data-mt-drawer-close hidden></div>
      <aside class="mt-drawer" id="mtDrawer" role="dialog" aria-modal="true" aria-label="Site menu" tabindex="-1" hidden>
        <div class="mt-drawer-head"><span class="mt-drawer-title">Mindful Tattva</span><button class="mt-icon-btn" type="button" data-mt-drawer-close aria-label="Close menu">×</button></div>
        <nav class="mt-drawer-nav" aria-label="Quick access">
          <p class="mt-drawer-group">Explore</p>
          <a href="/">Home</a>
          <a href="/events.html">Events &amp; passes</a>
          <a href="/calendar.html">Yearly calendar</a>
          <a href="/gallery.html">Gallery</a>
          <a href="/members.html">Members directory</a>
          <a href="/#join">Volunteer application</a>
          <p class="mt-drawer-group">Registration tools</p>
          <button type="button" data-mt-open="register">Register for an event</button>
          <button type="button" data-mt-open="lookup">Find my pass</button>
          <button type="button" data-mt-open="passes">My passes on this device</button>
          <p class="mt-drawer-group">Contacts</p>
          <div data-mt-drawer-contacts></div>
        </nav>
      </aside>`;
    while (wrap.firstChild) document.body.appendChild(wrap.firstChild);
  }

  function renderDrawerContacts(site) {
    const box = M.$('[data-mt-drawer-contacts]');
    if (!box || !site) return;
    const site0 = site.site || {};
    const officers = (site.team || []).filter(member => member.group === 'management' && M.telHref(member.phone));
    box.innerHTML = `
      ${officers.map(member => `<a href="${esc(M.telHref(member.phone))}">${esc(member.name)} · ${esc(member.role)} <small>${esc(M.phoneDisplay(member.phone))}</small></a>`).join('')}
      ${site0.email && M.mailHref(site0.email) ? `<a href="${esc(M.mailHref(site0.email))}">${esc(site0.email)}</a>` : ''}
      <a href="${esc(site0.instagramUrl || 'https://www.instagram.com/mindful_tattva')}" target="_blank" rel="noopener">Instagram · @mindful_tattva ↗</a>
      <a href="${esc(M.mapsUrl(site0))}" target="_blank" rel="noopener">Campus map · CSMU Panvel ↗</a>`;
  }

  function openDrawer() {
    const drawer = M.$('#mtDrawer');
    const overlay = M.$('.mt-drawer-overlay');
    if (!drawer) return;
    modal.lastFocus = document.activeElement;
    drawer.hidden = false;
    overlay.hidden = false;
    requestAnimationFrame(() => {
      drawer.classList.add('open');
      overlay.classList.add('open');
      const first = drawer.querySelector('a, button');
      if (first) first.focus();
    });
    document.documentElement.classList.add('mt-no-scroll');
  }

  function closeDrawer() {
    const drawer = M.$('#mtDrawer');
    const overlay = M.$('.mt-drawer-overlay');
    if (!drawer || drawer.hidden) return;
    drawer.classList.remove('open');
    overlay.classList.remove('open');
    setTimeout(() => { drawer.hidden = true; overlay.hidden = true; }, 220);
    document.documentElement.classList.remove('mt-no-scroll');
  }

  /* ---------- ticker ---------- */

  function mountTicker() {
    const host = M.$('[data-ticker-host]');
    if (!host || M.$('[data-ticker]')) return;
    host.innerHTML = `
      <div class="mt-ticker" data-ticker role="region" aria-label="Next event">
        <div class="mt-ticker-inner">
          <span class="mt-ticker-badge"><i></i>Next event</span>
          <div class="mt-ticker-main"><strong data-ticker-title>Loading the next event…</strong><span data-ticker-meta></span></div>
          <span class="mt-ticker-seats" data-ticker-seats></span>
          <button class="mt-ticker-rsvp" type="button" data-ticker-rsvp hidden>RSVP ↗</button>
          <span class="mt-live" data-live-status>Connecting…</span>
        </div>
      </div>`;
  }

  function renderTicker(site) {
    const bar = M.$('[data-ticker]');
    if (!bar || !site) return;
    const next = M.openEvents(site)[0];
    const title = M.$('[data-ticker-title]', bar);
    const meta = M.$('[data-ticker-meta]', bar);
    const seats = M.$('[data-ticker-seats]', bar);
    const rsvp = M.$('[data-ticker-rsvp]', bar);
    if (!next) {
      title.textContent = 'No upcoming events yet — stay tuned.';
      meta.textContent = 'Follow @mindful_tattva for announcements';
      seats.textContent = '';
      rsvp.hidden = true;
      return;
    }
    title.textContent = next.title;
    meta.textContent = [D.displayDate(next), next.time, next.location].filter(Boolean).join(' · ');
    seats.textContent = M.seatText(next);
    rsvp.hidden = false;
    rsvp.dataset.eventId = next.id;
    const seatInfo = M.seatsOf(next);
    rsvp.disabled = !next.registrationOpen;
    rsvp.textContent = next.registrationOpen ? 'RSVP ↗' : (seatInfo.full ? 'Event full' : 'Closed');
  }

  /* ---------- modal ---------- */

  function buildModal() {
    if (modal.el) return modal.el;
    const el = document.createElement('div');
    el.className = 'mt-modal';
    el.hidden = true;
    el.innerHTML = `
      <div class="mt-modal-backdrop" data-mt-close></div>
      <div class="mt-modal-card" role="dialog" aria-modal="true" aria-labelledby="mtModalTitle" tabindex="-1">
        <button class="mt-modal-close" type="button" data-mt-close aria-label="Close">×</button>
        <div class="mt-modal-body" id="mtModalBody"></div>
      </div>`;
    document.body.appendChild(el);
    el.addEventListener('click', event => {
      if (event.target.closest('[data-mt-close]')) closeModal();
    });
    modal.el = el;
    return el;
  }

  function body() {
    buildModal();
    return M.$('#mtModalBody', modal.el);
  }

  function openModal() {
    buildModal();
    if (modal.el.hidden) modal.lastFocus = document.activeElement;
    modal.el.hidden = false;
    document.documentElement.classList.add('mt-no-scroll');
    const card = M.$('.mt-modal-card', modal.el);
    requestAnimationFrame(() => { modal.el.classList.add('open'); card.focus(); });
  }

  function closeModal() {
    if (!modal.el || modal.el.hidden) return;
    stopRosterPolling();
    modal.el.classList.remove('open');
    modal.el.hidden = true;
    document.documentElement.classList.remove('mt-no-scroll');
    if (modal.lastFocus && modal.lastFocus.focus) modal.lastFocus.focus();
  }

  function stopRosterPolling() {
    if (modal.rosterTimer) clearInterval(modal.rosterTimer);
    modal.rosterTimer = null;
  }

  function setAlert(node, message, tone) {
    if (!node) return;
    node.hidden = !message;
    node.textContent = message || '';
    node.dataset.tone = tone || 'error';
  }

  function scopeFieldsHtml(scope, values) {
    const v = values || {};
    const val = key => esc(v[key] || '');
    const yearOptions = D.YEAR_OPTIONS.map(item => `<option ${v.year === item ? 'selected' : ''}>${esc(item)}</option>`).join('');
    const semesterOptions = D.SEMESTER_OPTIONS.map(item => `<option ${v.semester === item ? 'selected' : ''}>${esc(item)}</option>`).join('');
    if (scope === 'intercollege') {
      return `
        <p class="mt-scope-note">Intercollege registration · for students from other colleges and universities.</p>
        <div class="mt-grid-2">
          <label class="mt-field"><span>External college / university name</span><input name="college" value="${val('college')}" placeholder="e.g. University of Mumbai" autocomplete="organization"><small class="mt-error" data-error-for="college"></small></label>
          <label class="mt-field"><span>PRN / college roll number</span><input name="rollNo" value="${val('rollNo')}" placeholder="Your PRN or roll number"><small class="mt-error" data-error-for="rollNo"></small></label>
        </div>
        <label class="mt-field"><span>Department / stream</span><input name="department" value="${val('department')}" placeholder="e.g. B.Sc. Psychology"><small class="mt-error" data-error-for="department"></small></label>`;
    }
    if (scope === 'interdepartmental') {
      return `
        <p class="mt-scope-note">Interdepartmental registration · for CSMU students from any department.</p>
        <div class="mt-grid-2">
          <label class="mt-field"><span>CSMU department / course</span><input name="department" value="${val('department')}" placeholder="e.g. B.A. Psychology"><small class="mt-error" data-error-for="department"></small></label>
          <label class="mt-field"><span>Student roll number</span><input name="rollNo" value="${val('rollNo')}" placeholder="Your CSMU roll number"><small class="mt-error" data-error-for="rollNo"></small></label>
        </div>
        <label class="mt-field"><span>Year of study</span><select name="year"><option value="">Choose your year</option>${yearOptions}</select><small class="mt-error" data-error-for="year"></small></label>`;
    }
    if (scope === 'departmental') {
      return `
        <p class="mt-scope-note">Departmental registration · for students of the Department of Applied Social Sciences.</p>
        <div class="mt-locked"><span>Department</span><strong>${esc(D.DEPARTMENT_NAME)}</strong><em>locked</em></div>
        <div class="mt-grid-2">
          <label class="mt-field"><span>CSMU roll number</span><input name="rollNo" value="${val('rollNo')}" placeholder="Your CSMU roll number"><small class="mt-error" data-error-for="rollNo"></small></label>
          <label class="mt-field"><span>Semester</span><select name="semester"><option value="">Choose your semester</option>${semesterOptions}</select><small class="mt-error" data-error-for="semester"></small></label>
        </div>`;
    }
    return '<p class="mt-scope-note">Choose a category above to see the details this registration needs.</p>';
  }

  function rosterCacheKey(eventId) {
    return `${ROSTER_KEY}:${eventId}`;
  }

  function rosterHtml(event, data, note) {
    const seats = M.seatsOf(event);
    const rows = (data.roster || []).map((row, index) => `
        <li><span class="mt-roster-index">${String(index + 1).padStart(2, '0')}</span><strong>${esc(row.name)}</strong><code>${esc(row.serial)}</code></li>`).join('');
    return `
      <div class="mt-roster-head"><strong>${esc(event.title)}</strong><span>${esc(M.seatText(event))}</span></div>
      ${note ? `<p class="mt-fine">${esc(note)}</p>` : ''}
      ${rows ? `<ol class="mt-roster-list" aria-live="polite">${rows}</ol>` : '<p class="mt-roster-empty">No one has registered yet. Be the first to claim a seat.</p>'}
      <p class="mt-fine">Live roster · refreshes every 10 seconds while open.</p>`;
  }

  async function loadRoster(eventId, target) {
    const event = (state.site && state.site.events || []).find(item => item.id === eventId);
    if (!event || !target) return;
    try {
      const data = await M.api(`/api/events/${encodeURIComponent(eventId)}/roster`);
      M.writeJson(rosterCacheKey(eventId), data);
      target.innerHTML = rosterHtml(event, data, '');
    } catch (error) {
      const cached = M.readJson(rosterCacheKey(eventId), null);
      if (cached) target.innerHTML = rosterHtml(event, cached, 'Showing the last saved roster — the server is not reachable right now.');
      else target.innerHTML = `<p class="mt-error-block">${esc(error.message)}</p>`;
    }
  }

  function startRosterPolling(eventId, target) {
    stopRosterPolling();
    modal.rosterTimer = setInterval(() => loadRoster(eventId, target), 10000);
  }

  function renderRoster(eventId) {
    const event = (state.site && state.site.events || []).find(item => item.id === eventId);
    if (!event) { M.toast && M.toast('That event is no longer listed.'); return; }
    modal.view = 'roster';
    modal.eventId = eventId;
    const seats = M.seatsOf(event);
    body().innerHTML = `
      <p class="eyebrow">Live roster</p>
      <h2 id="mtModalTitle" class="mt-modal-title">${esc(event.title)}</h2>
      <p class="mt-lede">${esc(D.displayDate(event))}${event.time ? ` · ${esc(event.time)}` : ''}${event.location ? ` · ${esc(event.location)}` : ''}</p>
      <div class="mt-roster-box" data-roster-box><p class="mt-roster-empty">Loading the roster…</p></div>
      <div class="mt-modal-actions">
        ${event.registrationOpen ? `<button class="solid-button" type="button" data-mt-register-for="${esc(event.id)}">Register for this event ↗</button>` : ''}
        <button class="outline-button" type="button" data-mt-close>Close</button>
      </div>
      <p class="mt-fine">${seats.capacity ? `${seats.filled} of ${seats.capacity} seats are taken.` : `${seats.filled} people registered so far.`}</p>`;
    const box = M.$('[data-roster-box]', modal.el);
    loadRoster(eventId, box);
    startRosterPolling(eventId, box);
    openModal();
  }

  function renderResult(pass, options) {
    const opts = options || {};
    modal.view = 'result';
    stopRosterPolling();
    rememberPass(pass);
    body().innerHTML = `
      <p class="eyebrow">${opts.duplicate ? 'Already registered' : 'Registration complete'}</p>
      <h2 id="mtModalTitle" class="mt-modal-title">${opts.duplicate ? 'Your pass is already here.' : 'Your pass is ready.'}</h2>
      <p class="mt-lede">${opts.duplicate ? 'You are already on the list for this event, so here is your existing pass. Download it below.' : 'Keep the serial number handy — the desk will ask for it. Paid entries are settled at the desk on the event day.'}</p>
      ${M.passCard(pass)}
      <div class="mt-modal-actions">
        <button class="solid-button" type="button" data-pass-download="${esc(pass.serial)}">Download pass (PNG) ↓</button>
        <button class="outline-button" type="button" data-mt-open="register">Register for another</button>
        <button class="outline-button" type="button" data-mt-close>Done</button>
      </div>
      <p class="mt-fine">Saved on this device under “My passes”.</p>`;
    openModal();
  }

  function renderLookupResults(passes, note) {
    const box = M.$('[data-lookup-results]', modal.el);
    if (!box) return;
    if (!passes.length) { box.innerHTML = `<p class="mt-note">${esc(note || 'No pass found for these details yet.')}</p>`; return; }
    passes.forEach(rememberPass);
    box.innerHTML = passes.map(pass => `${M.passCard(pass)}<div class="mt-modal-actions"><button class="solid-button" type="button" data-pass-download="${esc(pass.serial)}">Download PNG ↓</button></div>`).join('');
  }

  function renderPasses() {
    modal.view = 'passes';
    const list = M.myPasses();
    body().innerHTML = `
      <p class="eyebrow">On this device</p>
      <h2 id="mtModalTitle" class="mt-modal-title">My passes</h2>
      <p class="mt-lede">Passes you were issued on this browser. Download a PNG anytime; the server keeps the official record.</p>
      ${list.length ? list.map(item => `
        <div class="mt-saved-pass">
          <div><strong>${esc(item.pass.eventTitle)}</strong><span>${esc(item.serial)} · ${esc(item.pass.name)}</span></div>
          <div class="mt-saved-actions"><button class="solid-button small" type="button" data-pass-download="${esc(item.serial)}">PNG ↓</button><button class="outline-button small" type="button" data-pass-remove="${esc(item.serial)}">Remove</button></div>
        </div>`).join('') : '<p class="mt-note">No passes saved on this device yet. Register for an event to get one.</p>'}
      <div class="mt-modal-actions"><button class="solid-button" type="button" data-mt-open="register">Register for an event</button><button class="outline-button" type="button" data-mt-open="lookup">Find a pass by email</button></div>`;
    openModal();
  }

  function renderLookup() {
    modal.view = 'lookup';
    body().innerHTML = `
      <p class="eyebrow">Find my pass</p>
      <h2 id="mtModalTitle" class="mt-modal-title">Bring back a lost pass.</h2>
      <p class="mt-lede">Enter the email and mobile number you registered with. Your passes will appear here.</p>
      <form class="mt-form" data-lookup-form novalidate>
        <div class="mt-grid-2">
          <label class="mt-field"><span>Email</span><input name="email" type="email" autocomplete="email" placeholder="you@gmail.com"><small class="mt-error" data-error-for="email"></small></label>
          <label class="mt-field"><span>Mobile number</span><div class="mt-phone"><b>+91</b><input name="phone" inputmode="numeric" autocomplete="tel-national" placeholder="10-digit mobile"></div><small class="mt-error" data-error-for="phone"></small></label>
        </div>
        <div class="mt-form-alert" data-alert hidden></div>
        <button class="solid-button" type="submit">Find my passes ↗</button>
      </form>
      <div data-lookup-results></div>`;
    openModal();
  }

  function renderRegister(preset) {
    const site = state.site || { events: [], today: D.todayIso(), team: [] };
    const open = M.openEvents(site);
    const selected = preset && preset.eventId ? preset.eventId : '';
    const singles = open.map(event => {
      const seats = M.seatsOf(event);
      const disabled = !event.registrationOpen;
      const label = `${event.title} · ${D.displayDate(event)}${seats.full ? ' (full)' : ''}`;
      return `<option value="${esc(event.id)}" ${selected === event.id ? 'selected' : ''} ${disabled ? 'disabled' : ''}>${esc(label)}</option>`;
    }).join('');
    modal.view = 'register';
    body().innerHTML = `
      <p class="eyebrow">Event registration</p>
      <h2 id="mtModalTitle" class="mt-modal-title">Register and get your digital pass</h2>
      <p class="mt-lede">Pick the event you want to attend. You get your own serial number and a PNG pass to show at the desk.</p>
      <form class="mt-form" data-register-form novalidate>
        <label class="mt-field"><span>Event</span>
          <select name="target" required>
            <option value="">Choose an event…</option>
            ${singles}
          </select>
          <small class="mt-error" data-error-for="target"></small>
        </label>
        <div class="mt-panel" data-target-panel></div>
        <div class="mt-grid-2">
          <label class="mt-field"><span>Full name</span><input name="name" autocomplete="name" placeholder="As on your ID"><small class="mt-error" data-error-for="name"></small></label>
          <label class="mt-field"><span>Email</span><input name="email" type="email" autocomplete="email" placeholder="you@gmail.com"><small class="mt-error" data-error-for="email"></small></label>
        </div>
        <label class="mt-field"><span>Mobile number (India)</span><div class="mt-phone"><b>+91</b><input name="phone" inputmode="numeric" autocomplete="tel-national" placeholder="10-digit mobile"></div><small class="mt-error" data-error-for="phone"></small></label>
        <fieldset class="mt-scope" data-scope-fields><legend>Your details</legend><p class="mt-scope-note">Choose an event to see its fields.</p></fieldset>
        <div class="mt-form-alert" data-alert hidden></div>
        <button class="solid-button" type="submit" data-submit disabled>Register and get my pass ↗</button>
        <p class="mt-fine">Placeholder emails and repeated or sequential mobile numbers are rejected. One registration per event per email or phone.</p>
      </form>
      <div class="mt-roster-toggle-wrap" data-roster-toggle-wrap hidden>
        <button class="outline-button small" type="button" data-roster-toggle aria-expanded="false">Show live roster</button>
        <div class="mt-roster-box" data-roster-box hidden></div>
      </div>
      <p class="mt-fine" style="margin-top:14px">Paid events are settled at the desk on the event day. Each event is registered for on its own.</p>`;
    const form = M.$('[data-register-form]', modal.el);
    const target = form.elements.target;
    if (selected) refreshTarget(form, site);
    target.addEventListener('change', () => refreshTarget(form, site));
    M.$('[data-roster-toggle]', modal.el).addEventListener('click', () => toggleRosterInModal(form));
    form.addEventListener('submit', event => { event.preventDefault(); submitRegistration(form, site); });
    openModal();
  }

  function currentScope(form, site) {
    const target = form.elements.target.value;
    if (!target) return '';
    const event = (site.events || []).find(item => item.id === target);
    return event ? event.scope : '';
  }

  function refreshTarget(form, site) {
    const target = form.elements.target.value;
    const panel = M.$('[data-target-panel]', modal.el);
    const rosterWrap = M.$('[data-roster-toggle-wrap]', modal.el);
    const rosterBox = M.$('[data-roster-box]', modal.el);
    stopRosterPolling();
    if (rosterBox) { rosterBox.hidden = true; rosterBox.innerHTML = ''; }
    const toggle = M.$('[data-roster-toggle]', modal.el);
    if (toggle) { toggle.setAttribute('aria-expanded', 'false'); toggle.textContent = 'Show live roster'; }
    if (!target) {
      panel.innerHTML = '';
      rosterWrap.hidden = true;
    } else {
      const event = (site.events || []).find(item => item.id === target);
      if (!event) return;
      panel.innerHTML = `
        <div class="mt-event-facts">
          <div><span>When</span><strong>${esc(D.displayDate(event))}${event.time ? ` · ${esc(event.time)}` : ''}</strong></div>
          <div><span>Where</span><strong>${esc(event.location || 'Venue to be announced')}</strong></div>
          <div><span>Entry</span><strong>${esc(M.feeText(event))}</strong></div>
          <div><span>Seats</span><strong>${esc(M.seatText(event))}</strong></div>
        </div>
        <div class="mt-event-facts-foot">${event.instructor ? `<span>With ${esc(event.instructor)}</span>` : ''}${M.brochureLink(event, 'outline-button small')}</div>`;
      rosterWrap.hidden = false;
    }
    refreshScope(form, site);
  }

  function refreshScope(form, site) {
    const scope = currentScope(form, site);
    const values = {};
    for (const element of form.elements) if (element.name) values[element.name] = element.value;
    const box = M.$('[data-scope-fields]', modal.el);
    box.innerHTML = `<legend>Your details</legend>${scopeFieldsHtml(scope, values)}`;
    const submit = M.$('[data-submit]', modal.el);
    submit.disabled = !scope || !form.elements.target.value;
    const target = form.elements.target.value;
    if (target) {
      const event = (site.events || []).find(item => item.id === target);
      if (event && !event.registrationOpen) submit.disabled = true;
    }
  }

  function toggleRosterInModal(form) {
    const toggle = M.$('[data-roster-toggle]', modal.el);
    const box = M.$('[data-roster-box]', modal.el);
    const eventId = form.elements.target.value;
    if (!eventId) return;
    const showing = box.hidden === false;
    if (showing) {
      stopRosterPolling();
      box.hidden = true;
      toggle.setAttribute('aria-expanded', 'false');
      toggle.textContent = 'Show live roster';
      return;
    }
    box.hidden = false;
    box.innerHTML = '<p class="mt-roster-empty">Loading the roster…</p>';
    toggle.setAttribute('aria-expanded', 'true');
    toggle.textContent = 'Hide live roster';
    loadRoster(eventId, box);
    startRosterPolling(eventId, box);
  }

  function readRegisterForm(form) {
    const values = {};
    for (const element of form.elements) {
      if (element.name && element.type !== 'submit') values[element.name] = element.value;
    }
    return values;
  }

  function showFieldErrors(form, fields) {
    M.$$('.mt-error', modal.el).forEach(node => { node.textContent = ''; });
    M.$$('.mt-field', modal.el).forEach(node => node.classList.remove('has-error'));
    Object.keys(fields || {}).forEach(key => {
      const node = M.$(`[data-error-for="${key}"]`, modal.el);
      if (node) {
        node.textContent = fields[key];
        node.closest('.mt-field') && node.closest('.mt-field').classList.add('has-error');
      }
    });
  }

  async function submitRegistration(form, site) {
    const alert = M.$('[data-alert]', modal.el);
    const submit = M.$('[data-submit]', modal.el);
    setAlert(alert, '');
    const values = readRegisterForm(form);
    const scope = currentScope(form, site);
    const check = D.validateRegistrationFields(values, scope);
    const fields = { ...check.errors };
    if (!values.target) fields.target = 'Choose an event.';
    if (Object.keys(fields).length) {
      showFieldErrors(form, fields);
      setAlert(alert, 'Please correct the highlighted fields.');
      return;
    }
    submit.disabled = true;
    submit.textContent = 'Issuing your pass…';
    const payload = { ...values, ...check.value };
    try {
      const result = await M.api('/api/registrations', { method: 'POST', body: payload });
      if (result.pass) {
        await M.loadSite();
        renderResult(result.pass, { skipped: result.skipped || [] });
      }
    } catch (error) {
      const data = error.payload || {};
      if (data.code === 'duplicate' && data.passes && data.passes.length) {
        await M.loadSite();
        renderResult(data.passes[0], { duplicate: true });
        return;
      }
      if (data.fields) showFieldErrors(form, data.fields);
      const message = error.network
        ? 'We could not reach the club server, so nothing was registered. Please check your connection and try again.'
        : (data.error || 'Something went wrong. Nothing was registered — please try again.');
      setAlert(alert, message);
      submit.disabled = false;
      submit.textContent = 'Register and get my pass ↗';
    }
  }

  /* ---------- global handlers ---------- */

  function bindGlobalHandlers() {
    document.addEventListener('click', event => {
      const target = event.target;
      const openButton = target.closest('[data-mt-open]');
      if (openButton) {
        const kind = openButton.dataset.mtOpen;
        closeDrawer();
        if (kind === 'register') renderRegister({});
        if (kind === 'lookup') renderLookup();
        if (kind === 'passes') renderPasses();
        return;
      }
      const registerButton = target.closest('[data-register]');
      if (registerButton) { renderRegister({ eventId: registerButton.dataset.register }); return; }
      const registerFor = target.closest('[data-mt-register-for]');
      if (registerFor) { renderRegister({ eventId: registerFor.dataset.mtRegisterFor }); return; }
      const rosterButton = target.closest('[data-roster]');
      if (rosterButton) { renderRoster(rosterButton.dataset.roster); return; }
      const rsvp = target.closest('[data-ticker-rsvp]');
      if (rsvp && rsvp.dataset.eventId) { renderRegister({ eventId: rsvp.dataset.eventId }); return; }
      const download = target.closest('[data-pass-download]');
      if (download) {
        download.disabled = true;
        M.downloadPass(download.dataset.passDownload)
          .catch(error => M.toast(error.message))
          .finally(() => { download.disabled = false; });
        return;
      }
      const remove = target.closest('[data-pass-remove]');
      if (remove) { forgetPass(remove.dataset.passRemove); renderPasses(); return; }
      if (target.closest('[data-mt-drawer-close]')) { closeDrawer(); return; }
      if (target.closest('[data-mt-drawer-open]')) { openDrawer(); return; }
      if (target.closest('[data-mt-menu]')) { openDrawer(); return; }
    });

    document.addEventListener('submit', event => {
      if (!event.target.matches('[data-lookup-form]')) return;
      event.preventDefault();
      lookupPasses(event.target);
    });

    document.addEventListener('keydown', event => {
      if (event.key !== 'Escape') return;
      if (modal.el && !modal.el.hidden) closeModal();
      else closeDrawer();
    });
  }

  async function lookupPasses(form) {
    const alert = M.$('[data-alert]', modal.el);
    const email = form.elements.email.value;
    const phone = form.elements.phone.value;
    const check = { email: D.validateEmail(email), phone: D.normalizeIndianMobile(phone) };
    const fields = {};
    if (!check.email.ok) fields.email = check.email.error;
    if (!check.phone.ok) fields.phone = check.phone.error;
    showFieldErrors(form, fields);
    if (Object.keys(fields).length) { setAlert(alert, 'Please check the email and mobile number.'); return; }
    setAlert(alert, '');
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
      const result = await M.api('/api/passes/lookup', { method: 'POST', body: { email, phone } });
      renderLookupResults(result.passes || [], result.note);
    } catch (error) {
      setAlert(alert, error.network ? 'We could not reach the club server. Please try again in a moment.' : (error.message || 'The lookup could not be completed.'));
    } finally {
      button.disabled = false;
    }
  }

  M.toast = message => {
    const node = document.createElement('div');
    node.className = 'mt-toast';
    node.setAttribute('role', 'status');
    node.textContent = message;
    document.body.appendChild(node);
    setTimeout(() => node.classList.add('show'), 10);
    setTimeout(() => { node.classList.remove('show'); setTimeout(() => node.remove(), 300); }, 3800);
  };

  /* ---------- page bootstrap ---------- */

  M.initPublic = (options) => {
    const opts = options || {};
    M.ready(() => {
      buildDrawer();
      buildModal();
      mountTicker();
      bindGlobalHandlers();
      M.onSite(site => {
        renderTicker(site);
        renderDrawerContacts(site);
        if (typeof opts.render === 'function') opts.render(site, state.source);
      });
      updateStatus();
      M.loadSite().then(() => connectLive());
      const mobileMenu = M.$('#menuButton');
      if (mobileMenu) mobileMenu.setAttribute('data-mt-menu', '');
      document.addEventListener('visibilitychange', () => {
        if (!document.hidden && state.source !== 'live') M.loadSite();
      });
    });
  };

  M.openRegisterFor = eventId => renderRegister({ eventId });
  M.openLookup = () => renderLookup();
  M.openPasses = () => renderPasses();
  M.openDrawer = openDrawer;
  M.closeModal = closeModal;
  M.setPassIndex = rememberPass;
  M.volunteerStatusSummary = () => M.volunteerApplications();
})(window.MT = window.MT || {});
