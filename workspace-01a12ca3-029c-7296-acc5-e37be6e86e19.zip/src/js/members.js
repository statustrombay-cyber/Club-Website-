/* Members directory: three fixed groups, filter chips, clickable tel/mailto links. */
(function (M) {
  'use strict';

  const esc = M.esc;
  const GROUPS = [
    { id: 'management', kicker: '01 · Core', title: 'Core Committee', empty: 'Core Committee members will appear here once they are added.' },
    { id: 'heads', kicker: '02 · Organizing team', title: 'Head Committee', empty: 'Head Committee will be added soon.' },
    { id: 'volunteers', kicker: '03 · Community', title: 'Volunteers', empty: 'The circle is open. Volunteers will be listed here as they join.' }
  ];
  let activeFilter = 'all';

  function card(member, index, group) {
    const image = M.bgStyle(member.image);
    const number = `<span class="member-number">${String(index + 1).padStart(2, '0')}</span>`;
    const photo = image
      ? `<div class="member-photo" role="img" aria-label="${esc(member.name)} photo" style="${esc(image)}"></div>`
      : `<div class="member-photo member-photo-placeholder" role="img" aria-label="${esc(member.name)} · Mindful Tattva placeholder">MT</div>`;
    const phone = M.telHref(member.phone);
    const phoneLink = phone ? `<a class="member-phone" href="${esc(phone)}">${esc(M.phoneDisplay(member.phone))} ↗</a>` : '';
    // Volunteers show only name and phone. Officers also show email.
    const email = group.id !== 'volunteers' ? M.mailHref(member.email) : '';
    const emailLink = email ? `<a class="member-email" href="${esc(email)}">${esc(member.email)} ↗</a>` : '';
    return `<article class="member-card has-photo${group.id === 'volunteers' ? ' member-card-volunteer' : ''}" data-group="${esc(group.id)}">${number}${photo}<h4>${esc(member.name)}</h4><div class="member-role">${esc(member.role || group.title)}</div>${phoneLink}${emailLink}</article>`;
  }

  function render(site) {
    const box = document.getElementById('memberGroups');
    if (!box) return;
    const team = site.team || [];
    const sections = GROUPS.map(group => {
      const members = team.filter(member => member.group === group.id);
      const cards = members.map((member, index) => card(member, index, group)).join('');
      const body = cards
        ? `<div class="member-cards">${cards}</div>`
        : `<div class="member-empty"><div><strong>${esc(group.empty)}</strong><p>Add members from the Content Studio.</p></div></div>`;
      const hidden = activeFilter !== 'all' && activeFilter !== group.id;
      return `<section class="member-group" data-group-section="${esc(group.id)}"${hidden ? ' hidden' : ''}><div class="member-group-head"><div><div class="member-group-kicker">${esc(group.kicker)}</div><h3>${esc(group.title)}</h3></div><span class="mt-count">${members.length} ${members.length === 1 ? 'member' : 'members'}</span></div>${body}</section>`;
    }).join('');
    M.setHtml(box, sections);
    const counts = document.getElementById('memberTotal');
    if (counts) counts.textContent = `${team.length} member${team.length === 1 ? '' : 's'} in the directory`;
  }

  function bindFilters() {
    const bar = document.getElementById('memberFilters');
    if (!bar) return;
    bar.addEventListener('click', event => {
      const button = event.target.closest('[data-filter]');
      if (!button) return;
      activeFilter = button.dataset.filter;
      M.$$('[data-filter]', bar).forEach(item => item.setAttribute('aria-pressed', String(item === button)));
      M.$$('[data-group-section]').forEach(section => {
        section.hidden = activeFilter !== 'all' && activeFilter !== section.dataset.groupSection;
      });
    });
  }

  M.initPublic({ render });
  M.ready(bindFilters);
})(window.MT);
