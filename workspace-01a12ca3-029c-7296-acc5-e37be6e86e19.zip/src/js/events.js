/* Events page: search and filter by keyword, venue, instructor, category and scope. */
(function (M) {
  'use strict';

  const D = window.MTDomain;
  const esc = M.esc;
  const controls = {};
  let pendingOpen = null;

  // Rebuilds a dropdown only when its options change, so an open dropdown is not disturbed by live updates.
  function fillSelect(select, values, labelFor) {
    if (!select) return;
    const signature = JSON.stringify(values);
    if (select.dataset.signature === signature) return;
    const current = select.value;
    select.dataset.signature = signature;
    select.innerHTML = `<option value="">${esc(labelFor.all)}</option>` + values.map(value => `<option value="${esc(value)}">${esc(labelFor.map ? labelFor.map(value) : value)}</option>`).join('');
    if (values.includes(current)) select.value = current;
  }

  function matches(event, filters) {
    if (filters.venue && event.location !== filters.venue) return false;
    if (filters.instructor && event.instructor !== filters.instructor) return false;
    if (filters.category && (event.category || event.kicker) !== filters.category) return false;
    if (filters.scope && event.scope !== filters.scope) return false;
    if (filters.keyword) {
      const haystack = [event.title, event.description, event.location, event.instructor, event.category, event.kicker, D.SCOPE_LABEL[event.scope]]
        .filter(Boolean).join(' ').toLowerCase();
      if (!filters.keyword.split(/\s+/).every(word => haystack.includes(word))) return false;
    }
    return true;
  }

  function currentFilters() {
    return {
      keyword: (controls.keyword ? controls.keyword.value : '').trim().toLowerCase(),
      venue: controls.venue ? controls.venue.value : '',
      instructor: controls.instructor ? controls.instructor.value : '',
      category: controls.category ? controls.category.value : '',
      scope: controls.scope ? controls.scope.value : '',
      includePast: Boolean(controls.past && controls.past.checked)
    };
  }

  let lastResultsHtml = null;

  function render(site) {
    const results = document.getElementById('eventResults');
    if (!results) return;
    const today = site.today || D.todayIso();
    const published = (site.events || []).filter(event => event.published);
    const pool = published
      .filter(event => controls.past && controls.past.checked ? true : D.isUpcomingEvent(event, today))
      .sort((a, b) => String(D.eventIsoDate(a) || '9999-12-31').localeCompare(String(D.eventIsoDate(b) || '9999-12-31')));
    const uniq = key => [...new Set(published.map(event => event[key]).filter(Boolean))].sort((a, b) => a.localeCompare(b));
    fillSelect(controls.venue, uniq('location'), { all: 'All venues' });
    fillSelect(controls.instructor, uniq('instructor'), { all: 'All instructors' });
    fillSelect(controls.category, [...new Set(published.map(event => event.category || event.kicker).filter(Boolean))].sort(), { all: 'All categories' });

    if (pendingOpen) {
      const request = pendingOpen;
      pendingOpen = null;
      if (request.register) M.openRegisterFor(request.register);
    }
    const filters = currentFilters();
    const shown = pool.filter(event => matches(event, filters));
    const count = document.getElementById('eventCount');
    if (count) count.textContent = `${shown.length} of ${pool.length} event${pool.length === 1 ? '' : 's'} shown`;
    const html = shown.length
      ? shown.map(event => M.eventCard(event)).join('')
      : `<div class="mt-empty-wide"><strong>No events match these filters.</strong><p>Try a different keyword, or clear the filters to see every upcoming event.</p><button class="outline-button small" type="button" data-clear-filters>Clear filters</button></div>`;
    // Only touch the DOM when the list really changed: re-rendering on a text field's blur would swap out a button mid-click.
    if (html !== lastResultsHtml) {
      results.innerHTML = html;
      lastResultsHtml = html;
    }
  }

  function bind() {
    controls.keyword = document.getElementById('filterKeyword');
    controls.venue = document.getElementById('filterVenue');
    controls.instructor = document.getElementById('filterInstructor');
    controls.category = document.getElementById('filterCategory');
    controls.scope = document.getElementById('filterScope');
    controls.past = document.getElementById('filterPast');
    const form = document.getElementById('eventFilters');
    if (!form) return;
    const rerender = () => { if (M.site()) render(M.site()); };
    form.addEventListener('input', rerender);
    form.addEventListener('change', rerender);
    form.addEventListener('submit', event => event.preventDefault());
    document.addEventListener('click', event => {
      if (!event.target.closest('[data-clear-filters]')) return;
      form.reset();
      rerender();
    });
    const params = new URLSearchParams(window.location.search);
    if (params.get('q') && controls.keyword) controls.keyword.value = params.get('q');
    if (params.get('scope') && controls.scope) controls.scope.value = params.get('scope');
    pendingOpen = { register: params.get('register') || '' };
    rerender();
  }

  M.initPublic({ render });
  M.ready(bind);
})(window.MT);
