/* Gallery: photo slider and archive, driven by the saved gallery items. */
(function (M) {
  'use strict';

  const esc = M.esc;
  let index = 0;
  let timer = null;
  let items = [];

  function caption(item) {
    return item.title || item.caption || 'Mindful Tattva moment';
  }

  function showSlide() {
    const stage = document.getElementById('galleryStage');
    const image = document.getElementById('galleryStageImage');
    if (!stage || !image) return;
    if (!items.length) {
      image.setAttribute('style', '');
      image.innerHTML = '<span class="gallery-placeholder">No event photos yet</span>';
      document.getElementById('galleryStageCaption').textContent = 'Your first club memory is coming soon';
      document.getElementById('galleryStageKicker').textContent = 'Mindful Tattva memory';
      document.getElementById('galleryCounter').textContent = '00 / 00';
      return;
    }
    const item = items[index];
    const bg = M.bgStyle(item.image);
    image.setAttribute('style', bg);
    image.setAttribute('aria-label', item.alt || caption(item));
    image.innerHTML = bg ? '' : '<span class="gallery-placeholder">Photo placeholder</span>';
    document.getElementById('galleryStageCaption').textContent = caption(item);
    document.getElementById('galleryStageKicker').textContent = item.category || 'Mindful Tattva memory';
    document.getElementById('galleryCounter').textContent = `${String(index + 1).padStart(2, '0')} / ${String(items.length).padStart(2, '0')}`;
  }

  function step(delta) {
    if (!items.length) return;
    index = (index + delta + items.length) % items.length;
    showSlide();
  }

  function startTimer() {
    stopTimer();
    if (items.length > 1) timer = setInterval(() => step(1), 6500);
  }

  function stopTimer() {
    if (timer) clearInterval(timer);
    timer = null;
  }

  function renderArchive() {
    const grid = document.getElementById('archiveGrid');
    if (!grid) return;
    if (!items.length) {
      M.setHtml(grid, '<div class="gallery-empty"><div><strong>No event photos yet.</strong><p>Photos added in the Content Studio appear here automatically.</p></div></div>');
      return;
    }
    M.setHtml(grid, items.map((item, position) => {
      const bg = M.bgStyle(item.image);
      const link = /^https:\/\//i.test(item.url || '') ? `<a class="archive-link" href="${esc(item.url)}" target="_blank" rel="noopener">Open link ↗</a>` : '';
      return `
        <figure class="archive-card" data-slide="${position}">
          <button class="archive-open" type="button" data-slide-open="${position}" aria-label="Show ${esc(caption(item))}">
            <span class="archive-visual${bg ? ' has-image' : ''}" style="${esc(bg)}">${bg ? '' : '<span class="gallery-placeholder">Photo placeholder</span>'}</span>
          </button>
          <figcaption><small>${esc(item.category || 'Event')}</small><strong>${esc(caption(item))}</strong>${item.caption && item.caption !== caption(item) ? `<span>${esc(item.caption)}</span>` : ''}${link}</figcaption>
        </figure>`;
    }).join(''));
  }

  function render(site) {
    items = (site.gallery || []).filter(item => item.image || item.title || item.caption);
    if (index >= items.length) index = 0;
    showSlide();
    renderArchive();
    startTimer();
  }

  M.ready(() => {
    const prev = document.getElementById('galleryPrev');
    const next = document.getElementById('galleryNext');
    const stage = document.getElementById('galleryStage');
    if (prev) prev.addEventListener('click', () => { step(-1); startTimer(); });
    if (next) next.addEventListener('click', () => { step(1); startTimer(); });
    if (stage) {
      stage.addEventListener('mouseenter', stopTimer);
      stage.addEventListener('mouseleave', startTimer);
    }
    document.addEventListener('click', event => {
      const open = event.target.closest('[data-slide-open]');
      if (!open) return;
      index = Number(open.dataset.slideOpen) || 0;
      showSlide();
      startTimer();
      const target = document.getElementById('galleryStage');
      if (target) target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  });

  M.initPublic({ render });
})(window.MT);
