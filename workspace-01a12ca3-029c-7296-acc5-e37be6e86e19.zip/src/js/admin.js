/* Content Studio: password-gated officer console. Server is the source of truth; drafts are kept locally when offline. */
(function (M) {
  'use strict';

  const D = window.MTDomain;
  const esc = M.esc;
  const TOKEN_KEY = 'mt-admin-token';
  const DRAFTS_KEY = 'mt-admin-drafts-v1';
  const MAX_PDF_BYTES = 8 * 1024 * 1024;
  let token = '';
  try { token = window.sessionStorage.getItem(TOKEN_KEY) || ''; } catch (_) { token = ''; }
  M.adminToken = () => token;

  const state = { site: null, submissions: [], registrations: [] };
  const $ = (selector, root) => M.$(selector, root);
  const $$ = (selector, root) => M.$$(selector, root);

  /* ---------- session ---------- */

  function showGate(message) {
    $('#studio').hidden = true;
    $('#loginGate').classList.remove('hidden');
    $('#loginError').textContent = message || '';
  }

  function showStudio() {
    $('#loginGate').classList.add('hidden');
    $('#studio').hidden = false;
  }

  function endSession(message) {
    token = '';
    try { window.sessionStorage.removeItem(TOKEN_KEY); } catch (_) { /* ignore */ }
    showGate(message);
  }

  // Authenticated request. A 401 ends the session and asks for the password again.
  function call(url, options) {
    return M.api(url, Object.assign({ auth: true }, options || {})).catch(error => {
      if (error.status === 401) endSession('Your Studio session has ended. Please sign in again.');
      throw error;
    });
  }

  function flash(message, tone) {
    const node = $('#saveMessage');
    if (!node) return;
    node.textContent = message;
    node.dataset.tone = tone || 'ok';
    clearTimeout(flash.timer);
    flash.timer = setTimeout(() => { node.textContent = ''; }, 9000);
  }

  async function verifySession() {
    if (!token) { showGate(''); return; }
    try {
      const session = await M.api('/api/session', { auth: true });
      if (!session.authenticated) throw new Error('Session ended');
      showStudio();
      await refreshAll();
    } catch (error) {
      if (error.network) { showGate('We could not reach the server. Please try again shortly.'); return; }
      endSession('');
    }
  }

  /* ---------- data loading ---------- */

  // Public snapshot for display, with the full member records (incl. volunteer contacts) for editing.
  async function loadSite() {
    const site = await M.api('/api/site');
    site.team = await call('/api/admin/team');
    state.site = site;
  }

  async function refreshAll() {
    try {
      await loadSite();
      const [submissions, registrations] = await Promise.all([
        call('/api/submissions'),
        call('/api/admin/registrations')
      ]);
      state.submissions = submissions;
      state.registrations = registrations;
      renderAll();
      $('#syncStatus').textContent = `Synced ${new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit' }).format(new Date())}`;
    } catch (error) {
      if (error.network) flash('The club server cannot be reached. You can still read drafts saved on this device.', 'warn');
      else if (error.status !== 401) flash(error.message, 'error');
      renderAll();
    }
  }

  // Re-renders an editor only when its data changed. Unsaved "new" rows survive the refresh.
  function renderEditor(box, signature, html) {
    if (!box || box.dataset.sig === signature) return;
    box.dataset.sig = signature;
    const pending = Array.from(box.querySelectorAll('article[data-id="new"]'));
    box.innerHTML = html;
    pending.reverse().forEach(node => box.prepend(node));
  }

  function renderAll() {
    renderOverview();
    renderSite();
    renderMembers();
    renderEvents();
    renderGallery();
    renderVolunteers();
    renderRegistrations();
    renderInbox();
    renderDrafts();
  }

  /* ---------- drafts (local fallback, never shown as published) ---------- */

  const drafts = () => M.readJson(DRAFTS_KEY, []);

  function saveDraft(kind, id, payload, label) {
    const list = drafts().filter(item => !(item.kind === kind && item.id === id && id));
    list.unshift({ kind, id: id || '', payload, label: label || kind, savedAt: new Date().toISOString() });
    M.writeJson(DRAFTS_KEY, list.slice(0, 30));
    renderDrafts();
  }

  function renderDrafts() {
    const box = $('#draftsList');
    if (!box) return;
    const list = drafts();
    box.innerHTML = list.length ? list.map((draft, index) => `
      <article class="submission-card draft-card">
        <div class="submission-card-head"><span class="submission-type">${esc(draft.kind)} draft</span><span class="submission-time">${esc(M.issuedStamp(draft.savedAt))}</span></div>
        <h3>${esc(draft.label)}</h3>
        <p>Not published yet. It stays on this device until the server accepts it.</p>
        <div class="item-actions"><button class="solid-button small" type="button" data-draft-publish="${index}">Publish now</button><button class="text-button remove-button" type="button" data-draft-delete="${index}">Delete draft</button></div>
      </article>`).join('') : '<p class="empty-note">No drafts on this device. Changes that fail to reach the server are kept here.</p>';
  }

  /* ---------- overview ---------- */

  function renderOverview() {
    const box = $('#overviewStats');
    if (!box || !state.site) return;
    const today = state.site.today;
    const events = state.site.events || [];
    const upcoming = events.filter(event => event.published && D.isUpcomingEvent(event, today));
    const seats = events.reduce((sum, event) => sum + ((event.seats && event.seats.filled) || 0), 0);
    const pending = state.submissions.filter(item => item.type === 'volunteer' && item.status !== 'approved').length;
    const members = state.site.team || [];
    const stat = (value, label) => `<div class="stat-tile"><strong>${esc(value)}</strong><span>${esc(label)}</span></div>`;
    box.innerHTML = [
      stat(upcoming.length, 'Upcoming published events'),
      stat(state.registrations.length, 'Registrations on record'),
      stat(seats, 'Seats taken across events'),
      stat(pending, 'Volunteer applications to review'),
      stat(members.length, 'Members in the directory'),
      stat((state.site.gallery || []).length, 'Event photos')
    ].join('');
  }

  /* ---------- site & Instagram ---------- */

  function renderSite() {
    const form = $('#siteForm');
    if (!form || !state.site) return;
    const s = state.site.site || {};
    for (const field of ['instagramHandle', 'instagramUrl', 'email', 'clubPhone', 'announcement', 'intro']) {
      if (form.elements[field]) form.elements[field].value = s[field] || '';
    }
  }

  async function saveSite() {
    const form = $('#siteForm');
    const instagramUrl = form.elements.instagramUrl.value.trim();
    const email = form.elements.email.value.trim();
    const problems = [];
    if (instagramUrl && !/^https:\/\//i.test(instagramUrl)) problems.push('The Instagram link must start with https://');
    if (email && !D.validateEmail(email).ok) problems.push(D.validateEmail(email).error);
    if (form.elements.clubPhone.value.trim() && !D.normalizeIndianMobile(form.elements.clubPhone.value).ok) problems.push(D.normalizeIndianMobile(form.elements.clubPhone.value).error);
    if (problems.length) { flash(problems[0], 'error'); return; }
    const body = {
      instagramHandle: form.elements.instagramHandle.value.trim(),
      instagramUrl,
      email,
      clubPhone: form.elements.clubPhone.value.trim() ? D.normalizeIndianMobile(form.elements.clubPhone.value).display : '',
      announcement: form.elements.announcement.value.trim(),
      intro: form.elements.intro.value.trim()
    };
    try {
      await call('/api/site', { method: 'PUT', body });
      await loadSite();
      renderSite();
      flash('Instagram and contact details saved. The public site is updated.');
    } catch (error) {
      flash(error.network ? 'Not saved — the server cannot be reached. Nothing was published.' : error.message, 'error');
    }
  }

  /* ---------- images ---------- */

  function resizeImage(dataUrl, maxSide, square) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => {
        const sourceSide = square ? Math.min(image.naturalWidth, image.naturalHeight) : Math.max(image.naturalWidth, image.naturalHeight);
        if (!sourceSide) { reject(new Error('That picture is empty. Please choose another photo.')); return; }
        const sx = square ? (image.naturalWidth - sourceSide) / 2 : 0;
        const sy = square ? (image.naturalHeight - sourceSide) / 2 : 0;
        const sw = square ? sourceSide : image.naturalWidth;
        const sh = square ? sourceSide : image.naturalHeight;
        const scale = Math.min(1, maxSide / sourceSide);
        const canvas = document.createElement('canvas');
        canvas.width = Math.round((square ? sourceSide : sw) * scale);
        canvas.height = Math.round((square ? sourceSide : sh) * scale);
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fffaf1';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(image, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.88));
      };
      image.onerror = () => reject(new Error('That picture could not be opened. Use a PNG, JPG or WebP photo.'));
      image.src = dataUrl;
    });
  }

  async function imageFromInput(input, options) {
    const file = input.files && input.files[0];
    if (!file) return null;
    if (!/^image\/(png|jpe?g|webp)$/i.test(file.type)) throw new Error('Photos must be PNG, JPG or WebP files.');
    if (file.size > 12 * 1024 * 1024) throw new Error('That photo is over 12 MB. Please choose a smaller file.');
    const raw = await M.readFileAsDataUrl(file);
    return resizeImage(raw, options.maxSide, options.square);
  }

  async function pdfFromInput(input) {
    const file = input.files && input.files[0];
    if (!file) return null;
    if (file.type !== 'application/pdf' && !/\.pdf$/i.test(file.name)) throw new Error('Brochures must be PDF files.');
    if (file.size > MAX_PDF_BYTES) throw new Error('The brochure PDF must be 8 MB or smaller.');
    const dataUrl = await M.readFileAsDataUrl(file);
    return { data: dataUrl.replace(/^data:[^,]*,/, 'data:application/pdf;base64,'), name: file.name.slice(0, 120) };
  }

  function bindUploads() {
    document.addEventListener('change', async event => {
      const input = event.target;
      if (!input.matches || !input.matches('[data-upload]')) return;
      const item = input.closest('[data-kind]');
      if (!item) return;
      const kind = input.dataset.upload;
      const hidden = item.querySelector(`[data-field="${kind}"]`);
      const preview = item.querySelector('[data-preview]');
      try {
        if (kind === 'attachment') {
          const pdf = await pdfFromInput(input);
          if (!pdf) return;
          item.querySelector('[data-field="attachment"]').value = pdf.data;
          item.querySelector('[data-field="attachmentName"]').value = pdf.name;
          item.querySelector('[data-brochure-name]').textContent = `Brochure ready: ${pdf.name}`;
          return;
        }
        const options = item.dataset.kind === 'member' ? { maxSide: 900, square: true } : { maxSide: 1400, square: false };
        const image = await imageFromInput(input, options);
        if (!image) return;
        if (hidden) hidden.value = image;
        if (preview) preview.innerHTML = `<img src="${esc(image)}" alt="">`;
        if (preview) preview.classList.remove('empty');
        item.querySelector('[data-action="clear-photo"]') && item.querySelector('[data-action="clear-photo"]').removeAttribute('disabled');
      } catch (error) {
        showItemError(item, error.message);
      }
    });
  }

  /* ---------- members ---------- */

  function memberRow(member, index) {
    const isNew = !member;
    const m = member || { name: '', role: '', group: 'management', phone: '', email: '', bio: '', image: '', showOnHome: true };
    const image = M.safeImage(m.image);
    return `
      <article class="editor-item" data-kind="member" data-id="${esc(isNew ? 'new' : m.id)}">
        <div class="item-top">
          <span class="item-label">${isNew ? 'New member' : `Member ${String(index + 1).padStart(2, '0')} · ${esc(D.GROUP_LABEL[m.group] || '')}`}</span>
          <div class="item-actions">
            <button class="text-button" type="button" data-action="save-member">Save</button>
            <button class="text-button remove-button" type="button" data-action="delete-member">${isNew ? 'Discard' : 'Delete'}</button>
          </div>
        </div>
        <div class="form-grid two compact">
          <label>Name<input data-field="name" value="${esc(m.name)}" maxlength="80" placeholder="Full name"></label>
          <label>Role<input data-field="role" value="${esc(m.role)}" maxlength="80" placeholder="e.g. President"></label>
          <label>Member group<select data-field="group">${D.GROUP_IDS.map(id => `<option value="${id}" ${m.group === id ? 'selected' : ''}>${esc(D.GROUP_LABEL[id])}</option>`).join('')}</select></label>
          <label>Mobile number (India)<input data-field="phone" value="${esc(M.phoneDisplay(m.phone))}" inputmode="tel" placeholder="+91 98765 43210"></label>
          <label>Email (optional)<input data-field="email" type="email" value="${esc(m.email || '')}" placeholder="name@gmail.com"></label>
          <label class="check-label"><span><input type="checkbox" data-field="showOnHome" ${m.showOnHome !== false ? 'checked' : ''}> Show on the homepage (Core Committee only)</span></label>
          <label class="span-2">Short bio<textarea data-field="bio" rows="3" maxlength="600" placeholder="A line about this member">${esc(m.bio || '')}</textarea></label>
        </div>
        <div class="file-row">
          <div class="preview-thumb ${image ? '' : 'empty'}" data-preview>${image ? `<img src="${esc(image)}" alt="">` : 'MT'}</div>
          <input type="hidden" data-field="image" value="${esc(image)}">
          <input type="file" accept="image/png,image/jpeg,image/webp" data-upload="image" aria-label="Upload a photo for ${esc(m.name || 'this member')}">
          <button class="text-button" type="button" data-action="clear-photo">Remove photo</button>
        </div>
        <p class="item-error" data-item-error hidden></p>
      </article>`;
  }

  function renderMembers() {
    const box = $('#teamEditor');
    if (!box || !state.site) return;
    const team = state.site.team || [];
    const rows = [];
    for (const group of D.GROUP_IDS) {
      const members = team.filter(member => member.group === group);
      rows.push(`<h3 class="group-heading">${esc(D.GROUP_LABEL[group])} <span class="mt-count">${members.length}</span></h3>`);
      rows.push(members.length ? members.map((member, index) => memberRow(member, index)).join('') : `<p class="empty-note">No ${esc(D.GROUP_LABEL[group])} members yet.</p>`);
    }
    renderEditor(box, JSON.stringify(team), rows.join(''));
  }

  function readMember(item) {
    const get = name => {
      const node = item.querySelector(`[data-field="${name}"]`);
      if (!node) return '';
      return node.type === 'checkbox' ? node.checked : node.value;
    };
    return {
      name: get('name'),
      role: get('role'),
      group: get('group'),
      phone: get('phone'),
      email: get('email'),
      bio: get('bio'),
      image: get('image'),
      showOnHome: get('showOnHome')
    };
  }

  function showItemError(item, message) {
    const node = item.querySelector('[data-item-error]');
    if (node) { node.hidden = !message; node.textContent = message || ''; }
    if (message) item.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  async function saveMember(item) {
    const id = item.dataset.id;
    const data = readMember(item);
    const name = D.validateName(data.name);
    if (!name.ok) { showItemError(item, name.error); return; }
    const phone = D.normalizeIndianMobile(data.phone);
    if (!phone.ok) { showItemError(item, phone.error); return; }
    if (data.email && !D.validateEmail(data.email).ok) { showItemError(item, D.validateEmail(data.email).error); return; }
    showItemError(item, '');
    const body = { ...data, name: name.value, phone: phone.e164, email: data.email ? D.validateEmail(data.email).value : '', showOnHome: data.group === 'management' ? data.showOnHome !== false : false };
    try {
      if (id === 'new') await call('/api/team', { method: 'POST', body });
      else await call(`/api/team/${encodeURIComponent(id)}`, { method: 'PUT', body });
      await loadSite();
      renderMembers();
      renderOverview();
      flash(`${name.value} is saved. The Members page and homepage update live.`);
    } catch (error) {
      if (error.network) {
        saveDraft('member', id === 'new' ? '' : id, { id, body }, `${name.value} (member)`);
        flash('The server cannot be reached, so this member was NOT published. Kept as a draft on this device.', 'warn');
        return;
      }
      showItemError(item, error.payload && error.payload.error ? error.payload.error : error.message);
    }
  }

  async function deleteMember(item) {
    const id = item.dataset.id;
    if (id === 'new') { item.remove(); return; }
    const name = (state.site.team || []).find(member => member.id === id);
    if (!window.confirm(`Delete ${name ? name.name : 'this member'} from the directory? This cannot be undone.`)) return;
    try {
      await call(`/api/team/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await loadSite();
      renderMembers();
      renderOverview();
      flash('Member deleted. The public directory has been updated.');
    } catch (error) {
      flash(error.network ? 'Not deleted — the server cannot be reached.' : error.message, 'error');
    }
  }

  /* ---------- events ---------- */

  function timeToInput(text) {
    const match = String(text || '').match(/^(\d{1,2}):(\d{2})\s*([AaPp][Mm])?$/);
    if (!match) return '';
    let hours = Number(match[1]);
    if (match[3]) {
      const pm = /p/i.test(match[3]);
      if (pm && hours < 12) hours += 12;
      if (!pm && hours === 12) hours = 0;
    }
    return `${String(hours).padStart(2, '0')}:${match[2]}`;
  }

  function eventRow(event, index) {
    const isNew = !event;
    const e = event || { title: '', scope: 'interdepartmental', category: '', instructor: '', location: '', description: '', feeType: 'free', fee: 0, capacity: null, published: true, brochureUrl: '', attachment: '', attachmentName: '', image: '', isoDate: '', time: '' };
    const iso = e.isoDate || '';
    const day = iso ? Number(iso.slice(8, 10)) : '';
    const month = iso ? Number(iso.slice(5, 7)) - 1 : '';
    const year = iso ? iso.slice(0, 4) : '';
    const image = M.safeImage(e.image);
    const seats = e.seats || { filled: 0 };
    return `
      <article class="editor-item event-editor" data-kind="event" data-id="${esc(isNew ? 'new' : e.id)}">
        <div class="item-top">
          <span class="item-label">${isNew ? 'New event' : `Event ${String(index + 1).padStart(2, '0')} · ${esc(e.published ? 'Published' : 'Hidden')}`}</span>
          <div class="item-actions">
            <button class="text-button" type="button" data-action="save-event">Save</button>
            <button class="text-button remove-button" type="button" data-action="delete-event">${isNew ? 'Discard' : 'Delete'}</button>
          </div>
        </div>
        <div class="form-grid two compact">
          <label class="span-2">Event title<input data-field="title" value="${esc(e.title)}" maxlength="120" placeholder="e.g. Mindful Walk: Breath & Balance"></label>
          <label>Scope<select data-field="scope">${D.SCOPES.map(item => `<option value="${item.id}" ${e.scope === item.id ? 'selected' : ''}>${esc(item.label)}</option>`).join('')}</select></label>
          <label>Category<input data-field="category" value="${esc(e.category || e.kicker || '')}" list="categoryList" maxlength="60" placeholder="Workshop, Talk, Cultural…"></label>
          <label>Day<select data-field="day"><option value="">—</option>${Array.from({ length: 31 }, (_, i) => `<option value="${i + 1}" ${day === i + 1 ? 'selected' : ''}>${i + 1}</option>`).join('')}</select></label>
          <label>Month<select data-field="month"><option value="">—</option>${D.MONTHS.map((name, i) => `<option value="${i}" ${month === i ? 'selected' : ''}>${name}</option>`).join('')}</select></label>
          <label>Year<input data-field="year" value="${esc(year)}" inputmode="numeric" maxlength="4" placeholder="2026"></label>
          <label>Time<input data-field="time" type="time" value="${esc(timeToInput(e.time))}"></label>
          <label class="span-2">Venue<input data-field="location" value="${esc(e.location || '')}" maxlength="160" placeholder="CSMU campus · Seminar Hall"></label>
          <label>Instructor / host (optional)<input data-field="instructor" value="${esc(e.instructor || '')}" maxlength="120" placeholder="Name of the facilitator"></label>
          <label>Entry fee<select data-field="feeType"><option value="free" ${e.feeType !== 'paid' ? 'selected' : ''}>Free entry</option><option value="paid" ${e.feeType === 'paid' ? 'selected' : ''}>Custom ₹ fee (pay at desk)</option></select></label>
          <label>Fee amount (₹)<input data-field="fee" type="number" min="1" max="100000" step="1" value="${e.feeType === 'paid' && e.fee ? esc(e.fee) : ''}" placeholder="e.g. 250"></label>
          <label>Seat capacity (blank = no limit)<input data-field="capacity" type="number" min="1" max="5000" step="1" value="${esc(e.capacity || '')}" placeholder="e.g. 60"></label>
          <label>Brochure link (https, optional)<input data-field="brochureUrl" type="url" value="${esc(e.brochureUrl || '')}" placeholder="https://…/brochure.pdf"></label>
          <label class="span-2">Description<textarea data-field="description" rows="3" maxlength="1500" placeholder="What will happen, who it is for, what to bring">${esc(e.description || '')}</textarea></label>
        </div>
        <div class="file-row">
          <div class="preview-thumb ${image ? '' : 'empty'}" data-preview>${image ? `<img src="${esc(image)}" alt="">` : 'Cover'}</div>
          <input type="hidden" data-field="image" value="${esc(image)}">
          <input type="file" accept="image/png,image/jpeg,image/webp" data-upload="image" aria-label="Cover image">
          <button class="text-button" type="button" data-action="clear-photo">Remove cover</button>
        </div>
        <div class="file-row">
          <input type="hidden" data-field="attachment" value="${esc(e.attachment || '')}">
          <input type="hidden" data-field="attachmentName" value="${esc(e.attachmentName || '')}">
          <input type="file" accept="application/pdf" data-upload="attachment" aria-label="Brochure PDF">
          <span data-brochure-name>${e.attachment ? `Brochure on file: ${esc(e.attachmentName || 'brochure.pdf')}` : 'No PDF brochure uploaded'}</span>
          <button class="text-button" type="button" data-action="clear-brochure">Remove PDF</button>
        </div>
        <label class="publish-toggle"><input type="checkbox" data-field="published" ${e.published ? 'checked' : ''}> Published on the public site and open for registration</label>
        <p class="item-meta">${isNew ? 'Save to publish.' : `Seats: ${esc(seats.filled || 0)} registered${e.capacity ? ` of ${esc(e.capacity)}` : ''}.`}</p>
        <p class="item-error" data-item-error hidden></p>
      </article>`;
  }

  function renderEvents() {
    const box = $('#eventsEditor');
    if (!box || !state.site) return;
    const events = [...(state.site.events || [])].sort((a, b) => String(D.eventIsoDate(a) || '9999').localeCompare(String(D.eventIsoDate(b) || '9999')));
    const datalist = $('#categoryList');
    if (datalist) datalist.innerHTML = [...new Set(events.map(event => event.category || event.kicker).filter(Boolean))].map(value => `<option value="${esc(value)}">`).join('');
    renderEditor(box, JSON.stringify(events), events.length ? events.map((event, index) => eventRow(event, index)).join('') : '<p class="empty-note">No events yet. Use “Add event” to create the first one.</p>');
  }

  function readEvent(item) {
    const get = name => {
      const node = item.querySelector(`[data-field="${name}"]`);
      if (!node) return '';
      return node.type === 'checkbox' ? node.checked : node.value;
    };
    return {
      title: get('title'),
      scope: get('scope'),
      category: get('category'),
      day: get('day'),
      month: get('month'),
      year: get('year'),
      time: get('time'),
      location: get('location'),
      instructor: get('instructor'),
      feeType: get('feeType'),
      fee: get('fee'),
      capacity: get('capacity'),
      brochureUrl: get('brochureUrl'),
      description: get('description'),
      image: get('image'),
      attachment: get('attachment'),
      attachmentName: get('attachmentName'),
      published: get('published')
    };
  }

  async function saveEvent(item) {
    const id = item.dataset.id;
    const data = readEvent(item);
    const problems = [];
    if (String(data.title).trim().length < 2) problems.push('Give the event a title.');
    if (!D.SCOPE_IDS.includes(data.scope)) problems.push('Choose the event scope.');
    if (data.feeType === 'paid' && !(Number(data.fee) > 0)) problems.push('Enter the entry fee in rupees, or switch to free entry.');
    if (data.capacity !== '' && !(Number.isInteger(Number(data.capacity)) && Number(data.capacity) >= 1 && Number(data.capacity) <= 5000)) problems.push('Seat capacity must be a whole number from 1 to 5000, or left blank.');
    if (data.day || data.month || data.year) {
      if (!(data.day && data.month !== '' && data.year)) problems.push('For the date, choose the day, month and year together — or leave all three blank.');
      else if (!D.validIso(data.year, Number(data.month) + 1, data.day)) problems.push('That date does not exist. Check the day, month and year.');
    }
    if (!String(data.location).trim()) problems.push('Add the venue.');
    if (data.brochureUrl && !/^https:\/\//i.test(data.brochureUrl)) problems.push('The brochure link must start with https://');
    if (problems.length) { showItemError(item, problems[0]); return; }
    showItemError(item, '');
    const body = {
      title: data.title.trim(),
      scope: data.scope,
      category: data.category.trim(),
      kicker: data.category.trim(),
      day: data.day ? String(data.day) : '',
      month: data.month === '' ? '' : String(data.month),
      year: data.year ? String(data.year).trim() : '',
      time: M.formatTimeInput(data.time),
      location: data.location.trim(),
      instructor: data.instructor.trim(),
      feeType: data.feeType,
      fee: data.feeType === 'paid' ? Number(data.fee) : 0,
      capacity: data.capacity === '' ? '' : Number(data.capacity),
      brochureUrl: data.brochureUrl.trim(),
      description: data.description.trim(),
      image: data.image,
      attachment: data.attachment,
      attachmentName: data.attachmentName,
      published: data.published === true
    };
    try {
      if (id === 'new') await call('/api/events', { method: 'POST', body });
      else await call(`/api/events/${encodeURIComponent(id)}`, { method: 'PUT', body });
      await loadSite();
      renderEvents();
      renderOverview();
      renderRegistrations();
      flash(`${body.title} is saved. The events page and calendar update live.`);
    } catch (error) {
      if (error.network) {
        saveDraft('event', id === 'new' ? '' : id, { id, body }, `${body.title} (event)`);
        flash('The server cannot be reached, so this event was NOT published. Kept as a draft on this device.', 'warn');
        return;
      }
      showItemError(item, error.payload && error.payload.error ? error.payload.error : error.message);
    }
  }

  async function deleteEvent(item) {
    const id = item.dataset.id;
    if (id === 'new') { item.remove(); return; }
    const event = (state.site.events || []).find(entry => entry.id === id);
    const count = state.registrations.filter(row => row.eventId === id).length;
    const message = `Delete “${event ? event.title : 'this event'}”?${count ? ` Its ${count} registration${count === 1 ? '' : 's'} stay on record as archived attendance — export the master CSV whenever you need them.` : ''}`;
    if (!window.confirm(message)) return;
    try {
      await call(`/api/events/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await loadSite();
      await refreshAll();
      flash(count
        ? `Event deleted. ${count} registration${count === 1 ? '' : 's'} kept as archived attendance.`
        : 'Event deleted.');
    } catch (error) {
      flash(error.network ? 'Not deleted — the server cannot be reached.' : error.message, 'error');
    }
  }

  /* ---------- gallery ---------- */

  function galleryRow(item, index) {
    const isNew = !item;
    const g = item || { title: '', category: 'Event', caption: '', url: '', image: '' };
    const image = M.safeImage(g.image);
    return `
      <article class="editor-item" data-kind="gallery" data-id="${esc(isNew ? 'new' : g.id)}">
        <div class="item-top">
          <span class="item-label">${isNew ? 'New photo' : `Photo ${String(index + 1).padStart(2, '0')}`}</span>
          <div class="item-actions">
            <button class="text-button" type="button" data-action="save-gallery">Save</button>
            <button class="text-button remove-button" type="button" data-action="delete-gallery">${isNew ? 'Discard' : 'Delete'}</button>
          </div>
        </div>
        <div class="form-grid two compact">
          <label>Title<input data-field="title" value="${esc(g.title || g.caption || '')}" maxlength="120" placeholder="e.g. Welcome circle, 2026"></label>
          <label>Category<input data-field="category" value="${esc(g.category || 'Event')}" maxlength="60" placeholder="Event, Workshop…"></label>
          <label class="span-2">Caption<input data-field="caption" value="${esc(g.caption || '')}" maxlength="200" placeholder="A line shown under the photo"></label>
          <label class="span-2">Link (https, optional)<input data-field="url" type="url" value="${esc(g.url || '')}" placeholder="https://instagram.com/p/…"></label>
        </div>
        <div class="file-row">
          <div class="preview-thumb ${image ? '' : 'empty'}" data-preview>${image ? `<img src="${esc(image)}" alt="">` : 'Photo'}</div>
          <input type="hidden" data-field="image" value="${esc(image)}">
          <input type="file" accept="image/png,image/jpeg,image/webp" data-upload="image" aria-label="Upload gallery photo">
        </div>
        <p class="item-error" data-item-error hidden></p>
      </article>`;
  }

  function renderGallery() {
    const box = $('#galleryEditor');
    if (!box || !state.site) return;
    const items = state.site.gallery || [];
    renderEditor(box, JSON.stringify(items), items.length ? items.map((item, index) => galleryRow(item, index)).join('') : '<p class="empty-note">No photos yet. Add the first one below.</p>');
  }

  async function saveGallery(item) {
    const id = item.dataset.id;
    const get = name => (item.querySelector(`[data-field="${name}"]`) || {}).value || '';
    const body = { title: get('title').trim(), category: get('category').trim(), caption: get('caption').trim(), url: get('url').trim(), image: get('image') };
    if (!body.title && !body.caption) { showItemError(item, 'Add a title or caption for this photo.'); return; }
    if (id === 'new' && !body.image) { showItemError(item, 'Choose a photo to upload.'); return; }
    if (body.url && !/^https:\/\//i.test(body.url)) { showItemError(item, 'The link must start with https://'); return; }
    showItemError(item, '');
    try {
      if (id === 'new') await call('/api/gallery', { method: 'POST', body });
      else await call(`/api/gallery/${encodeURIComponent(id)}`, { method: 'PUT', body });
      await loadSite();
      renderGallery();
      renderOverview();
      flash('Photo saved. The gallery page updates live.');
    } catch (error) {
      if (error.network) {
        saveDraft('gallery', id === 'new' ? '' : id, { id, body }, `${body.title || 'Photo'} (gallery)`);
        flash('The server cannot be reached, so this photo was NOT published. Kept as a draft on this device.', 'warn');
        return;
      }
      showItemError(item, error.payload && error.payload.error ? error.payload.error : error.message);
    }
  }

  async function deleteGallery(item) {
    const id = item.dataset.id;
    if (id === 'new') { item.remove(); return; }
    if (!window.confirm('Delete this photo from the gallery?')) return;
    try {
      await call(`/api/gallery/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await loadSite();
      renderGallery();
      renderOverview();
      flash('Photo deleted.');
    } catch (error) {
      flash(error.network ? 'Not deleted — the server cannot be reached.' : error.message, 'error');
    }
  }

  /* ---------- volunteers ---------- */

  let volunteerFilter = 'pending';

  function renderVolunteers() {
    const box = $('#volunteerList');
    if (!box) return;
    const all = state.submissions.filter(item => item.type === 'volunteer');
    const shown = all.filter(item => volunteerFilter === 'all' || (volunteerFilter === 'pending' ? item.status !== 'approved' : item.status === 'approved'));
    const pendingCount = all.filter(item => item.status !== 'approved').length;
    const approvedCount = all.length - pendingCount;
    $$('[data-volunteer-filter]').forEach(button => {
      button.setAttribute('aria-pressed', String(button.dataset.volunteerFilter === volunteerFilter));
      const label = button.dataset.volunteerFilter === 'pending' ? `Pending (${pendingCount})` : button.dataset.volunteerFilter === 'approved' ? `Approved (${approvedCount})` : `All (${all.length})`;
      button.textContent = label;
    });
    renderEditor(box, JSON.stringify([volunteerFilter, shown]), shown.length ? shown.map(item => `
      <article class="submission-card volunteer-card" data-submission="${esc(item.id)}">
        <div class="submission-card-head"><span class="submission-type">${item.status === 'approved' ? 'Approved member' : 'Volunteer application'}</span><span class="submission-time">${esc(M.issuedStamp(item.submittedAt))}</span></div>
        <h3>${esc(item.name)}</h3>
        <div class="submission-meta"><a href="${esc(M.mailHref(item.email))}">${esc(item.email)}</a><a href="${esc(M.telHref(item.phone))}">${esc(M.phoneDisplay(item.phone))}</a>${item.programme ? `<span>${esc(item.programme)}</span>` : ''}${item.year ? `<span>${esc(item.year)}</span>` : ''}</div>
        ${item.interests ? `<p><strong>Interests:</strong> ${esc(item.interests)}</p>` : ''}
        <blockquote class="contribution"><small>What they can do for the club</small>${esc(item.contribution || '')}</blockquote>
        ${item.status === 'approved' ? '<p class="item-meta">Approved and listed in the members directory.</p>' : `
        <div class="approve-row">
          <label>Add as
            <select data-approve-group>${D.GROUP_IDS.map(id => `<option value="${id}" ${id === 'volunteers' ? 'selected' : ''}>${esc(D.GROUP_LABEL[id])}</option>`).join('')}</select>
          </label>
          <label>Role / title<input data-approve-role maxlength="80" placeholder="Volunteer"></label>
          <button class="solid-button small" type="button" data-approve="${esc(item.id)}">Approve as member</button>
          <button class="text-button remove-button" type="button" data-reject="${esc(item.id)}">Reject &amp; delete</button>
        </div>`}
      </article>`).join('') : `<p class="empty-note">${volunteerFilter === 'pending' ? 'No applications waiting for review.' : 'Nothing here yet.'}</p>`);
  }

  async function approveVolunteer(id, card) {
    const group = card.querySelector('[data-approve-group]').value;
    const role = card.querySelector('[data-approve-role]').value.trim();
    try {
      await call(`/api/submissions/${encodeURIComponent(id)}/approve`, { method: 'POST', body: { group, role } });
      await refreshAll();
      flash('Approved. A live member profile now appears in the directory.');
    } catch (error) {
      flash(error.network ? 'Not approved — the server cannot be reached.' : error.message, 'error');
    }
  }

  async function rejectVolunteer(id, card) {
    const name = card.querySelector('h3') ? card.querySelector('h3').textContent : 'this application';
    if (!window.confirm(`Reject and permanently delete the application from ${name}?`)) return;
    try {
      await call(`/api/submissions/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await refreshAll();
      flash('Application rejected and deleted.');
    } catch (error) {
      flash(error.network ? 'Not deleted — the server cannot be reached.' : error.message, 'error');
    }
  }

  /* ---------- registrations and exports ---------- */

  function filenameFrom(response, fallback) {
    const header = response.headers.get('Content-Disposition') || '';
    const match = header.match(/filename="([^"]+)"/);
    return match ? match[1] : fallback;
  }

  async function downloadCsv(eventId) {
    const query = eventId ? `?eventId=${encodeURIComponent(eventId)}` : '';
    try {
      const response = await fetch(`/api/admin/export/registrations.csv${query}`, { headers: { Authorization: `Bearer ${token}` }, cache: 'no-store' });
      if (response.status === 401) { endSession('Your Studio session has ended. Please sign in again.'); return; }
      if (!response.ok) throw new Error('The export could not be created.');
      const blob = await response.blob();
      M.downloadBlob(blob, filenameFrom(response, eventId ? 'mindful-tattva-registrations.csv' : 'mindful-tattva-all-registrations.csv'));
      flash('CSV downloaded.');
    } catch (error) {
      flash(error.network ? 'The export needs the club server, which cannot be reached right now.' : error.message, 'error');
    }
  }

  function renderRegistrations() {
    const summary = $('#eventSummary');
    const table = $('#registrationTable');
    const filter = $('#registrationEvent');
    if (!summary || !table || !state.site) return;
    const events = state.site.events || [];
    const current = filter.value;
    filter.innerHTML = '<option value="">All events</option>' + events.map(event => `<option value="${esc(event.id)}">${esc(event.title)}</option>`).join('');
    if (events.some(event => event.id === current)) filter.value = current;
    summary.innerHTML = events.length ? events.map(event => {
      const count = state.registrations.filter(row => row.eventId === event.id).length;
      const seats = event.capacity ? `${count} / ${event.capacity}` : `${count} registered`;
      return `
        <article class="summary-row">
          <div><strong>${esc(event.title)}</strong><span>${esc(D.SCOPE_LABEL[event.scope] || '')} · ${esc(D.displayDate(event))} · ${esc(seats)}</span></div>
          <div class="item-actions">
            <button class="text-button" type="button" data-roster-admin="${esc(event.id)}">Roster</button>
            <button class="text-button" type="button" data-export-event="${esc(event.id)}">Event CSV ↓</button>
          </div>
        </article>`;
    }).join('') : '<p class="empty-note">No events yet.</p>';

    const term = ($('#registrationSearch').value || '').trim().toLowerCase();
    const selected = filter.value;
    const rows = state.registrations
      .filter(row => !selected || row.eventId === selected)
      .filter(row => !term || [row.name, row.email, row.phone, row.serial, row.college, row.rollNo].filter(Boolean).join(' ').toLowerCase().includes(term))
      .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    table.innerHTML = rows.length ? `
      <div class="table-wrap"><table class="data-table">
        <thead><tr><th>Serial</th><th>Event</th><th>Name</th><th>Email</th><th>Phone</th><th>College / dept.</th><th>Roll / PRN</th><th>Registered (IST)</th><th></th></tr></thead>
        <tbody>${rows.map(row => `
          <tr>
            <td><code>${esc(row.serial)}</code></td>
            <td>${esc(row.eventTitle)}${(state.site.events || []).some(event => event.id === row.eventId) ? '' : ' <em class="tag">Archived</em>'}</td>
            <td>${esc(row.name)}</td>
            <td>${esc(row.email)}</td>
            <td>${esc(row.phone)}</td>
            <td>${esc(row.college)}<br><small>${esc(row.department)}</small></td>
            <td>${esc(row.rollNo)}</td>
            <td>${esc(D.formatIstDateTime(row.createdAt))}</td>
            <td><button class="text-button remove-button" type="button" data-remove-registration="${esc(row.id)}">Remove</button></td>
          </tr>`).join('')}
        </tbody>
      </table></div>` : '<p class="empty-note">No registrations match this view yet.</p>';
  }

  async function showRoster(eventId) {
    const event = (state.site.events || []).find(item => item.id === eventId);
    if (!event) return;
    const rows = state.registrations.filter(row => row.eventId === eventId).sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)));
    $('#registrationEvent').value = eventId;
    $('#registrationSearch').value = '';
    renderRegistrations();
    flash(`${event.title}: ${rows.length} registered. Scroll down for the list.`);
    $('#registrations').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  async function removeRegistration(id) {
    const row = state.registrations.find(item => item.id === id);
    if (!row) return;
    if (!window.confirm(`Remove ${row.name} (${row.serial}) from ${row.eventTitle}? Their pass will stop being valid for this event.`)) return;
    try {
      await call(`/api/admin/registrations/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await refreshAll();
      flash('Registration removed.');
    } catch (error) {
      flash(error.network ? 'Not removed — the server cannot be reached.' : error.message, 'error');
    }
  }

  /* ---------- form inbox (legacy forms) ---------- */

  function renderInbox() {
    const box = $('#inboxList');
    if (!box) return;
    const legacy = state.submissions.filter(item => item.type !== 'volunteer');
    box.innerHTML = legacy.length ? legacy.map(item => `
      <article class="submission-card" data-submission="${esc(item.id)}">
        <div class="submission-card-head"><span class="submission-type">${esc(item.type === 'club-registration' ? 'Event interest' : item.type)}</span><span class="submission-time">${esc(M.issuedStamp(item.submittedAt))}</span></div>
        <h3>${esc(item.name)}</h3>
        <div class="submission-meta"><a href="${esc(M.mailHref(item.email))}">${esc(item.email)}</a><a href="${esc(M.telHref(item.phone))}">${esc(M.phoneDisplay(item.phone))}</a></div>
        ${item.event ? `<p><strong>Event:</strong> ${esc(item.event)}</p>` : ''}
        ${item.message ? `<p>${esc(item.message)}</p>` : ''}
        <button class="text-button remove-button" type="button" data-inbox-delete="${esc(item.id)}">Delete</button>
      </article>`).join('') : '<p class="empty-note">No older form messages.</p>';
  }

  /* ---------- wiring ---------- */

  function bindEvents() {
    document.addEventListener('click', async event => {
      const target = event.target;
      const actionButton = target.closest('[data-action]');
      if (actionButton) {
        const item = actionButton.closest('[data-kind]');
        const action = actionButton.dataset.action;
        if (action === 'save-member') return saveMember(item);
        if (action === 'delete-member') return deleteMember(item);
        if (action === 'save-event') return saveEvent(item);
        if (action === 'delete-event') return deleteEvent(item);
        if (action === 'save-gallery') return saveGallery(item);
        if (action === 'delete-gallery') return deleteGallery(item);
        if (action === 'clear-photo') {
          const hidden = item.querySelector('[data-field="image"]');
          if (hidden) hidden.value = '';
          const preview = item.querySelector('[data-preview]');
          if (preview) { preview.innerHTML = item.dataset.kind === 'member' ? 'MT' : (item.dataset.kind === 'event' ? 'Cover' : 'Photo'); preview.classList.add('empty'); }
          return;
        }
        if (action === 'clear-brochure') {
          item.querySelector('[data-field="attachment"]').value = '';
          item.querySelector('[data-field="attachmentName"]').value = '';
          item.querySelector('[data-brochure-name]').textContent = 'No PDF brochure uploaded';
          return;
        }
      }
      if (target.closest('#addMember')) { $('#teamEditor').insertAdjacentHTML('afterbegin', memberRow(null, 0)); return; }
      if (target.closest('#addEvent')) { $('#eventsEditor').insertAdjacentHTML('afterbegin', eventRow(null, 0)); return; }
      if (target.closest('#addGallery')) { $('#galleryEditor').insertAdjacentHTML('afterbegin', galleryRow(null, 0)); return; }
      if (target.closest('#saveSite')) return saveSite();
      if (target.closest('#refreshStudio')) return refreshAll();
      if (target.closest('#signOut')) {
        call('/api/admin/logout', { method: 'POST' }).catch(() => {});
        endSession('You have signed out of the Content Studio.');
        return;
      }
      const filterButton = target.closest('[data-volunteer-filter]');
      if (filterButton) { volunteerFilter = filterButton.dataset.volunteerFilter; renderVolunteers(); return; }
      const approve = target.closest('[data-approve]');
      if (approve) { return approveVolunteer(approve.dataset.approve, approve.closest('[data-submission]')); }
      const reject = target.closest('[data-reject]');
      if (reject) { return rejectVolunteer(reject.dataset.reject, reject.closest('[data-submission]')); }
      const roster = target.closest('[data-roster-admin]');
      if (roster) { return showRoster(roster.dataset.rosterAdmin); }
      const exportEvent = target.closest('[data-export-event]');
      if (exportEvent) { return downloadCsv(exportEvent.dataset.exportEvent); }
      if (target.closest('#exportAll')) { return downloadCsv(''); }
      const remove = target.closest('[data-remove-registration]');
      if (remove) { return removeRegistration(remove.dataset.removeRegistration); }
      const inboxDelete = target.closest('[data-inbox-delete]');
      if (inboxDelete) {
        if (!window.confirm('Delete this message?')) return;
        call(`/api/submissions/${encodeURIComponent(inboxDelete.dataset.inboxDelete)}`, { method: 'DELETE' })
          .then(refreshAll).then(() => flash('Message deleted.')).catch(error => flash(error.message, 'error'));
        return;
      }
      const publish = target.closest('[data-draft-publish]');
      if (publish) { return publishDraft(Number(publish.dataset.draftPublish)); }
      const discard = target.closest('[data-draft-delete]');
      if (discard) {
        const list = drafts();
        list.splice(Number(discard.dataset.draftDelete), 1);
        M.writeJson(DRAFTS_KEY, list);
        renderDrafts();
        return;
      }
    });

    $('#loginForm').addEventListener('submit', async event => {
      event.preventDefault();
      const form = event.target;
      const password = form.elements.password.value;
      const button = form.querySelector('button[type="submit"]');
      button.disabled = true;
      $('#loginError').textContent = '';
      try {
        const result = await M.api('/api/admin/login', { method: 'POST', body: { password } });
        token = result.token;
        try { window.sessionStorage.setItem(TOKEN_KEY, token); } catch (_) { /* private mode */ }
        form.reset();
        showStudio();
        await refreshAll();
      } catch (error) {
        $('#loginError').textContent = error.network ? 'We could not reach the server. Please try again shortly.' : error.message;
        form.elements.password.select();
      } finally {
        button.disabled = false;
      }
    });

    $('#siteForm').addEventListener('submit', event => { event.preventDefault(); saveSite(); });
    $('#registrationEvent').addEventListener('change', renderRegistrations);
    $('#registrationSearch').addEventListener('input', renderRegistrations);
    $('#studioNav').addEventListener('click', event => {
      const link = event.target.closest('a[href^="#"]');
      if (!link) return;
      $$('#studioNav a').forEach(item => item.classList.toggle('active', item === link));
    });
  }

  function publishDraft(index) {
    const list = drafts();
    const draft = list[index];
    if (!draft) return;
    const { kind, payload } = draft;
    const path = kind === 'member' ? '/api/team' : kind === 'event' ? '/api/events' : '/api/gallery';
    const request = payload.id ? call(`${path}/${encodeURIComponent(payload.id)}`, { method: 'PUT', body: payload.body }) : call(path, { method: 'POST', body: payload.body });
    request.then(async () => {
      const fresh = drafts();
      fresh.splice(index, 1);
      M.writeJson(DRAFTS_KEY, fresh);
      await refreshAll();
      flash('Draft published.');
    }).catch(error => {
      flash(error.network ? 'Still offline — the draft stays on this device.' : error.message, 'error');
    });
  }

  M.ready(() => {
    bindEvents();
    bindUploads();
    renderDrafts();
    verifySession();
  });
})(window.MT);
