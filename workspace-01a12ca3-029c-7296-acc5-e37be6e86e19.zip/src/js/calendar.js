/* Yearly calendar: twelve month cards, TBA block, live seats, register and brochure actions. */
(function (M) {
  'use strict';

  const D = window.MTDomain;
  const esc = M.esc;
  let viewYear = null;
  let currentYear = null;

  function weekdayShort(iso) {
    if (!iso) return '';
    const date = new Date(`${iso}T12:00:00+05:30`);
    return new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', weekday: 'short' }).format(date);
  }

  function eventItem(event) {
    const iso = D.eventIsoDate(event);
    const day = iso ? Number(iso.slice(8, 10)) : null;
    const monthShort = iso ? D.MONTHS[Number(iso.slice(5, 7)) - 1].slice(0, 3) : '';
    const when = iso ? `${String(day).padStart(2, '0')} ${monthShort} · ${weekdayShort(iso)}` : 'Date to be announced';
    const seats = M.seatsOf(event);
    const action = event.registrationOpen
      ? `<button class="solid-button small" type="button" data-register="${esc(event.id)}">Register ↗</button>`
      : (seats.full ? '<button class="outline-button small" type="button" disabled>Event full</button>' : '');
    return `
      <div class="event mt-cal-event" data-event-id="${esc(event.id)}">
        <div class="event-date">${esc(when)}${event.time ? ` · ${esc(event.time)}` : ''}</div>
        <h4>${esc(event.title)}</h4>
        <p>${esc(event.location || 'Venue to be announced')}${event.instructor ? ` · ${esc(event.instructor)}` : ''}</p>
        <p><span class="mt-chip">${esc(D.SCOPE_LABEL[event.scope] || '')}</span> <span class="mt-chip mt-chip-fee">${esc(M.feeText(event))}</span></p>
        <div class="mt-seats mt-seats-compact"><div class="mt-seat-bar"><span style="width:${seats.capacity ? seats.pct : 0}%"></span></div><small><strong>${esc(M.seatText(event))}</strong></small></div>
        <div class="mt-card-actions">${action}<button class="outline-button small" type="button" data-roster="${esc(event.id)}">Live roster</button>${M.brochureLink(event, 'event-brochure mt-brochure')}</div>
      </div>`;
  }

  function render(site) {
    const grid = document.getElementById('monthGrid');
    if (!grid) return;
    currentYear = Number(String(site.today || D.todayIso()).slice(0, 4));
    if (viewYear === null) viewYear = currentYear;
    const label = document.getElementById('calendarYear');
    if (label) label.textContent = String(viewYear);
    const published = (site.events || []).filter(event => event.published);
    const months = D.MONTHS.map((name, index) => {
      const items = published
        .filter(event => {
          const iso = D.eventIsoDate(event);
          return iso && Number(iso.slice(0, 4)) === viewYear && Number(iso.slice(5, 7)) === index + 1;
        })
        .sort((a, b) => String(D.eventIsoDate(a)).localeCompare(String(D.eventIsoDate(b))));
      return `
        <article class="month${items.length ? ' has-event' : ''}">
          <div class="month-head"><h3>${esc(name)}</h3><span class="month-number">${String(index + 1).padStart(2, '0')}</span></div>
          <div class="event-list">${items.length ? items.map(eventItem).join('') : '<p class="empty">No activities planned yet.</p>'}</div>
        </article>`;
    });
    const tba = published.filter(event => !D.eventIsoDate(event) && (!event.year || Number(event.year) === viewYear));
    if (tba.length) {
      months.push(`
        <article class="month has-event">
          <div class="month-head"><h3>To be announced</h3><span class="month-number">TBA</span></div>
          <div class="event-list">${tba.map(eventItem).join('')}</div>
        </article>`);
    }
    M.setHtml(grid, months.join(''));
    const prev = document.getElementById('yearPrev');
    if (prev) prev.disabled = viewYear <= currentYear - 2;
  }

  function bindYearControls() {
    const prev = document.getElementById('yearPrev');
    const next = document.getElementById('yearNext');
    const refresh = () => { if (M.site()) render(M.site()); };
    if (prev) prev.addEventListener('click', () => { viewYear -= 1; refresh(); });
    if (next) next.addEventListener('click', () => { viewYear += 1; refresh(); });
  }

  M.initPublic({ render });
  M.ready(bindYearControls);
})(window.MT);
