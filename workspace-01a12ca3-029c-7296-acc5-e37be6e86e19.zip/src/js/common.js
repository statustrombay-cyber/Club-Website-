/* Shared browser helpers. Loaded first on every page. Exposes window.MT. */
(function (M) {
  'use strict';

  const D = window.MTDomain;

  M.ready = fn => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  };

  // Writes HTML only when it changed, so live updates never swap out a button the visitor is pressing.
  const lastHtml = new WeakMap();
  M.setHtml = (node, html) => {
    if (!node || lastHtml.get(node) === html) return false;
    lastHtml.set(node, html);
    node.innerHTML = html;
    return true;
  };

  M.$ = (selector, root) => (root || document).querySelector(selector);
  M.$$ = (selector, root) => Array.from((root || document).querySelectorAll(selector));

  M.esc = value => String(value === undefined || value === null ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  M.safeUrl = (value, fallback) => {
    const text = String(value || '').trim();
    return /^(https:\/\/|mailto:|tel:|\/(?!\/)|#)/i.test(text) ? text : (fallback || '#');
  };

  M.safeImage = value => {
    const text = String(value || '').trim();
    return /^data:image\/(png|jpe?g|webp);base64,/i.test(text) || /^https:\/\//i.test(text) || /^\/assets\/[\w./-]+$/i.test(text) ? text : '';
  };

  M.safeAttachment = value => {
    const text = String(value || '').trim();
    return /^data:application\/pdf(;[^,]*)?,/i.test(text) || /^https:\/\//i.test(text) ? text : '';
  };

  // Turns an image URL into a CSS background declaration without allowing quote breakouts.
  M.bgStyle = value => {
    const safe = M.safeImage(value);
    return safe ? `background-image:url("${safe.replace(/["\\\r\n()]/g, '')}")` : '';
  };

  M.initials = name => String(name || '').split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0].toUpperCase()).join('') || 'MT';

  M.money = amount => `₹${Number(amount || 0).toLocaleString('en-IN')}`;

  M.phoneDisplay = phone => {
    const check = D.normalizeIndianMobile(phone);
    return check.ok ? check.display : String(phone || '');
  };

  M.telHref = phone => {
    const check = D.normalizeIndianMobile(phone);
    return check.ok ? `tel:${check.e164}` : '';
  };

  M.mailHref = email => {
    const check = D.validateEmail(email);
    return check.ok ? `mailto:${check.value}` : '';
  };

  M.mapsUrl = site => {
    const query = [site && site.universityName, site && site.address].filter(Boolean).join(', ') || 'Chhatrapati Shivaji Maharaj University, Panvel';
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
  };

  M.shortDate = iso => {
    if (!iso) return '';
    const date = new Date(`${iso}T00:00:00+05:30`);
    if (Number.isNaN(date.getTime())) return iso;
    return new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', day: '2-digit', month: 'short', year: 'numeric' }).format(date);
  };

  M.issuedStamp = iso => {
    if (!iso) return '';
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return '';
    return new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }).format(date);
  };

  M.readJson = (key, fallback) => {
    try {
      const raw = window.localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (_) {
      return fallback;
    }
  };

  M.writeJson = (key, value) => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (_) {
      return false;
    }
  };

  // JSON request helper. Rejects with err.network for connection failures and err.payload for API errors.
  M.api = async (url, options) => {
    const opts = options || {};
    const headers = { Accept: 'application/json' };
    if (opts.body !== undefined) headers['Content-Type'] = 'application/json';
    if (opts.auth && M.adminToken && M.adminToken()) headers.Authorization = `Bearer ${M.adminToken()}`;
    const method = opts.method || (opts.body !== undefined ? 'POST' : 'GET');
    let response;
    try {
      response = await fetch(url, {
        method,
        headers,
        cache: 'no-store',
        body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined
      });
    } catch (cause) {
      const error = new Error('We could not reach the club server. Check your connection and try again.');
      error.network = true;
      error.cause = cause;
      throw error;
    }
    let payload = null;
    try { payload = await response.json(); } catch (_) { payload = null; }
    if (!response.ok) {
      const error = new Error((payload && payload.error) || `Request failed (${response.status})`);
      error.status = response.status;
      error.payload = payload || {};
      throw error;
    }
    return payload;
  };

  M.downloadBlob = (blob, filename) => {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    setTimeout(() => { URL.revokeObjectURL(url); link.remove(); }, 1000);
  };

  M.downloadText = (text, filename, type) => {
    M.downloadBlob(new Blob([text], { type: type || 'text/csv;charset=utf-8' }), filename);
  };

  // Reads a file as a data URL (Base64). Used by every upload field.
  M.readFileAsDataUrl = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('That file could not be read. Please try another file.'));
    reader.readAsDataURL(file);
  });

  // Centre-crops an image to a square JPEG so member and gallery photos stay consistent.
  M.squareJpeg = (dataUrl, size) => new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => {
      const side = Math.min(image.naturalWidth, image.naturalHeight);
      if (!side) { reject(new Error('That picture is empty. Please choose another photo.')); return; }
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#fffaf1';
      ctx.fillRect(0, 0, size, size);
      const sx = (image.naturalWidth - side) / 2;
      const sy = (image.naturalHeight - side) / 2;
      ctx.drawImage(image, sx, sy, side, side, 0, 0, size, size);
      resolve(canvas.toDataURL('image/jpeg', 0.9));
    };
    image.onerror = () => reject(new Error('That picture could not be opened. Use a PNG, JPG or WebP photo.'));
    image.src = dataUrl;
  });

  M.formatTimeInput = value => {
    const match = String(value || '').match(/^(\d{1,2}):(\d{2})$/);
    if (!match) return String(value || '').trim();
    let hours = Number(match[1]);
    const minutes = match[2];
    const suffix = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `${hours}:${minutes} ${suffix}`;
  };

  M.slug = text => D.slugify(text);
})(window.MT = window.MT || {});
