/* Homepage: renders the live site content and the volunteer application form. */
(function (M) {
  'use strict';

  const D = window.MTDomain;
  const esc = M.esc;

  function setText(id, value) {
    const node = document.getElementById(id);
    if (node && value) node.textContent = value;
  }

  function setLink(id, href, text) {
    const node = document.getElementById(id);
    if (!node) return;
    if (href) node.setAttribute('href', href);
    if (text) node.textContent = text;
  }

  function renderSite(site) {
    const s = site.site || {};
    setText('announcement', s.announcement);
    setText('brandName', s.clubName);
    setText('footerName', s.clubName);
    setText('heroEyebrow', s.eyebrow);
    setText('heroTagline', s.tagline);
    setText('heroIntro', s.intro);
    setText('heroUniversity', s.universityName);
    setText('heroDepartment', s.department);
    setText('aboutDepartment', s.department);
    setText('aboutUniversity', s.universityName);
    setText('aboutHeading', s.aboutHeading);
    setText('aboutBody', s.aboutBody);
    setText('clubDescription', s.clubDescription);
    setText('missionText', s.mission);
    setText('visionText', s.vision);
    setText('benefitsText', s.memberBenefits);
    setText('joiningIntro', s.joiningIntro);
    setText('contactNote', s.contactNote);
    setText('contactUniversityName', s.universityName);
    setText('contactDepartmentName', s.department ? `${s.department} · Psychology Club` : '');
    setText('addressSource', s.addressSource);
    const mapUrl = M.mapsUrl(s);
    if (s.address) {
      setText('aboutAddress', `${s.address} ↗`);
      setText('addressContact', s.address);
    }
    setLink('aboutAddress', mapUrl);
    setLink('addressContact', mapUrl);
    setLink('addressMap', mapUrl);
    const handle = s.instagramHandle || '@mindful_tattva';
    const instagram = s.instagramUrl || 'https://www.instagram.com/mindful_tattva';
    setLink('instagramNav', instagram);
    setLink('instagramContact', instagram, `${handle.startsWith('@') ? handle : `@${handle}`} ↗`);
    if (s.email && M.mailHref(s.email)) setLink('emailContact', M.mailHref(s.email), s.email);
    if (Array.isArray(s.stats) && s.stats.length) {
      const row = document.getElementById('statsRow');
      if (row) row.innerHTML = s.stats.map(stat => `<div class="stat"><strong>${esc(stat.value)}</strong><span>${esc(stat.label)}</span></div>`).join('');
    }
  }

  function renderEvents(site) {
    const grid = document.getElementById('eventGrid');
    if (!grid) return;
    const open = M.openEvents(site).slice(0, 3);
    grid.classList.toggle('mt-event-grid', true);
    M.setHtml(grid, open.length
      ? open.map(event => M.eventCard(event)).join('')
      : '<article class="event-card mt-empty-card"><div class="event-body"><div class="event-date">Coming soon</div><h3>No events are scheduled right now.</h3><p>Follow @mindful_tattva for the next gathering — registration opens with each event.</p></div></article>');
    const more = document.getElementById('eventsMore');
    if (more) more.innerHTML = `<a class="solid-button" href="/events.html">See all events, filters &amp; passes ↗</a><button class="outline-button" type="button" data-mt-open="register">Register for an event</button>`;
  }

  function renderGallery(site) {
    const grid = document.getElementById('galleryGrid');
    if (!grid) return;
    const items = (site.gallery || []).slice(0, 4);
    if (!items.length) return;
    M.setHtml(grid, items.map((item, index) => {
      const image = M.bgStyle(item.image);
      const caption = item.title || item.caption || 'Mindful Tattva moment';
      const body = image
        ? `<div class="gallery-visual has-image" style="${esc(image)}" role="img" aria-label="${esc(item.alt || caption)}"></div>`
        : `<div class="gallery-visual"><span class="gallery-placeholder">Photo placeholder</span></div>`;
      return `<figure class="gallery-item${index === 0 ? ' gallery-item-first' : ''}">${body}<figcaption class="gallery-caption">${esc(caption)}</figcaption></figure>`;
    }).join(''));
  }

  function memberCard(member) {
    const image = M.bgStyle(member.image);
    const phone = M.telHref(member.phone);
    const email = M.mailHref(member.email);
    const avatar = image
      ? `<div class="team-avatar has-image" role="img" aria-label="${esc(member.name)} photo" style="${esc(image)}"><span></span></div>`
      : `<div class="team-avatar" role="img" aria-label="${esc(member.name)} placeholder"><span>MT</span></div>`;
    return `<article class="team-card">${avatar}<h3>${esc(member.name)}</h3><div class="team-role">${esc(member.role || 'Core Committee')}</div>${member.bio ? `<p class="team-bio">${esc(member.bio)}</p>` : ''}${phone ? `<a class="team-phone" href="${esc(phone)}">${esc(M.phoneDisplay(member.phone))} ↗</a>` : ''}${email ? `<a class="team-phone" href="${esc(email)}">${esc(member.email)} ↗</a>` : ''}</article>`;
  }

  function renderTeam(site) {
    const grid = document.getElementById('teamGrid');
    if (!grid) return;
    // Core-only homepage: Core Committee members that are switched on for the homepage.
    const core = (site.team || []).filter(member => member.group === 'management' && member.showOnHome !== false);
    if (!core.length) {
      M.setHtml(grid, '<article class="team-card team-empty"><strong>The core team is being updated.</strong><p>Check the members directory for the full list.</p></article>');
      return;
    }
    M.setHtml(grid, core.map(memberCard).join(''));
  }

  function renderHistory(site) {
    const list = document.getElementById('historyList');
    if (!list || !(site.history || []).length) return;
    M.setHtml(list, site.history.map(item => `<article class="timeline-item"><span class="timeline-dot"></span><div class="timeline-year">${esc(item.year)}</div><div><h3>${esc(item.title)}</h3><p>${esc(item.body)}</p></div></article>`).join(''));
  }

  function renderApplications() {
    const node = document.getElementById('volunteerHistory');
    if (!node) return;
    const list = M.volunteerApplications();
    node.hidden = !list.length;
    node.textContent = list.length ? `${list.length} application${list.length === 1 ? '' : 's'} sent from this device. The studio team reviews every one.` : '';
  }

  function bindVolunteerForm() {
    const form = document.getElementById('volunteerForm');
    if (!form) return;
    const status = form.querySelector('.form-status');
    const button = form.querySelector('button[type="submit"]');
    form.addEventListener('submit', async event => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      const name = D.validateName(data.name);
      const email = D.validateEmail(data.email);
      const phone = D.normalizeIndianMobile(data.phone);
      const contribution = String(data.contribution || '').trim();
      const problems = [];
      if (!name.ok) problems.push(name.error);
      if (!email.ok) problems.push(email.error);
      if (!phone.ok) problems.push(phone.error);
      if (contribution.length < 30) problems.push('Please share at least 30 characters about how you can help Mindful Tattva grow.');
      if (problems.length) {
        status.textContent = problems[0];
        status.dataset.tone = 'error';
        return;
      }
      button.disabled = true;
      const label = button.textContent;
      button.textContent = 'Sending your application…';
      status.textContent = '';
      try {
        const result = await M.api('/api/submissions', {
          method: 'POST',
          body: { type: 'volunteer', name: data.name, email: data.email, phone: data.phone, programme: data.programme, year: data.year, interests: data.interests, contribution }
        });
        M.recordVolunteerApplication({ id: result.id, name: name.value, submittedAt: new Date().toISOString(), status: 'Received' });
        form.reset();
        status.dataset.tone = 'success';
        status.textContent = 'Thank you! Your volunteer application has reached the Studio team.';
        renderApplications();
      } catch (error) {
        status.dataset.tone = 'error';
        if (error.network) status.textContent = 'We could not reach the club server, so your application was NOT sent. Please try again.';
        else status.textContent = error.message || 'Your application could not be sent. Please try again.';
      } finally {
        button.disabled = false;
        button.textContent = label;
      }
    });
  }

  M.initPublic({
    render(site) {
      renderSite(site);
      renderEvents(site);
      renderGallery(site);
      renderTeam(site);
      renderHistory(site);
    }
  });

  M.ready(() => {
    bindVolunteerForm();
    renderApplications();
  });
})(window.MT);
