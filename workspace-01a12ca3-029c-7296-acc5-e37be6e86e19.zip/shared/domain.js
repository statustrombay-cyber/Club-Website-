/*
 * Mindful Tattva — shared domain rules.
 * Used by the Node server (CommonJS) and embedded into every public page (browser global `MTDomain`).
 * Keep this file dependency-free and ES2018-compatible.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MTDomain = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const UNIVERSITY_NAME = 'Chhatrapati Shivaji Maharaj University (CSMU)';
  const DEPARTMENT_NAME = 'Department of Applied Social Sciences';
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const SCOPES = [
    { id: 'intercollege', label: 'Intercollege' },
    { id: 'interdepartmental', label: 'Interdepartmental' },
    { id: 'departmental', label: 'Departmental' }
  ];
  const SCOPE_IDS = SCOPES.map(scope => scope.id);
  const SCOPE_LABEL = Object.fromEntries(SCOPES.map(scope => [scope.id, scope.label]));
  const GROUP_IDS = ['management', 'heads', 'volunteers'];
  const GROUP_LABEL = { management: 'Core Committee', heads: 'Head Committee', volunteers: 'Volunteers' };
  const YEAR_OPTIONS = ['1st Year', '2nd Year', '3rd Year', '4th Year'];
  const SEMESTER_OPTIONS = ['Semester 1', 'Semester 2', 'Semester 3', 'Semester 4', 'Semester 5', 'Semester 6'];
  const CATEGORY_PRESETS = ['Workshop', 'Talk', 'Cultural', 'Wellbeing', 'Club gathering', 'Seminar', 'Initiative'];
  const FEE_TYPES = ['free', 'paid'];
  const TIME_ZONE = 'Asia/Kolkata';

  const fail = error => ({ ok: false, error });

  /* ---------- Indian mobile numbers ---------- */

  const KNOWN_DUMMY_MOBILES = new Set(['9000000000', '8000000000', '7000000000', '6000000000', '9876543210', '9123456789', '8123456789', '7123456789', '6123456789']);

  // Returns '' for a plausible number or a short reason string for a dummy/fake pattern.
  function mobileDummyReason(digits) {
    if (/^(\d)\1{9}$/.test(digits)) return 'repeated';
    const counts = new Array(10).fill(0);
    for (const ch of digits) counts[Number(ch)] += 1;
    if (Math.max(...counts) >= 8) return 'repeated';
    if (/^(\d{2})\1{4}$/.test(digits) || /^(\d{5})\1$/.test(digits)) return 'pattern';
    let run = 1;
    let direction = 0;
    for (let i = 1; i < digits.length; i += 1) {
      const diff = (Number(digits[i]) - Number(digits[i - 1]) + 10) % 10;
      const step = diff === 1 ? 1 : diff === 9 ? -1 : 0;
      if (!step) { run = 1; direction = 0; continue; }
      if (step === direction) run += 1;
      else { direction = step; run = 2; }
      if (run >= 7) return 'sequence';
    }
    if (KNOWN_DUMMY_MOBILES.has(digits)) return 'known';
    return '';
  }

  // Accepts +91 / 91 / 0 prefixes, strips them and returns the 10-digit national number.
  function normalizeIndianMobile(value) {
    const raw = String(value === undefined || value === null ? '' : value).trim();
    if (!raw) return fail('Enter your 10-digit mobile number.');
    if (/[a-z]/i.test(raw)) return fail('Mobile numbers can only contain digits.');
    let digits = raw.replace(/\D/g, '');
    if (!digits) return fail('Enter your 10-digit mobile number.');
    if (raw.startsWith('+') || raw.startsWith('00')) {
      if (raw.startsWith('00')) digits = digits.slice(2);
      if (!digits.startsWith('91')) return fail('Only Indian mobile numbers (+91) are accepted.');
      digits = digits.slice(2);
    } else if (digits.length === 12 && digits.startsWith('91')) {
      digits = digits.slice(2);
    }
    if (digits.length === 11 && digits.startsWith('0')) digits = digits.slice(1);
    if (digits.length !== 10) return fail('Enter a 10-digit Indian mobile number.');
    if (!/^[6-9]/.test(digits)) return fail('Indian mobile numbers start with 6, 7, 8 or 9.');
    if (mobileDummyReason(digits)) return fail('That looks like a placeholder number. Please enter your real mobile number.');
    return { ok: true, digits, e164: `+91${digits}`, display: `+91 ${digits.slice(0, 5)} ${digits.slice(5)}` };
  }

  /* ---------- Email ---------- */

  const EMAIL_PATTERN = /^[a-z0-9](?:[a-z0-9._%+-]{0,62}[a-z0-9])?@(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$/;
  const BLOCKED_EMAIL_DOMAINS = new Set([
    'test.com', 'example.com', 'example.org', 'example.net', 'example.edu', 'sample.com', 'dummy.com', 'fake.com', 'abc.com', 'xyz.com',
    'mailinator.com', 'tempmail.com', 'temp-mail.org', 'temp-mail.io', 'tempmail.net', '10minutemail.com', '10minutemail.net',
    'guerrillamail.com', 'guerrillamail.net', 'guerrillamailblock.com', 'yopmail.com', 'trashmail.com', 'throwawaymail.com',
    'sharklasers.com', 'dispostable.com', 'fakeinbox.com', 'maildrop.cc', 'getnada.com', 'mailnesia.com', 'tempinbox.com',
    'emailondeck.com', 'mintemail.com', 'spamgourmet.com', 'moakt.com', 'mytemp.email', 'tempr.email', 'discard.email',
    'mohmal.com', 'mailcatch.com', 'spam4.me', 'inboxbear.com', 'tempail.com', 'burnermail.io', 'emailfake.com', 'fakemail.net', 'mailsac.com'
  ]);
  const BLOCKED_EMAIL_LABEL = /(^|[.-])(temp-?mail|mailinator|yopmail|guerrillamail|10minute|throwaway|trash-?mail|disposable|fakeinbox|sharklasers|maildrop|getnada|mailnesia|tempinbox|mintemail|dispostable|spamgourmet|moakt|burner|mailsac|fakemail|emailfake)/;
  const PLACEHOLDER_EMAIL_DOMAIN = /^(test|example|sample|dummy|fake|placeholder)\./;
  const RESERVED_TLDS = new Set(['test', 'example', 'invalid', 'localhost', 'local']);
  const PLACEHOLDER_EMAIL_LOCAL = new Set(['test', 'testing', 'example', 'sample', 'dummy', 'fake', 'placeholder', 'asdf', 'qwerty', 'xyz', 'abc123']);

  function validateEmail(value) {
    const email = String(value === undefined || value === null ? '' : value).trim().toLowerCase();
    if (!email) return fail('Enter your email address.');
    if (email.length > 254 || !EMAIL_PATTERN.test(email)) return fail('Enter a valid email address, such as name@gmail.com.');
    const at = email.lastIndexOf('@');
    const local = email.slice(0, at);
    const domain = email.slice(at + 1);
    const tld = domain.split('.').pop();
    if (PLACEHOLDER_EMAIL_LOCAL.has(local)) return fail('Please use your real email address.');
    if (RESERVED_TLDS.has(tld) || BLOCKED_EMAIL_DOMAINS.has(domain) || BLOCKED_EMAIL_LABEL.test(domain) || PLACEHOLDER_EMAIL_DOMAIN.test(domain)) {
      return fail('Placeholder and temporary email domains are not accepted. Please use your personal or college email.');
    }
    return { ok: true, value: email };
  }

  /* ---------- Names, rolls and free text ---------- */

  const NAME_PATTERN = /^[\p{L}\p{M}][\p{L}\p{M} .'’-]*[\p{L}\p{M}.]$/u;
  const PLACEHOLDER_NAMES = new Set(['test', 'testing', 'asdf', 'qwerty', 'abc', 'xyz', 'dummy', 'fake', 'name', 'user', 'none', 'na']);

  function validateName(value) {
    const name = String(value === undefined || value === null ? '' : value).replace(/\s+/g, ' ').trim();
    if (name.length < 2 || name.length > 80) return fail('Enter your full name (2–80 characters).');
    if (!NAME_PATTERN.test(name) || !/\p{L}{2,}/u.test(name)) return fail('Use letters only in your name.');
    if (PLACEHOLDER_NAMES.has(name.toLowerCase())) return fail('Please enter your real name.');
    return { ok: true, value: name };
  }

  const ROLL_PATTERN = /^[A-Z0-9][A-Z0-9/-]{2,29}$/;
  function validateRoll(value, label) {
    const roll = String(value === undefined || value === null ? '' : value).trim().toUpperCase();
    if (!ROLL_PATTERN.test(roll)) return fail(`Enter a valid ${label} (3–30 letters or numbers).`);
    return { ok: true, value: roll };
  }

  const TEXT_PATTERN = /^[\p{L}\p{N}][\p{L}\p{N} .,&()'’/-]*$/u;
  function validateText(value, label, min, max) {
    const text = String(value === undefined || value === null ? '' : value).replace(/\s+/g, ' ').trim();
    if (text.length < min || text.length > max) return fail(`${label} must be ${min}–${max} characters.`);
    if (!TEXT_PATTERN.test(text)) return fail(`${label} contains characters that are not allowed.`);
    return { ok: true, value: text };
  }

  /* ---------- Scope-adaptive registration fields ---------- */

  // Returns { ok, errors, value } where value holds the normalised participant record.
  function validateRegistrationFields(input, scope) {
    const source = input || {};
    const errors = {};
    const value = {};
    const put = (key, result) => { if (result.ok) value[key] = result.value; else errors[key] = result.error; };

    put('name', validateName(source.name));
    put('email', validateEmail(source.email));
    const phone = normalizeIndianMobile(source.phone);
    if (phone.ok) value.phone = phone.digits; else errors.phone = phone.error;

    if (scope === 'intercollege') {
      put('college', validateText(source.college, 'College / university name', 3, 120));
      put('rollNo', validateRoll(source.rollNo, 'PRN / college roll number'));
      put('department', validateText(source.department, 'Department / stream', 2, 100));
      value.yearOrSemester = '';
    } else if (scope === 'interdepartmental') {
      value.college = UNIVERSITY_NAME;
      put('department', validateText(source.department, 'CSMU department / course', 2, 100));
      put('rollNo', validateRoll(source.rollNo, 'student roll number'));
      const year = String(source.year || '').trim();
      if (YEAR_OPTIONS.includes(year)) value.yearOrSemester = year; else errors.year = 'Choose your year of study.';
    } else if (scope === 'departmental') {
      value.college = UNIVERSITY_NAME;
      value.department = DEPARTMENT_NAME;
      put('rollNo', validateRoll(source.rollNo, 'CSMU roll number'));
      const semester = String(source.semester || '').trim();
      if (SEMESTER_OPTIONS.includes(semester)) value.yearOrSemester = semester; else errors.semester = 'Choose your semester.';
    } else {
      errors.scope = 'Choose a registration scope.';
    }
    return { ok: Object.keys(errors).length === 0, errors, value };
  }

  /* ---------- Events ---------- */

  function monthIndexFromName(text) {
    const word = String(text || '').toLowerCase().replace(/[^a-z]/g, '');
    if (word.length < 3) return -1;
    return MONTHS.findIndex(month => month.toLowerCase().startsWith(word));
  }

  function validIso(year, month, day) {
    const y = Number(year);
    const m = Number(month);
    const d = Number(day);
    if (!Number.isInteger(y) || !Number.isInteger(m) || !Number.isInteger(d)) return '';
    const date = new Date(Date.UTC(y, m - 1, d));
    if (date.getUTCFullYear() !== y || date.getUTCMonth() !== m - 1 || date.getUTCDate() !== d) return '';
    return `${String(y).padStart(4, '0')}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }

  // Best-effort calendar date for an event: explicit ISO date, month/day/year fields, or the display text.
  function eventIsoDate(event) {
    const e = event || {};
    if (/^\d{4}-\d{2}-\d{2}$/.test(String(e.isoDate || ''))) return e.isoDate;
    if (e.month !== undefined && e.month !== '' && e.day && e.year) {
      const iso = validIso(e.year, Number(e.month) + 1, String(e.day).replace(/\D/g, ''));
      if (iso) return iso;
    }
    const text = String(e.date || '').trim();
    let match = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (match) return validIso(match[1], match[2], match[3]);
    match = text.match(/^(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]+)[,\s]+(\d{4})$/);
    if (match) {
      const month = monthIndexFromName(match[2]);
      return month >= 0 ? validIso(match[3], month + 1, match[1]) : '';
    }
    match = text.match(/^([A-Za-z]+)\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})$/);
    if (match) {
      const month = monthIndexFromName(match[1]);
      return month >= 0 ? validIso(match[3], month + 1, match[2]) : '';
    }
    return '';
  }

  function eventYear(event) {
    const iso = eventIsoDate(event);
    if (iso) return Number(iso.slice(0, 4));
    const year = Number(event && event.year);
    return Number.isInteger(year) && year > 1900 ? year : null;
  }

  function formatIsoDate(iso) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(iso || ''))) return '';
    const [y, m, d] = iso.split('-').map(Number);
    return `${d} ${MONTHS[m - 1]} ${y}`;
  }

  // Today's calendar date in India (YYYY-MM-DD), independent of the server's own timezone.
  function todayIso(now = new Date()) {
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone: TIME_ZONE, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now);
    const get = type => parts.find(part => part.type === type).value;
    return `${get('year')}-${get('month')}-${get('day')}`;
  }

  function formatIstDateTime(iso) {
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return '';
    const parts = new Intl.DateTimeFormat('en-GB', { timeZone: TIME_ZONE, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(date);
    const get = type => parts.find(part => part.type === type).value;
    return `${get('year')}-${get('month')}-${get('day')} ${get('hour')}:${get('minute')}`;
  }

  // Event is still open for registration: upcoming, or the date has not been set yet.
  function isUpcomingEvent(event, today) {
    const iso = eventIsoDate(event);
    return !iso || iso >= today;
  }

  function feeLabel(event) {
    if (!event || event.feeType !== 'paid' || !(Number(event.fee) > 0)) return 'Free entry';
    return `₹${Number(event.fee).toLocaleString('en-IN')}`;
  }

  function feeStatusText(amount, paid) {
    if (!paid || !(amount > 0)) return 'Free entry';
    return `Pending · ₹${Number(amount).toLocaleString('en-IN')} payable at the desk on the event day`;
  }

  function seatsFor(registrations, eventId, capacity) {
    const filled = (registrations || []).filter(row => row.eventId === eventId).length;
    const cap = Number.isInteger(capacity) && capacity > 0 ? capacity : null;
    return { filled, capacity: cap, open: cap === null ? null : Math.max(0, cap - filled), full: cap !== null && filled >= cap };
  }

  /* ---------- Serials and CSV ---------- */

  function serialFor(year, digits) {
    return `MT-${year}-${digits}`;
  }

  const SERIAL_PATTERN = /^MT-\d{4}-\d{6}$/;

  function csvCell(value) {
    let text = value === undefined || value === null ? '' : String(value);
    if (/^[=@\t\r]/.test(text)) text = `'${text}`;
    if (/[",\r\n]/.test(text)) text = `"${text.replace(/"/g, '""')}"`;
    return text;
  }

  function toCsv(headers, rows) {
    const lines = [headers, ...rows].map(row => row.map(csvCell).join(','));
    return `\uFEFF${lines.join('\r\n')}\r\n`;
  }


  /* ---------- Data model: normalisation, public projection, passes and exports ---------- */

  function normalizeEvent(raw) {
    const e = { ...(raw || {}) };
    e.id = String(e.id || '');
    e.title = String(e.title || 'Mindful Tattva activity');
    e.scope = SCOPE_IDS.includes(e.scope) ? e.scope : 'interdepartmental';
    e.kicker = String(e.kicker || 'Mindful Tattva');
    e.category = String(e.category || e.kicker || 'Club gathering').trim();
    e.feeType = FEE_TYPES.includes(e.feeType) ? e.feeType : 'free';
    e.fee = e.feeType === 'paid' ? Math.max(0, Number(e.fee) || 0) : 0;
    const capacity = Number(e.capacity);
    e.capacity = Number.isInteger(capacity) && capacity > 0 ? capacity : null;
    e.instructor = String(e.instructor || '');
    e.brochureUrl = String(e.brochureUrl || '');
    e.published = e.published === true;
    e.isoDate = eventIsoDate(e);
    return e;
  }

  function normalizeMember(raw) {
    const m = { ...(raw || {}) };
    m.group = GROUP_IDS.includes(m.group) ? m.group : 'management';
    m.groupLabel = GROUP_LABEL[m.group];
    m.email = String(m.email || '');
    m.showOnHome = m.group === 'management' ? m.showOnHome !== false : false;
    m.status = m.status || 'active';
    return m;
  }

  function normalizeGallery(raw) {
    const g = { ...(raw || {}) };
    g.title = String(g.title || g.caption || '');
    g.category = String(g.category || 'Event');
    g.url = String(g.url || '');
    return g;
  }

  // Brings a stored database up to the current shape without dropping any existing record.
  function normalizeDb(db) {
    db.site = db.site || {};
    db.history = Array.isArray(db.history) ? db.history : [];
    db.team = (Array.isArray(db.team) ? db.team : []).map(normalizeMember);
    db.events = (Array.isArray(db.events) ? db.events : []).map(normalizeEvent);
    db.gallery = (Array.isArray(db.gallery) ? db.gallery : []).map(normalizeGallery);
    db.submissions = Array.isArray(db.submissions) ? db.submissions : [];
    db.registrations = Array.isArray(db.registrations) ? db.registrations : [];
    return db;
  }

  function publicMember(member) {
    const { email, bio, sourceSubmissionId, ...rest } = member;
    if (member.group === 'volunteers') return { ...rest, email: '', bio: '' };
    return { ...rest, email: email || '', bio: bio || '', sourceSubmissionId: undefined };
  }

  function displayDate(event) {
    if (!event) return 'Date to be announced';
    if (event.date && String(event.date).trim()) return String(event.date).trim();
    return formatIsoDate(eventIsoDate(event)) || 'Date to be announced';
  }

  // Everything that may be shown on public pages. Registrations and submissions are never included.
  function publicSnapshot(db, now = new Date()) {
    const today = todayIso(now);
    const rows = db.registrations || [];
    return {
      site: db.site || {},
      history: db.history || [],
      team: (db.team || []).map(publicMember),
      events: (db.events || []).map(event => {
        const seats = seatsFor(rows, event.id, event.capacity);
        const iso = eventIsoDate(event);
        return {
          ...event,
          isoDate: iso,
          year: iso ? Number(iso.slice(0, 4)) : (event.year || null),
          seats,
          registrationOpen: Boolean(event.published) && (!iso || iso >= today) && !seats.full
        };
      }),
      gallery: db.gallery || [],
      serverTime: now.toISOString(),
      today
    };
  }

  // Builds the digital pass for one serial from its registration row.
  // A registration outlives its event: if the event is deleted from the calendar later, the pass still
  // renders from the details captured at registration time, and is flagged as archived.
  function buildPass(rows, eventsById) {
    const sorted = [...rows].sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)));
    const first = sorted[0];
    if (!first) return null;
    const event = (eventsById || {})[first.eventId];
    const archived = !event;
    const paid = first.feeType === 'paid' && Number(first.fee) > 0;
    const feeTotal = paid ? Number(first.fee) : 0;
    return {
      serial: first.serial,
      passType: 'event',
      archived,
      eventId: first.eventId,
      eventTitle: event ? event.title : (first.eventTitle || 'Event removed from the calendar'),
      eventDate: event ? displayDate(event) : (formatIsoDate(first.eventDate) || 'Archived event'),
      eventTime: event ? (event.time || '') : (first.eventTime || ''),
      venue: event ? (event.location || '') : (first.eventVenue || ''),
      eventScope: first.eventScope,
      eventScopeLabel: SCOPE_LABEL[first.eventScope] || '',
      participantScope: first.formScope,
      participantScopeLabel: SCOPE_LABEL[first.formScope] || '',
      name: first.name,
      email: first.email,
      phone: first.phone,
      college: first.college,
      department: first.department,
      rollNo: first.rollNo,
      yearOrSemester: first.yearOrSemester,
      feeTotal,
      feeStatus: feeTotal > 0 ? feeStatusText(feeTotal, true) : 'Free entry',
      issuedAt: first.createdAt
    };
  }

  const REGISTRATION_CSV_HEADERS = [
    'Serial Number', 'Event Title', 'Scope', 'Name', 'Email', 'Phone', 'College Name', 'Department',
    'Roll No/PRN', 'Registration Date', 'Pass Type', 'Participant Category', 'Year / Semester', 'Fee Status', 'Event Date', 'Venue'
  ];

  function registrationCsvRow(row, event) {
    const paid = row.feeType === 'paid' && Number(row.fee) > 0;
    return [
      row.serial,
      event ? event.title : (row.eventTitle || 'Deleted event'),
      SCOPE_LABEL[row.eventScope] || '',
      row.name,
      row.email,
      row.phone,
      row.college,
      row.department,
      row.rollNo,
      formatIstDateTime(row.createdAt),
      'Single event',
      SCOPE_LABEL[row.formScope] || '',
      row.yearOrSemester || '',
      paid ? `Pending · ₹${Number(row.fee).toLocaleString('en-IN')} at desk` : 'Free entry',
      event ? displayDate(event) : (formatIsoDate(row.eventDate) || ''),
      event ? event.location || '' : (row.eventVenue || '')
    ];
  }

  function slugify(text) {
    return String(text || 'event').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'event';
  }

  return {
    UNIVERSITY_NAME, DEPARTMENT_NAME, MONTHS, SCOPES, SCOPE_IDS, SCOPE_LABEL, GROUP_IDS, GROUP_LABEL,
    YEAR_OPTIONS, SEMESTER_OPTIONS, CATEGORY_PRESETS, FEE_TYPES, TIME_ZONE, SERIAL_PATTERN,
    mobileDummyReason, normalizeIndianMobile, validateEmail, validateName, validateRoll, validateText,
    validateRegistrationFields, eventIsoDate, eventYear, formatIsoDate, todayIso, formatIstDateTime,
    isUpcomingEvent, feeLabel, feeStatusText, seatsFor, serialFor, csvCell, toCsv, validIso,
    normalizeEvent, normalizeMember, normalizeGallery, normalizeDb, publicMember, publicSnapshot, displayDate,
    buildPass, REGISTRATION_CSV_HEADERS, registrationCsvRow, slugify, formatIsoDate
  };
});
